# Feature Engineering Variants Report

**Dataset**: data/my_gmail_dataset.csv
**Total Emails**: 100
**Bills**: 2 (2.0%)
**Generated**: 2025-07-04 13:50:48

## Feature Variants Created

### Basic Features
- **Description**: Basic features with minimal text processing
- **Feature Count**: 10
- **Text Processing**: Simple keyword counting
- **File**: `basic_features.csv`

### Enhanced Features
- **Description**: Enhanced text processing features (75+ features)
- **Feature Count**: 66
- **Text Processing**: Advanced NLP with domain-specific features
- **File**: `enhanced_features.csv`

### Tfidf Features
- **Description**: TF-IDF text features (top 100) + basic metadata
- **Feature Count**: 104
- **Text Processing**: TF-IDF vectorization with 1-2 grams
- **File**: `tfidf_features.csv`

### Combined Features
- **Description**: Enhanced features + TF-IDF features combined
- **Feature Count**: 166
- **Text Processing**: Advanced NLP + TF-IDF vectorization
- **File**: `combined_features.csv`

### Selected Features
- **Description**: Top 20 features selected using mutual information
- **Feature Count**: 20
- **Text Processing**: Feature selection from enhanced features
- **File**: `selected_features.csv`

### Pca Features
- **Description**: PCA-reduced features (15 components)
- **Feature Count**: 15
- **Text Processing**: Dimensionality reduction via PCA
- **Explained Variance**: 0.841
- **File**: `pca_features.csv`

## Recommended Usage

1. **Basic**: Baseline comparison, simple interpretability
2. **Enhanced**: Full feature richness, best for complex models
3. **TF-IDF**: Traditional text classification approach
4. **Combined**: Maximum information, may overfit on small datasets
5. **Selected**: Reduced overfitting, faster training
6. **PCA**: Dimensionality reduction, decorrelated features

## Next Steps

- Train models on each variant
- Compare cross-validation performance
- Analyze feature importance for interpretability
- Test on real-world email data
