#!/usr/bin/env python3
"""
Script to run the Email Classification Dashboard

This script launches the Streamlit dashboard for visualizing and interacting
with the email classification model results.

Usage:
    python run_dashboard.py
"""

import subprocess
import sys
import os
from pathlib import Path

def main():
    """Run the Streamlit dashboard"""
    
    # Get the directory containing this script
    script_dir = Path(__file__).parent
    
    # Path to the Streamlit app
    app_path = script_dir / "app" / "streamlit_dashboard.py"
    
    # Change to the project directory so paths work correctly
    os.chdir(script_dir)
    
    # Streamlit command
    cmd = [
        sys.executable, "-m", "streamlit", "run", str(app_path),
        "--server.port", "8501",
        "--server.address", "localhost",
        "--server.headless", "false",
        "--theme.base", "light"
    ]
    
    print("🚀 Starting Email Classification Dashboard...")
    print(f"📧 Dashboard will be available at: http://localhost:8501")
    print("💡 Press Ctrl+C to stop the server")
    print("-" * 50)
    
    try:
        # Run Streamlit
        subprocess.run(cmd, check=True)
    except KeyboardInterrupt:
        print("\n👋 Dashboard stopped by user")
    except subprocess.CalledProcessError as e:
        print(f"❌ Error running dashboard: {e}")
        return 1
    except Exception as e:
        print(f"❌ Unexpected error: {e}")
        return 1
    
    return 0

if __name__ == "__main__":
    exit(main()) 