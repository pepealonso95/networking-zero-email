#!/usr/bin/env python3
"""
Validation script to check if the Streamlit dashboard setup is correct.

This script verifies that all required data files and dependencies are available
before running the dashboard.
"""

import sys
from pathlib import Path
import json

def check_file_exists(file_path, description):
    """Check if a file exists and report the result"""
    if file_path.exists():
        print(f"✅ {description}: {file_path}")
        return True
    else:
        print(f"❌ {description}: {file_path} (NOT FOUND)")
        return False

def check_dependencies():
    """Check if required Python packages are available"""
    required_packages = [
        'streamlit', 'pandas', 'plotly', 'numpy', 
        'scikit-learn', 'matplotlib', 'seaborn'
    ]
    
    missing_packages = []
    
    print("🔍 Checking Python dependencies...")
    for package in required_packages:
        try:
            __import__(package)
            print(f"✅ {package}")
        except ImportError:
            print(f"❌ {package} (NOT INSTALLED)")
            missing_packages.append(package)
    
    return missing_packages

def validate_data_structure():
    """Validate that all required data files are present"""
    print("\n📁 Checking data files...")
    
    base_path = Path(".")
    all_files_present = True
    
    # Required files
    required_files = [
        ("data/my_gmail_dataset.csv", "Original Gmail dataset"),
        ("data/feature_variants/basic_features.csv", "Basic features"),
        ("data/feature_variants/enhanced_features.csv", "Enhanced features"),
        ("data/feature_variants/tfidf_features.csv", "TF-IDF features"),
        ("data/feature_variants/combined_features.csv", "Combined features"),
        ("data/feature_variants/selected_features.csv", "Selected features"),
        ("data/feature_variants/pca_features.csv", "PCA features"),
        ("data/feature_variants/feature_variants_report.json", "Feature variants report"),
        ("results/model_comparison/detailed_results.csv", "Model comparison results"),
        ("app/streamlit_dashboard.py", "Streamlit dashboard app"),
    ]
    
    for file_path, description in required_files:
        if not check_file_exists(base_path / file_path, description):
            all_files_present = False
    
    return all_files_present

def validate_data_content():
    """Validate the content of key data files"""
    print("\n🔍 Checking data content...")
    
    try:
        # Check feature variants report
        with open("data/feature_variants/feature_variants_report.json", 'r') as f:
            feature_report_data = json.load(f)
        
        # Extract the variants section if it exists
        feature_report = feature_report_data.get('variants', feature_report_data)
        
        expected_variants = ['basic', 'enhanced', 'tfidf', 'combined', 'selected', 'pca']
        found_variants = [v for v in expected_variants if v in feature_report]
        
        print(f"✅ Feature variants in report: {len(found_variants)}/6")
        if len(found_variants) < 6:
            missing = set(expected_variants) - set(found_variants)
            print(f"⚠️  Missing variants: {missing}")
        
        # Check if results file has expected columns
        import pandas as pd
        results_df = pd.read_csv("results/model_comparison/detailed_results.csv")
        
        expected_columns = ['model_name', 'variant_name', 'test_f1', 'test_roc_auc', 'test_precision', 'test_recall']
        missing_columns = [col for col in expected_columns if col not in results_df.columns]
        
        if missing_columns:
            print(f"❌ Missing columns in results: {missing_columns}")
            return False
        else:
            print(f"✅ Results file has {len(results_df)} model combinations")
            print(f"✅ All required columns present")
        
        return True
        
    except Exception as e:
        print(f"❌ Error validating data content: {e}")
        return False

def main():
    """Main validation function"""
    print("🚀 Email Classification Dashboard - Setup Validation")
    print("=" * 60)
    
    # Check current directory
    current_dir = Path.cwd()
    print(f"📍 Current directory: {current_dir}")
    
    # Check if we're in the right directory
    if not (current_dir / "app" / "streamlit_dashboard.py").exists():
        print("❌ Not in the email-classifier directory!")
        print("💡 Please run this script from the email-classifier directory")
        return 1
    
    # Check dependencies
    missing_packages = check_dependencies()
    
    # Check data structure
    data_files_ok = validate_data_structure()
    
    # Check data content
    data_content_ok = validate_data_content()
    
    # Summary
    print("\n" + "=" * 60)
    print("📋 VALIDATION SUMMARY")
    print("=" * 60)
    
    if missing_packages:
        print(f"❌ Missing Python packages: {', '.join(missing_packages)}")
        print("💡 Install with: pip install -r requirements.txt")
    else:
        print("✅ All Python dependencies are installed")
    
    if data_files_ok:
        print("✅ All required data files are present")
    else:
        print("❌ Some data files are missing")
        print("💡 Ensure feature engineering and model comparison scripts have been run")
    
    if data_content_ok:
        print("✅ Data content validation passed")
    else:
        print("❌ Data content validation failed")
    
    # Overall status
    if not missing_packages and data_files_ok and data_content_ok:
        print("\n🎉 SETUP VALIDATION PASSED!")
        print("✅ Dashboard is ready to run")
        print("🚀 Start with: python run_dashboard.py")
        return 0
    else:
        print("\n⚠️  SETUP VALIDATION FAILED!")
        print("❌ Please fix the issues above before running the dashboard")
        return 1

if __name__ == "__main__":
    exit(main()) 