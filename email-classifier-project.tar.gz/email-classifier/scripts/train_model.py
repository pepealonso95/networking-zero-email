#!/usr/bin/env python3
"""
Model Training Script

Trains a lightweight email classification model using the GPT-labeled data.
Supports multiple model types: DistilBERT, RoBERTa, or traditional ML models.

Usage:
    python scripts/train_model.py --data data/labeled_emails.csv --model-type distilbert --output models/bill_classifier
"""

import argparse
import pandas as pd
import numpy as np
import json
import pickle
import sys
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
from datetime import datetime
import os
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, confusion_matrix, accuracy_score, f1_score
from sklearn.preprocessing import StandardScaler
import torch
from torch.utils.data import Dataset, DataLoader
from transformers import (
    AutoTokenizer, AutoModelForSequenceClassification,
    TrainingArguments, Trainer, EvalPrediction
)
from datasets import Dataset as HFDataset
import warnings
warnings.filterwarnings('ignore')

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from config.settings import settings
from app.models.classifier import EmailFeatureExtractor


class EmailDataset(Dataset):
    """PyTorch dataset for email classification."""
    
    def __init__(self, texts: List[str], labels: List[int], tokenizer, max_length: int = 512):
        self.texts = texts
        self.labels = labels
        self.tokenizer = tokenizer
        self.max_length = max_length
    
    def __len__(self):
        return len(self.texts)
    
    def __getitem__(self, idx):
        text = str(self.texts[idx])
        label = self.labels[idx]
        
        encoding = self.tokenizer(
            text,
            truncation=True,
            padding='max_length',
            max_length=self.max_length,
            return_tensors='pt'
        )
        
        return {
            'input_ids': encoding['input_ids'].flatten(),
            'attention_mask': encoding['attention_mask'].flatten(),
            'labels': torch.tensor(label, dtype=torch.long)
        }


class ModelTrainer:
    """Trains different types of email classification models."""
    
    def __init__(self, model_type: str = "distilbert"):
        self.model_type = model_type
        self.feature_extractor = EmailFeatureExtractor()
        self.model = None
        self.tokenizer = None
        self.scaler = None
        
    def prepare_data(self, df: pd.DataFrame) -> Tuple[Any, Any, Any, Any]:
        """Prepare data for training based on model type."""
        # Filter out failed classifications
        if 'error' in df.columns:
            df_clean = df[~df['error']].copy()
        else:
            df_clean = df.copy()
        
        # Remove rows where classification is missing
        df_clean = df_clean.dropna(subset=['is_bill'])
        
        print(f"📊 Training data: {len(df_clean)} samples")
        print(f"   Bills: {df_clean['is_bill'].sum()} ({df_clean['is_bill'].mean()*100:.1f}%)")
        print(f"   Not bills: {(~df_clean['is_bill']).sum()} ({(~df_clean['is_bill']).mean()*100:.1f}%)")
        
        if self.model_type in ["distilbert", "roberta"]:
            return self._prepare_transformer_data(df_clean)
        else:
            return self._prepare_ml_data(df_clean)
    
    def _prepare_transformer_data(self, df: pd.DataFrame) -> Tuple[List[str], List[str], List[int], List[int]]:
        """Prepare data for transformer models."""
        # Combine subject and body
        texts = []
        for _, row in df.iterrows():
            subject = str(row.get('subject', ''))
            body = str(row.get('body', ''))
            text = f"{subject} [SEP] {body}"
            texts.append(text)
        
        labels = df['is_bill'].astype(int).tolist()
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            texts, labels, 
            test_size=settings.validation_split,
            random_state=42,
            stratify=labels
        )
        
        return X_train, X_test, y_train, y_test
    
    def _prepare_ml_data(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, List[int], List[int]]:
        """Prepare data for traditional ML models."""
        # Extract features for all emails
        features_list = []
        for _, row in df.iterrows():
            features = self.feature_extractor.extract_all_features(row.to_dict())
            features_list.append(features)
        
        features_df = pd.DataFrame(features_list)
        
        # Remove non-numeric columns
        numeric_columns = features_df.select_dtypes(include=[np.number]).columns
        features_df = features_df[numeric_columns]
        
        # Fill NaN values
        features_df = features_df.fillna(0)
        
        labels = df['is_bill'].astype(int).tolist()
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            features_df, labels,
            test_size=settings.validation_split,
            random_state=42,
            stratify=labels
        )
        
        return X_train, X_test, y_train, y_test
    
    def train_transformer_model(self, X_train: List[str], X_test: List[str], 
                              y_train: List[int], y_test: List[int]) -> Dict[str, Any]:
        """Train a transformer-based model."""
        print(f"🤖 Training {self.model_type} model...")
        
        # Initialize tokenizer and model
        model_name = f"distilbert-base-uncased" if self.model_type == "distilbert" else "roberta-base"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForSequenceClassification.from_pretrained(
            model_name, 
            num_labels=2
        )
        
        # Prepare datasets
        train_dataset = HFDataset.from_dict({
            'text': X_train,
            'labels': y_train
        })
        
        test_dataset = HFDataset.from_dict({
            'text': X_test,
            'labels': y_test
        })
        
        def tokenize_function(examples):
            return self.tokenizer(
                examples['text'],
                truncation=True,
                padding=True,
                max_length=512
            )
        
        train_dataset = train_dataset.map(tokenize_function, batched=True)
        test_dataset = test_dataset.map(tokenize_function, batched=True)
        
        # Training arguments
        training_args = TrainingArguments(
            output_dir='./training_output',
            num_train_epochs=settings.epochs,
            per_device_train_batch_size=settings.batch_size,
            per_device_eval_batch_size=settings.batch_size,
            warmup_steps=100,
            weight_decay=0.01,
            logging_dir='./logs',
            logging_steps=10,
            evaluation_strategy="epoch",
            save_strategy="epoch",
            load_best_model_at_end=True,
            metric_for_best_model="f1",
            greater_is_better=True,
            report_to=None,  # Disable wandb
        )
        
        def compute_metrics(eval_pred: EvalPrediction):
            predictions, labels = eval_pred
            predictions = np.argmax(predictions, axis=1)
            return {
                'accuracy': accuracy_score(labels, predictions),
                'f1': f1_score(labels, predictions)
            }
        
        # Create trainer
        trainer = Trainer(
            model=self.model,
            args=training_args,
            train_dataset=train_dataset,
            eval_dataset=test_dataset,
            compute_metrics=compute_metrics,
        )
        
        # Train model
        start_time = datetime.now()
        trainer.train()
        training_time = (datetime.now() - start_time).total_seconds()
        
        # Evaluate
        eval_results = trainer.evaluate()
        
        return {
            "model_type": self.model_type,
            "training_time": training_time,
            "accuracy": eval_results["eval_accuracy"],
            "f1_score": eval_results["eval_f1"],
            "eval_loss": eval_results["eval_loss"]
        }
    
    def train_ml_model(self, X_train: pd.DataFrame, X_test: pd.DataFrame,
                      y_train: List[int], y_test: List[int]) -> Dict[str, Any]:
        """Train a traditional ML model."""
        print(f"🤖 Training {self.model_type} model...")
        
        # Scale features
        self.scaler = StandardScaler()
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Choose model
        if self.model_type == "random_forest":
            self.model = RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42,
                n_jobs=-1
            )
        elif self.model_type == "gradient_boosting":
            self.model = GradientBoostingClassifier(
                n_estimators=100,
                max_depth=5,
                random_state=42
            )
        else:  # logistic_regression
            self.model = LogisticRegression(
                random_state=42,
                max_iter=1000
            )
        
        # Train model
        start_time = datetime.now()
        self.model.fit(X_train_scaled, y_train)
        training_time = (datetime.now() - start_time).total_seconds()
        
        # Evaluate
        y_pred = self.model.predict(X_test_scaled)
        accuracy = accuracy_score(y_test, y_pred)
        f1 = f1_score(y_test, y_pred)
        
        # Cross-validation (skip for very small datasets)
        if len(y_train) >= 10:
            cv_scores = cross_val_score(self.model, X_train_scaled, y_train, cv=3, scoring='f1')
        else:
            cv_scores = [f1]  # Skip CV for small datasets
            print("⚠️  Skipping cross-validation due to small dataset size")
        
        # Feature importance
        feature_importance = {}
        if hasattr(self.model, 'feature_importances_'):
            feature_names = X_train.columns.tolist()
            importance_scores = self.model.feature_importances_
            feature_importance = dict(zip(feature_names, importance_scores))
            # Sort by importance
            feature_importance = dict(sorted(feature_importance.items(), 
                                           key=lambda x: x[1], reverse=True))
        
        return {
            "model_type": self.model_type,
            "training_time": training_time,
            "accuracy": accuracy,
            "f1_score": f1,
            "cv_f1_mean": np.mean(cv_scores),
            "cv_f1_std": np.std(cv_scores),
            "feature_importance": feature_importance,
            "training_samples": len(X_train),
            "test_samples": len(X_test)
        }
    
    def save_model(self, output_path: str, training_results: Dict[str, Any]):
        """Save the trained model."""
        print(f"💾 Saving model to {output_path}...")
        
        # Create output directory
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        if self.model_type in ["distilbert", "roberta"]:
            # Save transformer model
            model_dir = os.path.dirname(output_path)
            self.model.save_pretrained(model_dir)
            self.tokenizer.save_pretrained(model_dir)
        else:
            # Save ML model and scaler
            model_data = {
                'model': self.model,
                'scaler': self.scaler,
                'feature_names': self.model.feature_names_in_ if hasattr(self.model, 'feature_names_in_') else None
            }
            with open(output_path, 'wb') as f:
                pickle.dump(model_data, f)
        
        # Save model info
        model_info = {
            **training_results,
            "trained_at": datetime.utcnow().isoformat(),
            "model_version": "1.0",
            "settings": {
                "max_email_length": settings.max_email_length,
                "epochs": settings.epochs if self.model_type in ["distilbert", "roberta"] else None,
                "batch_size": settings.batch_size if self.model_type in ["distilbert", "roberta"] else None
            }
        }
        
        info_path = output_path.replace('.pkl', '_info.json').replace('.bin', '_info.json')
        with open(info_path, 'w') as f:
            json.dump(model_info, f, indent=2)
        
        print(f"✅ Model saved successfully")
        print(f"   Model file: {output_path}")
        print(f"   Info file: {info_path}")


def main():
    """Main training function."""
    parser = argparse.ArgumentParser(description="Train email classification model")
    parser.add_argument("--data", required=True, help="Path to labeled training data CSV")
    parser.add_argument("--model-type", choices=["distilbert", "roberta", "random_forest", "gradient_boosting", "logistic_regression"],
                       default="distilbert", help="Type of model to train")
    parser.add_argument("--output", required=True, help="Output path for trained model")
    parser.add_argument("--epochs", type=int, default=3, help="Number of training epochs (transformer models)")
    parser.add_argument("--batch-size", type=int, default=16, help="Training batch size (transformer models)")
    parser.add_argument("--max-samples", type=int, default=None, help="Maximum samples to use for training")
    
    args = parser.parse_args()
    
    # Validate input
    if not os.path.exists(args.data):
        print(f"❌ Training data not found: {args.data}")
        return
    
    print(f"🚀 Starting model training...")
    print(f"   Data: {args.data}")
    print(f"   Model type: {args.model_type}")
    print(f"   Output: {args.output}")
    
    # Update settings
    if args.epochs:
        settings.epochs = args.epochs
    if args.batch_size:
        settings.batch_size = args.batch_size
    
    # Load data
    print("📂 Loading training data...")
    df = pd.read_csv(args.data)
    print(f"   Loaded {len(df)} samples")
    
    # Limit samples if specified
    if args.max_samples and len(df) > args.max_samples:
        df = df.sample(n=args.max_samples, random_state=42)
        print(f"   Limited to {len(df)} samples")
    
    # Initialize trainer
    trainer = ModelTrainer(args.model_type)
    
    # Prepare data
    print("🔄 Preparing data...")
    X_train, X_test, y_train, y_test = trainer.prepare_data(df)
    
    # Train model
    if args.model_type in ["distilbert", "roberta"]:
        results = trainer.train_transformer_model(X_train, X_test, y_train, y_test)
    else:
        results = trainer.train_ml_model(X_train, X_test, y_train, y_test)
    
    # Save model
    trainer.save_model(args.output, results)
    
    # Print results
    print("\n📊 Training Results:")
    print(f"   Model type: {results['model_type']}")
    print(f"   Training time: {results['training_time']:.2f} seconds")
    print(f"   Accuracy: {results['accuracy']:.4f}")
    print(f"   F1 Score: {results['f1_score']:.4f}")
    
    if 'cv_f1_mean' in results:
        print(f"   CV F1 Score: {results['cv_f1_mean']:.4f} ± {results['cv_f1_std']:.4f}")
    
    if 'feature_importance' in results:
        print("\n🔍 Top 10 Important Features:")
        for i, (feature, importance) in enumerate(list(results['feature_importance'].items())[:10]):
            print(f"   {i+1:2d}. {feature}: {importance:.4f}")
    
    print(f"\n✅ Training completed successfully!")


if __name__ == "__main__":
    main() 