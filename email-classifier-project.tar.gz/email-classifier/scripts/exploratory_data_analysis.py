"""
Comprehensive Exploratory Data Analysis (EDA) for Email Classification Dataset

This script provides thorough analysis including:
- Dataset overview and statistics
- Target distribution analysis
- Feature correlation analysis
- Visualization of patterns and relationships
- Data quality assessment
- Feature importance analysis
- Class imbalance evaluation
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy import stats
from sklearn.feature_selection import mutual_info_classif, chi2, SelectKBest
from sklearn.preprocessing import StandardScaler, LabelEncoder
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import warnings
import argparse
import os
import json
from datetime import datetime
from typing import Dict, List, Tuple, Any
import sys
from pathlib import Path

# Add parent directory to path for imports
sys.path.append(str(Path(__file__).parent.parent))

from app.models.enhanced_text_processor import EnhancedTextProcessor, create_enhanced_feature_dataset

# Configure plotting
plt.style.use('default')
sns.set_palette("husl")
warnings.filterwarnings('ignore')


class EmailDatasetEDA:
    """Comprehensive EDA class for email classification dataset."""
    
    def __init__(self, data_path: str, output_dir: str = "eda_output"):
        """Initialize EDA with dataset."""
        self.data_path = data_path
        self.output_dir = output_dir
        self.df = None
        self.enhanced_df = None
        self.target_col = 'is_bill'
        self.results = {}
        
        # Create output directory
        os.makedirs(output_dir, exist_ok=True)
        os.makedirs(f"{output_dir}/plots", exist_ok=True)
        
    def load_and_prepare_data(self) -> None:
        """Load and prepare the dataset for analysis."""
        print("📂 Loading dataset...")
        self.df = pd.read_csv(self.data_path)
        
        # Convert target to binary if needed
        if self.target_col not in self.df.columns:
            if 'label' in self.df.columns:
                self.df[self.target_col] = self.df['label']
            else:
                raise ValueError(f"Target column '{self.target_col}' not found in dataset")
        
        # Ensure target is boolean
        if self.df[self.target_col].dtype != bool:
            self.df[self.target_col] = self.df[self.target_col].astype(bool)
        
        print(f"✅ Loaded {len(self.df)} samples")
        
        # Create enhanced features
        print("🔧 Creating enhanced features...")
        self.enhanced_df = create_enhanced_feature_dataset(self.df)
        print(f"✅ Enhanced dataset with {self.enhanced_df.shape[1]} features")
        
    def dataset_overview(self) -> Dict[str, Any]:
        """Generate comprehensive dataset overview."""
        print("\n📊 Analyzing Dataset Overview...")
        
        overview = {
            'basic_info': {
                'total_samples': len(self.df),
                'total_features': self.df.shape[1],
                'enhanced_features': self.enhanced_df.shape[1],
                'memory_usage_mb': self.df.memory_usage(deep=True).sum() / 1024**2
            },
            'target_distribution': {
                'bills': int(self.df[self.target_col].sum()),
                'not_bills': int((~self.df[self.target_col]).sum()),
                'bill_percentage': float(self.df[self.target_col].mean() * 100),
                'class_imbalance_ratio': float((~self.df[self.target_col]).sum() / max(self.df[self.target_col].sum(), 1))
            },
            'data_quality': {
                'missing_values': int(self.df.isnull().sum().sum()),
                'duplicate_rows': int(self.df.duplicated().sum()),
                'unique_subjects': int(self.df['subject'].nunique()) if 'subject' in self.df.columns else 0,
                'unique_senders': int(self.df['sender_email'].nunique()) if 'sender_email' in self.df.columns else 0
            }
        }
        
        # Text statistics
        if 'subject' in self.df.columns and 'body' in self.df.columns:
            overview['text_statistics'] = {
                'avg_subject_length': float(self.df['subject'].str.len().mean()),
                'avg_body_length': float(self.df['body'].str.len().mean()),
                'max_subject_length': int(self.df['subject'].str.len().max()),
                'max_body_length': int(self.df['body'].str.len().max()),
                'empty_subjects': int(self.df['subject'].isnull().sum()),
                'empty_bodies': int(self.df['body'].isnull().sum())
            }
        
        self.results['dataset_overview'] = overview
        
        # Save overview
        with open(f"{self.output_dir}/dataset_overview.json", 'w') as f:
            json.dump(overview, f, indent=2)
        
        self._print_overview(overview)
        return overview
    
    def _print_overview(self, overview: Dict[str, Any]) -> None:
        """Print formatted overview."""
        print("\n" + "="*60)
        print("📋 DATASET OVERVIEW")
        print("="*60)
        
        basic = overview['basic_info']
        print(f"📊 Basic Information:")
        print(f"   • Total samples: {basic['total_samples']:,}")
        print(f"   • Original features: {basic['total_features']}")
        print(f"   • Enhanced features: {basic['enhanced_features']}")
        print(f"   • Memory usage: {basic['memory_usage_mb']:.2f} MB")
        
        target = overview['target_distribution']
        print(f"\n🎯 Target Distribution:")
        print(f"   • Bills: {target['bills']} ({target['bill_percentage']:.1f}%)")
        print(f"   • Not bills: {target['not_bills']} ({100-target['bill_percentage']:.1f}%)")
        print(f"   • Class imbalance ratio: {target['class_imbalance_ratio']:.2f}")
        
        quality = overview['data_quality']
        print(f"\n🔍 Data Quality:")
        print(f"   • Missing values: {quality['missing_values']}")
        print(f"   • Duplicate rows: {quality['duplicate_rows']}")
        print(f"   • Unique subjects: {quality['unique_subjects']}")
        print(f"   • Unique senders: {quality['unique_senders']}")
        
        if 'text_statistics' in overview:
            text = overview['text_statistics']
            print(f"\n📝 Text Statistics:")
            print(f"   • Avg subject length: {text['avg_subject_length']:.1f} chars")
            print(f"   • Avg body length: {text['avg_body_length']:.1f} chars")
            print(f"   • Max subject length: {text['max_subject_length']} chars")
            print(f"   • Max body length: {text['max_body_length']} chars")
    
    def analyze_target_distribution(self) -> None:
        """Analyze target variable distribution in detail."""
        print("\n🎯 Analyzing Target Distribution...")
        
        # Create visualizations
        fig, axes = plt.subplots(2, 2, figsize=(15, 10))
        
        # Target distribution pie chart
        target_counts = self.df[self.target_col].value_counts()
        axes[0, 0].pie(target_counts.values, labels=['Not Bills', 'Bills'], autopct='%1.1f%%', startangle=90)
        axes[0, 0].set_title('Target Distribution', fontsize=14, fontweight='bold')
        
        # Target distribution by sender domain (if available)
        if 'sender_email' in self.df.columns:
            domains = self.df['sender_email'].str.split('@').str[1].value_counts().head(10)
            domain_target = self.df.groupby(self.df['sender_email'].str.split('@').str[1])[self.target_col].agg(['count', 'sum', 'mean'])
            domain_target = domain_target[domain_target['count'] >= 2].sort_values('mean', ascending=False).head(8)
            
            axes[0, 1].bar(range(len(domain_target)), domain_target['mean'])
            axes[0, 1].set_xlabel('Top Sender Domains')
            axes[0, 1].set_ylabel('Bill Rate')
            axes[0, 1].set_title('Bill Rate by Sender Domain')
            axes[0, 1].set_xticks(range(len(domain_target)))
            axes[0, 1].set_xticklabels(domain_target.index, rotation=45, ha='right')
        
        # Text length distribution by target
        if 'subject' in self.df.columns:
            subject_lengths = self.df['subject'].str.len()
            bins = np.linspace(0, subject_lengths.max(), 20)
            
            axes[1, 0].hist(subject_lengths[self.df[self.target_col]], bins=bins, alpha=0.7, label='Bills', density=True)
            axes[1, 0].hist(subject_lengths[~self.df[self.target_col]], bins=bins, alpha=0.7, label='Not Bills', density=True)
            axes[1, 0].set_xlabel('Subject Length (characters)')
            axes[1, 0].set_ylabel('Density')
            axes[1, 0].set_title('Subject Length Distribution by Target')
            axes[1, 0].legend()
        
        # Feature importance preview (using enhanced features)
        numeric_features = self.enhanced_df.select_dtypes(include=[np.number]).columns
        numeric_features = [col for col in numeric_features if col != self.target_col]
        
        if len(numeric_features) > 0:
            # Calculate mutual information
            X = self.enhanced_df[numeric_features].fillna(0)
            y = self.enhanced_df[self.target_col]
            
            try:
                mi_scores = mutual_info_classif(X, y, random_state=42)
                # Ensure lengths match
                if len(mi_scores) == len(numeric_features):
                    feature_importance = pd.Series(mi_scores, index=numeric_features).sort_values(ascending=False).head(10)
                else:
                    print(f"⚠️  Feature count mismatch: {len(mi_scores)} scores vs {len(numeric_features)} features")
                    feature_importance = pd.Series([0.5] * min(len(mi_scores), len(numeric_features)), 
                                                 index=numeric_features[:min(len(mi_scores), len(numeric_features))])
            except Exception as e:
                print(f"⚠️  Mutual information calculation failed: {e}")
                feature_importance = pd.Series([0.5] * min(10, len(numeric_features)), 
                                             index=numeric_features[:min(10, len(numeric_features))])
            
            axes[1, 1].barh(range(len(feature_importance)), feature_importance.values)
            axes[1, 1].set_xlabel('Mutual Information Score')
            axes[1, 1].set_ylabel('Features')
            axes[1, 1].set_title('Top 10 Features by Mutual Information')
            axes[1, 1].set_yticks(range(len(feature_importance)))
            axes[1, 1].set_yticklabels(feature_importance.index)
        
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/plots/target_distribution_analysis.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        print("✅ Target distribution analysis completed")
    
    def correlation_analysis(self) -> None:
        """Perform comprehensive correlation analysis."""
        print("\n🔗 Analyzing Feature Correlations...")
        
        # Get numeric features only
        numeric_features = self.enhanced_df.select_dtypes(include=[np.number]).columns
        # Ensure target column is included
        if self.target_col not in numeric_features:
            numeric_features = list(numeric_features) + [self.target_col]
        
        correlation_data = self.enhanced_df[numeric_features].corr()
        
        # Create correlation heatmap
        plt.figure(figsize=(20, 16))
        mask = np.triu(np.ones_like(correlation_data, dtype=bool))
        
        sns.heatmap(correlation_data, mask=mask, annot=False, cmap='coolwarm', center=0,
                   square=True, linewidths=0.5, cbar_kws={"shrink": 0.8})
        plt.title('Feature Correlation Matrix', fontsize=16, fontweight='bold')
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/plots/correlation_matrix.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        # Find highly correlated features
        high_corr_pairs = []
        for i in range(len(correlation_data.columns)):
            for j in range(i+1, len(correlation_data.columns)):
                corr_value = correlation_data.iloc[i, j]
                if abs(corr_value) > 0.8:  # High correlation threshold
                    high_corr_pairs.append({
                        'feature1': correlation_data.columns[i],
                        'feature2': correlation_data.columns[j],
                        'correlation': corr_value
                    })
        
        # Target correlation analysis
        if self.target_col in correlation_data.columns:
            target_correlations = correlation_data[self.target_col].drop(self.target_col).sort_values(key=abs, ascending=False)
        else:
            print(f"⚠️  Target column '{self.target_col}' not found in correlation data")
            target_correlations = pd.Series(dtype=float)
        
        # Plot top target correlations
        plt.figure(figsize=(12, 8))
        if len(target_correlations) > 0:
            top_corr = target_correlations.head(15)
            colors = ['red' if x < 0 else 'blue' for x in top_corr.values]
            
            plt.barh(range(len(top_corr)), top_corr.values, color=colors, alpha=0.7)
            plt.xlabel('Correlation with Target')
            plt.ylabel('Features')
            plt.title('Top 15 Features Correlated with Target Variable')
            plt.yticks(range(len(top_corr)), top_corr.index)
            plt.axvline(x=0, color='black', linestyle='-', alpha=0.3)
        else:
            plt.text(0.5, 0.5, 'No target correlations available', 
                    horizontalalignment='center', verticalalignment='center', transform=plt.gca().transAxes)
            plt.title('Target Correlations - No Data Available')
        
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/plots/target_correlations.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        # Save correlation results
        correlation_results = {
            'high_correlation_pairs': high_corr_pairs,
            'top_target_correlations': target_correlations.head(20).to_dict() if len(target_correlations) > 0 else {},
            'correlation_statistics': {
                'mean_correlation': float(correlation_data.mean().mean()),
                'max_correlation': float(correlation_data.max().max()),
                'highly_correlated_pairs': len(high_corr_pairs)
            }
        }
        
        with open(f"{self.output_dir}/correlation_analysis.json", 'w') as f:
            json.dump(correlation_results, f, indent=2)
        
        self.results['correlation_analysis'] = correlation_results
        print(f"✅ Found {len(high_corr_pairs)} highly correlated feature pairs")
        if len(target_correlations) > 0:
            print(f"✅ Top target correlation: {target_correlations.iloc[0]:.3f} ({target_correlations.index[0]})")
        else:
            print("⚠️  No target correlations found")
    
    def feature_importance_analysis(self) -> None:
        """Comprehensive feature importance analysis using multiple methods."""
        print("\n🎯 Analyzing Feature Importance...")
        
        # Prepare data
        numeric_features = self.enhanced_df.select_dtypes(include=[np.number]).columns
        numeric_features = [col for col in numeric_features if col != self.target_col]
        
        X = self.enhanced_df[numeric_features].fillna(0)
        y = self.enhanced_df[self.target_col]
        
        # Method 1: Mutual Information
        try:
            mi_scores = mutual_info_classif(X, y, random_state=42)
            if len(mi_scores) == len(numeric_features):
                mi_importance = pd.Series(mi_scores, index=numeric_features).sort_values(ascending=False)
            else:
                print(f"⚠️  MI feature count mismatch: using first {len(mi_scores)} features")
                mi_importance = pd.Series(mi_scores, index=numeric_features[:len(mi_scores)]).sort_values(ascending=False)
        except Exception as e:
            print(f"⚠️  Mutual Information failed: {e}")
            mi_importance = pd.Series([0.1] * len(numeric_features), index=numeric_features)
        
        # Method 2: Chi-square test (for non-negative features)
        try:
            X_non_neg = X.copy()
            X_non_neg[X_non_neg < 0] = 0  # Chi-square requires non-negative values
            
            chi2_scores, chi2_pvalues = chi2(X_non_neg, y)
            if len(chi2_scores) == len(numeric_features):
                chi2_importance = pd.Series(chi2_scores, index=numeric_features).sort_values(ascending=False)
            else:
                print(f"⚠️  Chi2 feature count mismatch: using first {len(chi2_scores)} features")
                chi2_importance = pd.Series(chi2_scores, index=numeric_features[:len(chi2_scores)]).sort_values(ascending=False)
        except Exception as e:
            print(f"⚠️  Chi-square test failed: {e}")
            chi2_importance = pd.Series([0.1] * len(numeric_features), index=numeric_features)
        
        # Method 3: Correlation-based importance
        correlations = self.enhanced_df[numeric_features + [self.target_col]].corr()[self.target_col].drop(self.target_col)
        corr_importance = correlations.abs().sort_values(ascending=False)
        
        # Combine results
        importance_df = pd.DataFrame({
            'mutual_info': mi_importance,
            'chi_square': chi2_importance,
            'correlation': corr_importance
        }).fillna(0)
        
        # Normalize and create composite score
        importance_df_norm = importance_df.apply(lambda x: (x - x.min()) / (x.max() - x.min()))
        importance_df['composite_score'] = importance_df_norm.mean(axis=1)
        importance_df = importance_df.sort_values('composite_score', ascending=False)
        
        # Visualize top features
        fig, axes = plt.subplots(2, 2, figsize=(16, 12))
        
        # Top features by mutual information
        top_mi = mi_importance.head(10)
        axes[0, 0].barh(range(len(top_mi)), top_mi.values)
        axes[0, 0].set_title('Top 10 Features - Mutual Information')
        axes[0, 0].set_yticks(range(len(top_mi)))
        axes[0, 0].set_yticklabels(top_mi.index)
        
        # Top features by chi-square
        top_chi2 = chi2_importance.head(10)
        axes[0, 1].barh(range(len(top_chi2)), top_chi2.values)
        axes[0, 1].set_title('Top 10 Features - Chi-Square')
        axes[0, 1].set_yticks(range(len(top_chi2)))
        axes[0, 1].set_yticklabels(top_chi2.index)
        
        # Top features by correlation
        top_corr = corr_importance.head(10)
        axes[1, 0].barh(range(len(top_corr)), top_corr.values)
        axes[1, 0].set_title('Top 10 Features - Correlation')
        axes[1, 0].set_yticks(range(len(top_corr)))
        axes[1, 0].set_yticklabels(top_corr.index)
        
        # Composite ranking
        top_composite = importance_df['composite_score'].head(10)
        axes[1, 1].barh(range(len(top_composite)), top_composite.values)
        axes[1, 1].set_title('Top 10 Features - Composite Ranking')
        axes[1, 1].set_yticks(range(len(top_composite)))
        axes[1, 1].set_yticklabels(top_composite.index)
        
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/plots/feature_importance_analysis.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        # Save results
        importance_results = {
            'top_mutual_info': mi_importance.head(20).to_dict(),
            'top_chi_square': chi2_importance.head(20).to_dict(),
            'top_correlation': corr_importance.head(20).to_dict(),
            'top_composite': importance_df['composite_score'].head(20).to_dict()
        }
        
        with open(f"{self.output_dir}/feature_importance.json", 'w') as f:
            json.dump(importance_results, f, indent=2)
        
        self.results['feature_importance'] = importance_results
        print(f"✅ Feature importance analysis completed")
        print(f"   Top feature (composite): {importance_df.index[0]} (score: {importance_df['composite_score'].iloc[0]:.3f})")
    
    def text_analysis(self) -> None:
        """Analyze text-specific patterns and characteristics."""
        print("\n📝 Analyzing Text Patterns...")
        
        if 'subject' not in self.df.columns or 'body' not in self.df.columns:
            print("⚠️  Text columns not found, skipping text analysis")
            return
        
        # Text length analysis
        fig, axes = plt.subplots(2, 3, figsize=(18, 12))
        
        # Subject length distribution
        subject_lens_bills = self.df[self.df[self.target_col]]['subject'].str.len()
        subject_lens_not_bills = self.df[~self.df[self.target_col]]['subject'].str.len()
        
        axes[0, 0].hist(subject_lens_bills, bins=20, alpha=0.7, label='Bills', density=True)
        axes[0, 0].hist(subject_lens_not_bills, bins=20, alpha=0.7, label='Not Bills', density=True)
        axes[0, 0].set_title('Subject Length Distribution')
        axes[0, 0].set_xlabel('Characters')
        axes[0, 0].legend()
        
        # Body length distribution
        body_lens_bills = self.df[self.df[self.target_col]]['body'].str.len()
        body_lens_not_bills = self.df[~self.df[self.target_col]]['body'].str.len()
        
        axes[0, 1].hist(body_lens_bills, bins=20, alpha=0.7, label='Bills', density=True)
        axes[0, 1].hist(body_lens_not_bills, bins=20, alpha=0.7, label='Not Bills', density=True)
        axes[0, 1].set_title('Body Length Distribution')
        axes[0, 1].set_xlabel('Characters')
        axes[0, 1].legend()
        
        # Word count analysis
        subject_words_bills = self.df[self.df[self.target_col]]['subject'].str.split().str.len()
        subject_words_not_bills = self.df[~self.df[self.target_col]]['subject'].str.split().str.len()
        
        axes[0, 2].boxplot([subject_words_bills.dropna(), subject_words_not_bills.dropna()], 
                          labels=['Bills', 'Not Bills'])
        axes[0, 2].set_title('Subject Word Count')
        axes[0, 2].set_ylabel('Words')
        
        # Common words analysis
        all_subjects_bills = ' '.join(self.df[self.df[self.target_col]]['subject'].fillna(''))
        all_subjects_not_bills = ' '.join(self.df[~self.df[self.target_col]]['subject'].fillna(''))
        
        # Simple word frequency (excluding common stop words)
        stop_words = {'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by', 'is', 'are', 'was', 'were', 'your', 'you'}
        
        words_bills = [word.lower().strip('.,!?()[]') for word in all_subjects_bills.split() if word.lower() not in stop_words and len(word) > 2]
        words_not_bills = [word.lower().strip('.,!?()[]') for word in all_subjects_not_bills.split() if word.lower() not in stop_words and len(word) > 2]
        
        from collections import Counter
        top_words_bills = Counter(words_bills).most_common(10)
        top_words_not_bills = Counter(words_not_bills).most_common(10)
        
        # Plot top words for bills
        if top_words_bills:
            words, counts = zip(*top_words_bills)
            axes[1, 0].barh(range(len(words)), counts)
            axes[1, 0].set_title('Top Words in Bill Subjects')
            axes[1, 0].set_yticks(range(len(words)))
            axes[1, 0].set_yticklabels(words)
        
        # Plot top words for non-bills
        if top_words_not_bills:
            words, counts = zip(*top_words_not_bills)
            axes[1, 1].barh(range(len(words)), counts)
            axes[1, 1].set_title('Top Words in Non-Bill Subjects')
            axes[1, 1].set_yticks(range(len(words)))
            axes[1, 1].set_yticklabels(words)
        
        # Attachment analysis
        if 'attachment_count' in self.enhanced_df.columns:
            attachment_counts = self.enhanced_df.groupby(self.target_col)['attachment_count'].mean()
            axes[1, 2].bar(['Not Bills', 'Bills'], [attachment_counts[False], attachment_counts[True]])
            axes[1, 2].set_title('Average Attachment Count')
            axes[1, 2].set_ylabel('Attachments')
        
        plt.tight_layout()
        plt.savefig(f"{self.output_dir}/plots/text_analysis.png", dpi=300, bbox_inches='tight')
        plt.close()
        
        # Save text analysis results
        text_results = {
            'subject_length_stats': {
                'bills_mean': float(subject_lens_bills.mean()),
                'not_bills_mean': float(subject_lens_not_bills.mean()),
                'bills_std': float(subject_lens_bills.std()),
                'not_bills_std': float(subject_lens_not_bills.std())
            },
            'body_length_stats': {
                'bills_mean': float(body_lens_bills.mean()),
                'not_bills_mean': float(body_lens_not_bills.mean()),
                'bills_std': float(body_lens_bills.std()),
                'not_bills_std': float(body_lens_not_bills.std())
            },
            'top_words_bills': top_words_bills[:10],
            'top_words_not_bills': top_words_not_bills[:10]
        }
        
        with open(f"{self.output_dir}/text_analysis.json", 'w') as f:
            json.dump(text_results, f, indent=2)
        
        self.results['text_analysis'] = text_results
        print("✅ Text analysis completed")
    
    def generate_report(self) -> None:
        """Generate comprehensive EDA report."""
        print("\n📄 Generating EDA Report...")
        
        report = {
            'eda_metadata': {
                'generated_at': datetime.now().isoformat(),
                'dataset_path': self.data_path,
                'output_directory': self.output_dir,
                'analysis_version': '1.0'
            },
            'summary': {
                'total_samples': len(self.df),
                'total_features': self.enhanced_df.shape[1],
                'target_distribution': self.results.get('dataset_overview', {}).get('target_distribution', {}),
                'data_quality_score': self._calculate_data_quality_score(),
                'feature_engineering_impact': self._calculate_feature_impact()
            },
            'key_findings': self._extract_key_findings(),
            'recommendations': self._generate_recommendations(),
            'detailed_results': self.results
        }
        
        # Save comprehensive report
        with open(f"{self.output_dir}/eda_report.json", 'w') as f:
            json.dump(report, f, indent=2)
        
        # Generate markdown report
        self._generate_markdown_report(report)
        
        print(f"✅ EDA report saved to {self.output_dir}/eda_report.json")
        print(f"✅ Markdown report saved to {self.output_dir}/EDA_Report.md")
    
    def _calculate_data_quality_score(self) -> float:
        """Calculate overall data quality score."""
        if 'dataset_overview' not in self.results:
            return 0.5
        
        overview = self.results['dataset_overview']
        quality = overview.get('data_quality', {})
        
        # Factors that affect quality (lower is better)
        missing_penalty = min(quality.get('missing_values', 0) / len(self.df), 0.5)
        duplicate_penalty = min(quality.get('duplicate_rows', 0) / len(self.df), 0.3)
        
        # Factors that improve quality
        uniqueness_bonus = min(quality.get('unique_subjects', 0) / len(self.df), 0.2)
        
        score = 1.0 - missing_penalty - duplicate_penalty + uniqueness_bonus
        return max(0.0, min(1.0, score))
    
    def _calculate_feature_impact(self) -> float:
        """Calculate the impact of feature engineering."""
        original_features = self.df.shape[1]
        enhanced_features = self.enhanced_df.shape[1]
        return (enhanced_features - original_features) / original_features
    
    def _extract_key_findings(self) -> List[str]:
        """Extract key findings from the analysis."""
        findings = []
        
        if 'dataset_overview' in self.results:
            overview = self.results['dataset_overview']
            target = overview.get('target_distribution', {})
            
            # Class imbalance finding
            if target.get('class_imbalance_ratio', 1) > 3:
                findings.append(f"Significant class imbalance detected: {target.get('class_imbalance_ratio', 0):.1f}:1 ratio")
            
            # Dataset size finding
            if overview.get('basic_info', {}).get('total_samples', 0) < 1000:
                findings.append("Small dataset size may limit model performance and require careful validation")
        
        if 'feature_importance' in self.results:
            importance = self.results['feature_importance']
            top_feature = list(importance.get('top_composite', {}).keys())[0] if importance.get('top_composite') else None
            if top_feature:
                findings.append(f"Most predictive feature identified: {top_feature}")
        
        if 'correlation_analysis' in self.results:
            corr = self.results['correlation_analysis']
            if corr.get('correlation_statistics', {}).get('highly_correlated_pairs', 0) > 5:
                findings.append(f"High feature redundancy detected: {corr['correlation_statistics']['highly_correlated_pairs']} highly correlated pairs")
        
        return findings
    
    def _generate_recommendations(self) -> List[str]:
        """Generate actionable recommendations."""
        recommendations = []
        
        if 'dataset_overview' in self.results:
            overview = self.results['dataset_overview']
            
            # Data collection recommendations
            if overview.get('basic_info', {}).get('total_samples', 0) < 100:
                recommendations.append("Collect more data samples to improve model reliability (target: 1000+ samples)")
            
            # Class imbalance recommendations
            target = overview.get('target_distribution', {})
            if target.get('class_imbalance_ratio', 1) > 5:
                recommendations.append("Address class imbalance using SMOTE, class weights, or balanced sampling")
            
            # Data quality recommendations
            quality = overview.get('data_quality', {})
            if quality.get('missing_values', 0) > 0:
                recommendations.append("Implement missing value handling strategy before training")
        
        if 'correlation_analysis' in self.results:
            corr = self.results['correlation_analysis']
            if corr.get('correlation_statistics', {}).get('highly_correlated_pairs', 0) > 3:
                recommendations.append("Consider feature selection to remove redundant features")
        
        # General recommendations
        recommendations.extend([
            "Use cross-validation with stratification due to potential class imbalance",
            "Consider ensemble methods to improve classification performance",
            "Implement feature selection based on importance analysis",
            "Monitor for data leakage in temporal features"
        ])
        
        return recommendations
    
    def _generate_markdown_report(self, report: Dict[str, Any]) -> None:
        """Generate a markdown report for better readability."""
        markdown_content = f"""# Email Classification Dataset - EDA Report

**Generated:** {report['eda_metadata']['generated_at']}  
**Dataset:** {report['eda_metadata']['dataset_path']}

## Executive Summary

- **Total Samples:** {report['summary']['total_samples']:,}
- **Total Features:** {report['summary']['total_features']}
- **Data Quality Score:** {report['summary']['data_quality_score']:.2f}/1.0
- **Feature Engineering Impact:** +{report['summary']['feature_engineering_impact']:.1%} more features

### Target Distribution
- **Bills:** {report['summary']['target_distribution'].get('bills', 0)} ({report['summary']['target_distribution'].get('bill_percentage', 0):.1f}%)
- **Not Bills:** {report['summary']['target_distribution'].get('not_bills', 0)} ({100-report['summary']['target_distribution'].get('bill_percentage', 0):.1f}%)
- **Class Imbalance Ratio:** {report['summary']['target_distribution'].get('class_imbalance_ratio', 0):.2f}:1

## Key Findings

"""
        
        for finding in report['key_findings']:
            markdown_content += f"- {finding}\n"
        
        markdown_content += "\n## Recommendations\n\n"
        
        for rec in report['recommendations']:
            markdown_content += f"- {rec}\n"
        
        markdown_content += """
## Visualizations

The following plots have been generated:
- `target_distribution_analysis.png` - Target variable analysis
- `correlation_matrix.png` - Feature correlation heatmap
- `target_correlations.png` - Features most correlated with target
- `feature_importance_analysis.png` - Feature importance by multiple methods
- `text_analysis.png` - Text pattern analysis

## Files Generated

- `dataset_overview.json` - Basic dataset statistics
- `correlation_analysis.json` - Correlation analysis results
- `feature_importance.json` - Feature importance rankings
- `text_analysis.json` - Text pattern analysis
- `eda_report.json` - Complete analysis results
"""
        
        with open(f"{self.output_dir}/EDA_Report.md", 'w') as f:
            f.write(markdown_content)
    
    def run_complete_analysis(self) -> None:
        """Run the complete EDA pipeline."""
        print("🚀 Starting Comprehensive Email Dataset EDA")
        print("="*60)
        
        try:
            # Load and prepare data
            self.load_and_prepare_data()
            
            # Run analysis components
            self.dataset_overview()
            self.analyze_target_distribution()
            self.correlation_analysis()
            self.feature_importance_analysis()
            self.text_analysis()
            
            # Generate final report
            self.generate_report()
            
            print("\n" + "="*60)
            print("✅ EDA COMPLETED SUCCESSFULLY!")
            print("="*60)
            print(f"📁 Results saved to: {self.output_dir}/")
            print(f"📊 View plots in: {self.output_dir}/plots/")
            print(f"📄 Read report: {self.output_dir}/EDA_Report.md")
            
        except Exception as e:
            print(f"\n❌ EDA failed with error: {e}")
            raise


def main():
    """Main function to run EDA from command line."""
    parser = argparse.ArgumentParser(description="Comprehensive EDA for Email Classification Dataset")
    parser.add_argument("--data", required=True, help="Path to the labeled email dataset CSV")
    parser.add_argument("--output", default="eda_output", help="Output directory for results")
    
    args = parser.parse_args()
    
    # Run EDA
    eda = EmailDatasetEDA(args.data, args.output)
    eda.run_complete_analysis()


if __name__ == "__main__":
    main() 