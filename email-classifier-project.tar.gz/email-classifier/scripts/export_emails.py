#!/usr/bin/env python3
"""
Email Export Script

Connects to the Zero project's email infrastructure to export email data 
for training the bill classification model.

Usage:
    python scripts/export_emails.py --connection-id <conn_id> --max-emails 1000 --output data/emails.csv
"""

import asyncio
import argparse
import pandas as pd
import httpx
import json
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
import os
from dotenv import load_dotenv

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent))

from config.settings import settings

# Load environment variables
load_dotenv()


class ZeroEmailExporter:
    """Exports emails from Zero project for training data."""
    
    def __init__(self, base_url: str, api_key: Optional[str] = None):
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key
        self.session = httpx.AsyncClient(timeout=30.0)
        
    async def __aenter__(self):
        return self
        
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.session.aclose()
        
    def _get_headers(self) -> Dict[str, str]:
        """Get request headers with authentication."""
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "EmailClassifier/1.0"
        }
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers
    
    async def test_connection(self) -> bool:
        """Test connection to Zero project API."""
        try:
            response = await self.session.get(
                f"{self.base_url}/health",
                headers=self._get_headers()
            )
            return response.status_code == 200
        except Exception as e:
            print(f"❌ Connection test failed: {e}")
            return False
    
    async def get_email_threads(self, connection_id: str, folder: str = "inbox", 
                               max_results: int = 50, page_token: str = None) -> Dict[str, Any]:
        """Get email threads from Zero project."""
        try:
            # Use Zero project's TRPC endpoint for listing emails
            # This mimics the structure from the codebase search results
            params = {
                "folder": folder,
                "maxResults": max_results,
                "connectionId": connection_id
            }
            if page_token:
                params["pageToken"] = page_token
                
            response = await self.session.get(
                f"{self.base_url}/api/trpc/mail.list",
                params=params,
                headers=self._get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"❌ Failed to get emails: {response.status_code} - {response.text}")
                return {"threads": [], "nextPageToken": None}
                
        except Exception as e:
            print(f"❌ Error getting emails: {e}")
            return {"threads": [], "nextPageToken": None}
    
    async def get_thread_details(self, connection_id: str, thread_id: str) -> Optional[Dict[str, Any]]:
        """Get detailed thread information."""
        try:
            response = await self.session.get(
                f"{self.base_url}/api/trpc/mail.get",
                params={"threadId": thread_id, "connectionId": connection_id},
                headers=self._get_headers()
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"⚠️  Failed to get thread {thread_id}: {response.status_code}")
                return None
                
        except Exception as e:
            print(f"⚠️  Error getting thread {thread_id}: {e}")
            return None
    
    async def export_emails(self, connection_id: str, max_emails: int = 1000, 
                           folders: List[str] = None) -> List[Dict[str, Any]]:
        """Export emails from specified folders."""
        if folders is None:
            folders = ["inbox", "sent", "spam"]
        
        all_emails = []
        
        for folder in folders:
            print(f"📁 Exporting from folder: {folder}")
            page_token = None
            folder_count = 0
            
            while len(all_emails) < max_emails:
                # Get threads for this folder
                result = await self.get_email_threads(
                    connection_id=connection_id,
                    folder=folder,
                    max_results=min(50, max_emails - len(all_emails)),
                    page_token=page_token
                )
                
                threads = result.get("threads", [])
                if not threads:
                    print(f"  No more emails in {folder}")
                    break
                
                # Process each thread
                for thread in threads:
                    if len(all_emails) >= max_emails:
                        break
                        
                    thread_id = thread.get("id")
                    if not thread_id:
                        continue
                    
                    # Get detailed thread information
                    thread_details = await self.get_thread_details(connection_id, thread_id)
                    if not thread_details:
                        continue
                    
                    # Extract email messages from thread
                    messages = thread_details.get("messages", [])
                    latest = thread_details.get("latest")
                    
                    # Process the latest message (most relevant for classification)
                    if latest:
                        email_data = self._extract_email_data(latest, folder)
                        if email_data:
                            all_emails.append(email_data)
                            folder_count += 1
                
                # Check for next page
                page_token = result.get("nextPageToken")
                if not page_token:
                    break
                    
                print(f"  Exported {folder_count} emails from {folder} so far...")
            
            print(f"✅ Completed folder {folder}: {folder_count} emails")
        
        print(f"🎉 Total emails exported: {len(all_emails)}")
        return all_emails
    
    def _extract_email_data(self, message: Dict[str, Any], folder: str) -> Optional[Dict[str, Any]]:
        """Extract relevant data from email message."""
        try:
            # Extract basic fields
            subject = message.get("subject", "").strip()
            body = message.get("decodedBody", "") or message.get("body", "")
            
            # Skip emails without subject or body
            if not subject and not body:
                return None
            
            # Extract sender information
            sender = message.get("sender", {})
            sender_email = sender.get("email", "") if sender else ""
            sender_name = sender.get("name", "") if sender else ""
            
            # Extract recipient information
            to_emails = []
            if message.get("to"):
                to_emails = [r.get("email", "") for r in message["to"] if r.get("email")]
            
            cc_emails = []
            if message.get("cc"):
                cc_emails = [r.get("email", "") for r in message["cc"] if r.get("email")]
            
            # Extract other metadata
            received_date = message.get("receivedOn") or message.get("receivedDateTime")
            attachments = []
            if message.get("attachments"):
                attachments = [att.get("filename", "") for att in message["attachments"]]
            
            # Determine potential bill indicators
            bill_keywords = self._extract_bill_features(subject, body, sender_email)
            
            return {
                "id": message.get("id", ""),
                "thread_id": message.get("threadId", ""),
                "subject": subject,
                "body": body[:2000],  # Limit body length
                "sender_email": sender_email,
                "sender_name": sender_name,
                "to_emails": ",".join(to_emails),
                "cc_emails": ",".join(cc_emails),
                "received_date": received_date,
                "folder": folder,
                "attachments": ",".join(attachments),
                "attachment_count": len(attachments),
                "unread": message.get("unread", False),
                # Feature indicators
                "has_amount": bill_keywords["has_amount"],
                "has_payment_terms": bill_keywords["has_payment_terms"],
                "has_due_date": bill_keywords["has_due_date"],
                "sender_domain": sender_email.split("@")[-1] if "@" in sender_email else "",
                "word_count": len(body.split()) if body else 0,
                "exported_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            print(f"⚠️  Error extracting email data: {e}")
            return None
    
    def _extract_bill_features(self, subject: str, body: str, sender_email: str) -> Dict[str, bool]:
        """Extract features that might indicate a bill."""
        text = f"{subject} {body}".lower()
        
        # Amount patterns
        amount_patterns = ["$", "€", "£", "amount", "total", "balance", "payment", "charge"]
        has_amount = any(pattern in text for pattern in amount_patterns)
        
        # Payment terms
        payment_patterns = ["due", "invoice", "bill", "statement", "payment", "overdue", "reminder"]
        has_payment_terms = any(pattern in text for pattern in payment_patterns)
        
        # Due date patterns
        due_patterns = ["due date", "payment due", "expires", "deadline", "before"]
        has_due_date = any(pattern in text for pattern in due_patterns)
        
        return {
            "has_amount": has_amount,
            "has_payment_terms": has_payment_terms,
            "has_due_date": has_due_date
        }


async def main():
    """Main export function."""
    parser = argparse.ArgumentParser(description="Export emails from Zero project for training")
    parser.add_argument("--connection-id", required=True, help="Zero project connection ID")
    parser.add_argument("--max-emails", type=int, default=1000, help="Maximum emails to export")
    parser.add_argument("--output", default="data/emails.csv", help="Output CSV file path")
    parser.add_argument("--folders", nargs="+", default=["inbox", "sent"], help="Folders to export from")
    parser.add_argument("--base-url", default=None, help="Zero project base URL (overrides config)")
    parser.add_argument("--api-key", default=None, help="API key for authentication")
    
    args = parser.parse_args()
    
    # Use command line args or fall back to settings
    base_url = args.base_url or settings.zero_api_base_url
    api_key = args.api_key or settings.zero_api_key
    
    print(f"🚀 Starting email export...")
    print(f"   Connection ID: {args.connection_id}")
    print(f"   Max emails: {args.max_emails}")
    print(f"   Output: {args.output}")
    print(f"   Folders: {args.folders}")
    print(f"   Base URL: {base_url}")
    
    # Create output directory
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    # Export emails
    async with ZeroEmailExporter(base_url, api_key) as exporter:
        # Test connection first
        if not await exporter.test_connection():
            print("❌ Failed to connect to Zero project. Please check your configuration.")
            return
        
        print("✅ Connected to Zero project")
        
        # Export emails
        emails = await exporter.export_emails(
            connection_id=args.connection_id,
            max_emails=args.max_emails,
            folders=args.folders
        )
        
        if not emails:
            print("❌ No emails exported")
            return
        
        # Save to CSV
        df = pd.DataFrame(emails)
        df.to_csv(args.output, index=False)
        print(f"✅ Saved {len(emails)} emails to {args.output}")
        
        # Print summary statistics
        print("\n📊 Export Summary:")
        print(f"   Total emails: {len(emails)}")
        print(f"   Folders: {df['folder'].value_counts().to_dict()}")
        print(f"   Unique senders: {df['sender_email'].nunique()}")
        print(f"   Emails with amounts: {df['has_amount'].sum()}")
        print(f"   Emails with payment terms: {df['has_payment_terms'].sum()}")
        print(f"   Emails with due dates: {df['has_due_date'].sum()}")


if __name__ == "__main__":
    asyncio.run(main()) 