#!/usr/bin/env python3
"""
GPT Email Classification Script

Uses GPT to classify exported emails as bills or not bills, generating 
high-quality training data for the lightweight model.

Usage:
    python scripts/classify_with_gpt.py --input data/emails.csv --output data/labeled_emails.csv --batch-size 10
"""

import asyncio
import argparse
import pandas as pd
import json
import sys
from pathlib import Path
from typing import List, Dict, Any, Optional
from datetime import datetime
import os
from dotenv import load_dotenv
import openai
from openai import AsyncOpenAI
import time
from tqdm.asyncio import tqdm

# Load environment variables
load_dotenv()


class GPTEmailClassifier:
    """Classifies emails using GPT to generate training data."""
    
    def __init__(self, api_key: str, model: str = "gpt-4o"):
        self.client = AsyncOpenAI(api_key=api_key)
        self.model = model
        self.rate_limit_delay = 1.0  # Seconds between requests
        
    def _safe_strip(self, value):
        """Safely convert to string and strip, handling NaN/None/float values"""
        import pandas as pd
        if pd.isna(value) or value is None:
            return ""
        return str(value).strip()
    def _create_classification_prompt(self, email_data: Dict[str, Any]) -> str:
        """Create a detailed prompt for GPT classification."""
        
        subject = self._safe_strip(email_data.get("subject", ""))
        body = self._safe_strip(email_data.get("body", ""))
        sender_email = self._safe_strip(email_data.get("sender_email", ""))
        sender_name = self._safe_strip(email_data.get("sender_name", ""))
        attachments = email_data.get("attachments", "")
        
        prompt = f"""Analyze this email and determine if it represents a BILL TO PAY (requiring immediate payment action) vs NOT A BILL.

EMAIL DETAILS:
Subject: {subject}
From: {sender_name} <{sender_email}>
Body: {body[:1500]}...
Attachments: {attachments if attachments else "None"}

CLASSIFICATION CRITERIA:
🔴 BILL TO PAY (answer "YES") - Examples:
- Utility bills (electricity, gas, water, internet)
- Credit card statements requiring payment
- Invoice requiring payment within timeframe
- Subscription payment reminders (Netflix, Spotify, etc.)
- Loan payments, mortgage payments
- Medical bills requiring payment
- Tax payment notices
- Overdue payment reminders
- Service invoices (plumber, contractor, etc.)

🟢 NOT A BILL (answer "NO") - Examples:
- Receipts for already completed payments
- Order confirmations (already paid)
- Shipping notifications
- Account statements without payment required
- Marketing emails
- Newsletters
- Social media notifications
- Promotional offers
- Welcome emails
- Password reset emails
- General informational emails

ANALYSIS STEPS:
1. Does this email require ME to take a payment action?
2. Is there a specific amount to pay and due date?
3. Is this a reminder or notice about money I owe?
4. Is this actionable vs just informational?

Respond in JSON format:
{{
    "is_bill": true/false,
    "confidence": 0.0-1.0,
    "reasoning": "Explain your decision in 1-2 sentences focusing on why this requires/doesn't require payment action",
    "key_indicators": ["list", "of", "key", "phrases", "or", "indicators"],
    "amount_mentioned": "any dollar amount if found, or null",
    "due_date_mentioned": "any due date if found, or null"
}}"""
        
        return prompt
    
    async def classify_email(self, email_data: Dict[str, Any]) -> Dict[str, Any]:
        """Classify a single email using GPT."""
        try:
            prompt = self._create_classification_prompt(email_data)
            
            response = await self.client.chat.completions.create(
                model=self.model,
                messages=[
                    {
                        "role": "system",
                        "content": "You are an expert email classifier specializing in identifying bills that require payment action. Be precise and consistent in your classifications."
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.1,  # Low temperature for consistency
                max_tokens=500,
                response_format={"type": "json_object"}
            )
            
            # Parse the JSON response
            result = json.loads(response.choices[0].message.content)
            
            # Add original email ID for tracking
            result["email_id"] = email_data.get("id", "")
            result["classified_at"] = datetime.utcnow().isoformat()
            
            # Rate limiting
            await asyncio.sleep(self.rate_limit_delay)
            
            return result
            
        except Exception as e:
            print(f"❌ Error classifying email {email_data.get('id', 'unknown')}: {e}")
            return {
                "email_id": email_data.get("id", ""),
                "is_bill": False,
                "confidence": 0.0,
                "reasoning": f"Classification failed: {str(e)}",
                "key_indicators": [],
                "amount_mentioned": None,
                "due_date_mentioned": None,
                "classified_at": datetime.utcnow().isoformat(),
                "error": True
            }
    
    async def classify_batch(self, emails: List[Dict[str, Any]], 
                           batch_size: int = 10) -> List[Dict[str, Any]]:
        """Classify a batch of emails with progress tracking."""
        results = []
        
        # Process in smaller batches to respect rate limits
        for i in range(0, len(emails), batch_size):
            batch = emails[i:i + batch_size]
            
            print(f"📊 Processing batch {i//batch_size + 1}/{(len(emails) + batch_size - 1)//batch_size}")
            
            # Create tasks for this batch
            tasks = [self.classify_email(email) for email in batch]
            
            # Execute batch with progress bar
            batch_results = []
            for task in tqdm(tasks, desc=f"Batch {i//batch_size + 1}"):
                result = await task
                batch_results.append(result)
            
            results.extend(batch_results)
            
            # Longer delay between batches
            if i + batch_size < len(emails):
                print(f"⏱️  Waiting 5 seconds before next batch...")
                await asyncio.sleep(5)
        
        return results
    
    def analyze_classifications(self, results: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze the classification results and provide statistics."""
        total = len(results)
        bills = sum(1 for r in results if r.get("is_bill", False))
        not_bills = total - bills
        errors = sum(1 for r in results if r.get("error", False))
        
        # Confidence statistics
        confidences = [r.get("confidence", 0) for r in results if not r.get("error")]
        avg_confidence = sum(confidences) / len(confidences) if confidences else 0
        
        # Amount and due date statistics
        amounts_found = sum(1 for r in results if r.get("amount_mentioned"))
        due_dates_found = sum(1 for r in results if r.get("due_date_mentioned"))
        
        return {
            "total_emails": total,
            "bills_count": bills,
            "not_bills_count": not_bills,
            "bill_percentage": (bills / total * 100) if total > 0 else 0,
            "errors_count": errors,
            "average_confidence": avg_confidence,
            "amounts_detected": amounts_found,
            "due_dates_detected": due_dates_found
        }


def merge_classifications_with_emails(emails_df: pd.DataFrame, 
                                    classifications: List[Dict[str, Any]]) -> pd.DataFrame:
    """Merge GPT classifications with original email data."""
    
    # Convert classifications to DataFrame
    classifications_df = pd.DataFrame(classifications)
    
    # Merge with original data
    merged_df = emails_df.merge(
        classifications_df, 
        left_on="id", 
        right_on="email_id", 
        how="left"
    )
    
    # Clean up columns
    merged_df.drop(columns=["email_id"], inplace=True, errors="ignore")
    
    # Add label column for training
    merged_df["label"] = merged_df["is_bill"].astype(int)
    
    return merged_df


async def main():
    """Main classification function."""
    parser = argparse.ArgumentParser(description="Classify emails using GPT for training data")
    parser.add_argument("--input", required=True, help="Input CSV file with exported emails")
    parser.add_argument("--output", required=True, help="Output CSV file with classifications")
    parser.add_argument("--batch-size", type=int, default=10, help="Batch size for processing")
    parser.add_argument("--max-emails", type=int, default=None, help="Maximum emails to process")
    parser.add_argument("--api-key", default=None, help="OpenAI API key (overrides config)")
    parser.add_argument("--model", default="gpt-4o", help="OpenAI model to use")
    parser.add_argument("--filter-folders", nargs="+", default=None, help="Only process emails from these folders")
    
    args = parser.parse_args()
    
    # Validate input file
    if not os.path.exists(args.input):
        print(f"❌ Input file not found: {args.input}")
        return
    
    # Get API key
    api_key = args.api_key or os.getenv('OPENAI_API_KEY')
    if not api_key:
        print("❌ OpenAI API key not provided. Set OPENAI_API_KEY environment variable or use --api-key")
        return
    
    print(f"🚀 Starting GPT email classification...")
    print(f"   Input: {args.input}")
    print(f"   Output: {args.output}")
    print(f"   Model: {args.model}")
    print(f"   Batch size: {args.batch_size}")
    
    # Load email data
    print("📂 Loading email data...")
    emails_df = pd.read_csv(args.input)
    print(f"   Loaded {len(emails_df)} emails")
    
    # Filter by folders if specified
    if args.filter_folders:
        emails_df = emails_df[emails_df["folder"].isin(args.filter_folders)]
        print(f"   Filtered to {len(emails_df)} emails from folders: {args.filter_folders}")
    
    # Limit number of emails if specified
    if args.max_emails:
        emails_df = emails_df.head(args.max_emails)
        print(f"   Limited to {len(emails_df)} emails")
    
    if len(emails_df) == 0:
        print("❌ No emails to process")
        return
    
    # Initialize classifier
    classifier = GPTEmailClassifier(api_key, args.model)
    
    # Convert to list of dictionaries
    emails_list = emails_df.to_dict("records")
    
    print(f"🤖 Starting classification with GPT...")
    start_time = time.time()
    
    # Classify emails
    classifications = await classifier.classify_batch(emails_list, args.batch_size)
    
    end_time = time.time()
    
    print(f"✅ Classification completed in {end_time - start_time:.2f} seconds")
    
    # Analyze results
    analysis = classifier.analyze_classifications(classifications)
    
    print("\n📊 Classification Analysis:")
    print(f"   Total emails: {analysis['total_emails']}")
    print(f"   Bills: {analysis['bills_count']} ({analysis['bill_percentage']:.1f}%)")
    print(f"   Not bills: {analysis['not_bills_count']}")
    print(f"   Errors: {analysis['errors_count']}")
    print(f"   Average confidence: {analysis['average_confidence']:.3f}")
    print(f"   Amounts detected: {analysis['amounts_detected']}")
    print(f"   Due dates detected: {analysis['due_dates_detected']}")
    
    # Merge with original data
    print("🔗 Merging classifications with email data...")
    labeled_df = merge_classifications_with_emails(emails_df, classifications)
    
    # Create output directory
    os.makedirs(os.path.dirname(args.output), exist_ok=True)
    
    # Save results
    labeled_df.to_csv(args.output, index=False)
    print(f"✅ Saved {len(labeled_df)} labeled emails to {args.output}")
    
    # Save classification analysis
    analysis_file = args.output.replace('.csv', '_analysis.json')
    with open(analysis_file, 'w') as f:
        json.dump(analysis, f, indent=2)
    print(f"✅ Saved analysis to {analysis_file}")
    
    # Show sample of results
    print("\n📋 Sample Classifications:")
    sample_df = labeled_df[["subject", "sender_email", "is_bill", "confidence", "reasoning"]].head(5)
    print(sample_df.to_string(index=False, max_colwidth=50))


if __name__ == "__main__":
    asyncio.run(main()) 