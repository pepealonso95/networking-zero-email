#!/usr/bin/env python3
"""
Interactive Gmail Email Downloader for Email Classification Dataset

This script prompts you to log in to Gmail directly and downloads your emails
to expand the email classification dataset.

Features:
- Interactive OAuth login (opens browser)
- Downloads real emails from your Gmail account
- Processes emails with enhanced text features
- Labels emails using GPT classification
- Expands your classification dataset

Usage:
    python scripts/download_my_gmail_emails.py --max-emails 100 --days-back 30
"""

import argparse
import json
import logging
import os
import sys
from datetime import datetime, timedelta
from pathlib import Path
from typing import Dict, List, Optional

import pandas as pd
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError
from dotenv import load_dotenv

# Add the app directory to the path
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'app'))

from models.enhanced_text_processor import EnhancedTextProcessor

# Add current directory for GPT classifier
sys.path.append(str(Path(__file__).parent))
from classify_with_gpt import GPTEmailClassifier

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('logs/gmail_download.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# Gmail API scopes
SCOPES = [
    'https://www.googleapis.com/auth/gmail.readonly',
    'https://www.googleapis.com/auth/userinfo.profile',
    'https://www.googleapis.com/auth/userinfo.email',
    'openid'
]

class InteractiveGmailDownloader:
    """Downloads emails from Gmail using interactive OAuth authentication."""
    
    def __init__(self, openai_api_key: str):
        """Initialize the Gmail downloader.
        
        Args:
            openai_api_key: OpenAI API key for GPT classification
        """
        self.openai_api_key = openai_api_key
        self.text_processor = EnhancedTextProcessor()
        self.gpt_classifier = GPTEmailClassifier(openai_api_key)
        self.gmail_service = None
        self.credentials = None
        self.processed_count = 0
        self.labeled_count = 0
        
        # Credentials file path
        self.token_file = 'credentials/gmail_token.json'
        self.credentials_file = 'credentials/gmail_credentials.json'
        
        # Ensure credentials directory exists
        os.makedirs('credentials', exist_ok=True)
    
    def setup_credentials(self) -> bool:
        """Set up Gmail API credentials with interactive OAuth flow."""
        
        # Check for Google OAuth credentials in environment
        client_id = os.getenv('GOOGLE_CLIENT_ID')
        client_secret = os.getenv('GOOGLE_CLIENT_SECRET')
        
        if not client_id or not client_secret:
            logger.error("❌ Missing Google OAuth credentials!")
            logger.error("Please set GOOGLE_CLIENT_ID and GOOGLE_CLIENT_SECRET environment variables")
            logger.error("Get these from: https://console.cloud.google.com/apis/credentials")
            return False
        
        # Store credentials for direct use
        self.client_id = client_id
        self.client_secret = client_secret
        
        return True
    
    def authenticate_gmail(self) -> bool:
        """Authenticate with Gmail using OAuth flow."""
        try:
            if not self.setup_credentials():
                return False
            
            creds = None
            
            # Load existing token if it exists
            if os.path.exists(self.token_file):
                creds = Credentials.from_authorized_user_file(self.token_file, SCOPES)
                logger.info("📱 Found existing Gmail credentials")
            
            # If there are no valid credentials, go through OAuth flow
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    logger.info("🔄 Refreshing expired Gmail credentials...")
                    creds.refresh(Request())
                else:
                    logger.info("🌐 Starting interactive Gmail login...")
                    logger.info("📋 This will open your browser for Gmail authentication")
                    logger.info("🔐 Please log in to the Gmail account you want to download from")
                    
                    # Start OAuth flow using client config
                    client_config = {
                        "installed": {
                            "client_id": self.client_id,
                            "client_secret": self.client_secret,
                            "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                            "token_uri": "https://oauth2.googleapis.com/token",
                            "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
                            "redirect_uris": ["http://localhost:8081/"]
                        }
                    }
                    
                    flow = InstalledAppFlow.from_client_config(client_config, SCOPES)
                    creds = flow.run_local_server(port=8081)
                
                # Save credentials for future use
                with open(self.token_file, 'w') as token:
                    token.write(creds.to_json())
                logger.info("✅ Gmail credentials saved for future use")
            
            # Build Gmail service
            self.gmail_service = build('gmail', 'v1', credentials=creds)
            self.credentials = creds
            
            # Get user info to confirm connection
            profile = self.gmail_service.users().getProfile(userId='me').execute()
            email_address = profile.get('emailAddress', 'Unknown')
            total_messages = profile.get('messagesTotal', 0)
            
            logger.info(f"✅ Successfully connected to Gmail account: {email_address}")
            logger.info(f"📧 Total messages in account: {total_messages:,}")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Gmail authentication failed: {str(e)}")
            return False
    
    def download_emails(self, max_emails: int = 100, days_back: int = 30, 
                       folder: str = 'INBOX') -> List[Dict]:
        """Download emails from Gmail.
        
        Args:
            max_emails: Maximum number of emails to download
            days_back: How many days back to search
            folder: Gmail folder to search (INBOX, SENT, etc.)
            
        Returns:
            List of email data dictionaries
        """
        if not self.gmail_service:
            logger.error("❌ Gmail service not initialized")
            return []
        
        emails = []
        
        try:
            # Calculate date range
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            # Build search query
            query = f"after:{start_date.strftime('%Y/%m/%d')} before:{end_date.strftime('%Y/%m/%d')}"
            
            # Add folder filter
            if folder != 'INBOX':
                query += f" in:{folder.lower()}"
            
            logger.info(f"🔍 Searching for emails: {query}")
            logger.info(f"📂 Folder: {folder}")
            logger.info(f"📅 Date range: {start_date.strftime('%Y-%m-%d')} to {end_date.strftime('%Y-%m-%d')}")
            
            # Get list of messages
            results = self.gmail_service.users().messages().list(
                userId='me',
                q=query,
                maxResults=max_emails,
                labelIds=[folder] if folder != 'ALL' else None
            ).execute()
            
            messages = results.get('messages', [])
            logger.info(f"📧 Found {len(messages)} messages to download")
            
            if not messages:
                logger.warning("⚠️ No messages found matching your criteria")
                return []
            
            # Download each message
            for i, message in enumerate(messages):
                if i >= max_emails:
                    break
                
                try:
                    msg = self.gmail_service.users().messages().get(
                        userId='me',
                        id=message['id'],
                        format='full'
                    ).execute()
                    
                    email_data = self.parse_gmail_message(msg)
                    if email_data:
                        emails.append(email_data)
                        self.processed_count += 1
                        
                        if (i + 1) % 10 == 0:
                            logger.info(f"📥 Downloaded {i + 1}/{len(messages)} emails")
                        
                except HttpError as e:
                    logger.warning(f"⚠️ Error downloading message {message['id']}: {str(e)}")
                    continue
                except Exception as e:
                    logger.warning(f"⚠️ Unexpected error downloading message {message['id']}: {str(e)}")
                    continue
            
            logger.info(f"✅ Successfully downloaded {len(emails)} emails")
            return emails
            
        except Exception as e:
            logger.error(f"❌ Error downloading emails: {str(e)}")
            return []
    
    def parse_gmail_message(self, msg: Dict) -> Optional[Dict]:
        """Parse Gmail API message into our email format."""
        try:
            headers = msg['payload'].get('headers', [])
            header_dict = {h['name'].lower(): h['value'] for h in headers}
            
            # Extract basic email info
            subject = header_dict.get('subject', '(no subject)')
            from_header = header_dict.get('from', '')
            date_header = header_dict.get('date', '')
            to_header = header_dict.get('to', '')
            
            # Parse sender info
            sender_email = ''
            sender_name = ''
            if from_header:
                if '<' in from_header and '>' in from_header:
                    # Format: "Name <email@domain.com>"
                    sender_name = from_header.split('<')[0].strip().strip('"')
                    sender_email = from_header.split('<')[1].split('>')[0].strip()
                else:
                    # Format: "email@domain.com"
                    sender_email = from_header.strip()
            
            # Extract body
            body = self.extract_email_body(msg['payload'])
            
            # Count attachments
            attachment_count = self.count_attachments(msg['payload'])
            
            # Determine if HTML
            html_body = self.has_html_content(msg['payload'])
            
            # Parse timestamp
            timestamp = self.parse_email_date(date_header)
            
            # Get labels
            labels = msg.get('labelIds', [])
            
            email_data = {
                'id': msg['id'],
                'subject': subject,
                'body': body,
                'sender_email': sender_email,
                'sender_name': sender_name,
                'to_emails': [to_header] if to_header else [],
                'attachment_count': attachment_count,
                'html_body': html_body,
                'timestamp': timestamp,
                'thread_id': msg.get('threadId', ''),
                'labels': labels,
                'received_date': timestamp
            }
            
            return email_data
            
        except Exception as e:
            logger.warning(f"⚠️ Error parsing message: {str(e)}")
            return None
    
    def extract_email_body(self, payload: Dict) -> str:
        """Extract email body text from Gmail payload."""
        try:
            # Check if the payload has a body
            if 'body' in payload and payload['body'].get('data'):
                import base64
                return base64.urlsafe_b64decode(
                    payload['body']['data'] + '===='
                ).decode('utf-8', errors='ignore')
            
            # Check for multipart content
            if 'parts' in payload:
                for part in payload['parts']:
                    if part.get('mimeType') == 'text/plain':
                        if 'body' in part and part['body'].get('data'):
                            import base64
                            return base64.urlsafe_b64decode(
                                part['body']['data'] + '===='
                            ).decode('utf-8', errors='ignore')
                    
                    # Recursively search in nested parts
                    if 'parts' in part:
                        nested_body = self.extract_email_body(part)
                        if nested_body:
                            return nested_body
            
            return ''
            
        except Exception as e:
            logger.warning(f"⚠️ Error extracting email body: {str(e)}")
            return ''
    
    def count_attachments(self, payload: Dict) -> int:
        """Count attachments in Gmail payload."""
        count = 0
        
        def count_recursive(part):
            nonlocal count
            if part.get('filename') and part['filename']:
                # Check if it's not an inline image
                disposition = ''
                if 'headers' in part:
                    for header in part['headers']:
                        if header['name'].lower() == 'content-disposition':
                            disposition = header['value'].lower()
                            break
                
                if 'inline' not in disposition:
                    count += 1
            
            if 'parts' in part:
                for subpart in part['parts']:
                    count_recursive(subpart)
        
        count_recursive(payload)
        return count
    
    def has_html_content(self, payload: Dict) -> bool:
        """Check if email has HTML content."""
        def check_recursive(part):
            if part.get('mimeType') == 'text/html':
                return True
            if 'parts' in part:
                for subpart in part['parts']:
                    if check_recursive(subpart):
                        return True
            return False
        
        return check_recursive(payload)
    
    def parse_email_date(self, date_str: str) -> str:
        """Parse email date string to ISO format."""
        try:
            from email.utils import parsedate_to_datetime
            dt = parsedate_to_datetime(date_str)
            return dt.isoformat()
        except:
            return datetime.now().isoformat()
    
    async def process_and_label_emails(self, emails: List[Dict]) -> List[Dict]:
        """Process emails through text processing and GPT labeling."""
        labeled_emails = []
        
        logger.info(f"🧠 Starting enhanced text processing and GPT classification...")
        
        for i, email_data in enumerate(emails):
            try:
                logger.info(f"📝 Processing email {i+1}/{len(emails)}: {email_data['subject'][:50]}...")
                
                # Apply enhanced text processing
                processed_email = self.text_processor.process_email(email_data)
                
                # Create classification request format
                classification_request = {
                    'id': email_data.get('id', str(i)),
                    'subject': email_data['subject'],
                    'body': email_data['body'],
                    'sender_email': email_data['sender_email'],
                    'sender_name': email_data['sender_name'],
                    'attachment_count': email_data['attachment_count']
                }
                
                # Get GPT classification
                classification_result = await self.gpt_classifier.classify_email(classification_request)
                
                # Combine all data
                final_email = {
                    **email_data,
                    **processed_email,
                    'is_bill': classification_result['is_bill'],
                    'confidence': classification_result['confidence'],
                    'reasoning': classification_result['reasoning'],
                    'key_indicators': str(classification_result['key_indicators']),
                    'amount_mentioned': classification_result.get('amount_mentioned', ''),
                    'due_date_mentioned': classification_result.get('due_date_mentioned', ''),
                    'classified_at': datetime.now().isoformat(),
                    'label': 1 if classification_result['is_bill'] else 0
                }
                
                labeled_emails.append(final_email)
                self.labeled_count += 1
                
                # Show progress every 5 emails
                if (i + 1) % 5 == 0:
                    logger.info(f"✅ Processed and labeled {i + 1}/{len(emails)} emails")
                    
            except Exception as e:
                logger.error(f"❌ Error processing email {i+1}: {str(e)}")
                continue
        
        logger.info(f"🎉 Successfully labeled {len(labeled_emails)} emails")
        return labeled_emails
    
    def save_to_dataset(self, labeled_emails: List[Dict], output_file: str = 'data/labeled_emails.csv'):
        """Save labeled emails to the dataset CSV file."""
        try:
            # Ensure data directory exists
            os.makedirs(os.path.dirname(output_file), exist_ok=True)
            
            # Load existing dataset if it exists
            existing_df = pd.DataFrame()
            if os.path.exists(output_file):
                existing_df = pd.read_csv(output_file)
                logger.info(f"📊 Loaded existing dataset with {len(existing_df)} emails")
            
            # Convert new emails to DataFrame
            new_df = pd.DataFrame(labeled_emails)
            
            # Combine datasets
            if not existing_df.empty:
                # Get the next ID
                next_id = existing_df['id'].max() + 1 if 'id' in existing_df.columns else 1
                
                # Assign new IDs to new emails (Gmail IDs are strings, so use a separate numeric ID)
                new_df['dataset_id'] = range(next_id, next_id + len(new_df))
                
                # Combine DataFrames
                combined_df = pd.concat([existing_df, new_df], ignore_index=True)
            else:
                # First time - assign IDs starting from 1
                new_df['dataset_id'] = range(1, len(new_df) + 1)
                combined_df = new_df
            
            # Remove duplicates based on Gmail message ID
            combined_df = combined_df.drop_duplicates(subset=['id'], keep='first')
            
            # Save to CSV
            combined_df.to_csv(output_file, index=False)
            
            logger.info(f"💾 Dataset saved to {output_file}")
            logger.info(f"📈 Total emails in dataset: {len(combined_df)}")
            logger.info(f"🆕 New emails added: {len(new_df)}")
            
            # Show dataset statistics
            bills_count = len(combined_df[combined_df['label'] == 1])
            non_bills_count = len(combined_df[combined_df['label'] == 0])
            logger.info(f"📊 Bills: {bills_count}, Non-bills: {non_bills_count}")
            logger.info(f"📈 Bill percentage: {bills_count/len(combined_df)*100:.1f}%")
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Error saving dataset: {str(e)}")
            return False
    
    def generate_summary_report(self) -> Dict:
        """Generate a summary report of the download and labeling process."""
        return {
            'timestamp': datetime.now().isoformat(),
            'emails_processed': self.processed_count,
            'emails_labeled': self.labeled_count,
            'success_rate': (self.labeled_count / self.processed_count * 100) if self.processed_count > 0 else 0
        }

async def main():
    """Main function to run the interactive Gmail email downloader."""
    parser = argparse.ArgumentParser(description='Download your Gmail emails for classification dataset')
    parser.add_argument('--max-emails', type=int, default=50, help='Maximum number of emails to download')
    parser.add_argument('--days-back', type=int, default=30, help='Number of days back to search')
    parser.add_argument('--folder', default='INBOX', help='Gmail folder to download from (INBOX, SENT, ALL)')
    parser.add_argument('--openai-api-key', help='OpenAI API key (defaults to env var)')
    parser.add_argument('--output-file', default='data/my_gmail_dataset.csv', help='Output CSV file path')
    
    args = parser.parse_args()
    
    # Get OpenAI API key
    openai_api_key = args.openai_api_key or os.getenv('OPENAI_API_KEY')
    
    if not openai_api_key:
        logger.error("❌ OPENAI_API_KEY must be provided via --openai-api-key or environment variable")
        return 1
    
    # Ensure required directories exist
    os.makedirs('data', exist_ok=True)
    os.makedirs('logs', exist_ok=True)
    os.makedirs('credentials', exist_ok=True)
    
    try:
        # Initialize the downloader
        downloader = InteractiveGmailDownloader(openai_api_key)
        
        # Authenticate with Gmail
        logger.info("🔐 Starting Gmail authentication...")
        if not downloader.authenticate_gmail():
            logger.error("❌ Failed to authenticate with Gmail")
            return 1
        
        # Download emails
        logger.info(f"📥 Downloading up to {args.max_emails} emails from {args.folder}...")
        emails = downloader.download_emails(args.max_emails, args.days_back, args.folder)
        if not emails:
            logger.warning("⚠️ No emails downloaded")
            return 1
        
        # Process and label emails
        logger.info("🧠 Processing and labeling emails with GPT...")
        labeled_emails = await downloader.process_and_label_emails(emails)
        if not labeled_emails:
            logger.warning("⚠️ No emails were successfully labeled")
            return 1
        
        # Save to dataset
        logger.info("💾 Saving to dataset...")
        if not downloader.save_to_dataset(labeled_emails, args.output_file):
            logger.error("❌ Failed to save dataset")
            return 1
        
        # Generate summary report
        summary = downloader.generate_summary_report()
        logger.info("📋 Summary Report:")
        logger.info(f"  📧 Emails processed: {summary['emails_processed']}")
        logger.info(f"  🏷️  Emails labeled: {summary['emails_labeled']}")
        logger.info(f"  ✅ Success rate: {summary['success_rate']:.1f}%")
        
        # Save summary to file
        summary_file = 'logs/download_summary.json'
        with open(summary_file, 'w') as f:
            json.dump(summary, f, indent=2)
        logger.info(f"📄 Summary saved to {summary_file}")
        
        logger.info("🎉 Gmail email download and labeling completed successfully!")
        return 0
        
    except Exception as e:
        logger.error(f"💥 Fatal error: {str(e)}")
        return 1

if __name__ == '__main__':
    import asyncio
    exit(asyncio.run(main())) 