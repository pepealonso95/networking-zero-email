#!/usr/bin/env python3
"""
Hyperparameter Tuning for Email Classification Models

This script performs systematic hyperparameter optimization for the best performing
email classification models using different search strategies and evaluation metrics.

Usage:
    python scripts/hyperparameter_tuning.py --variant selected --models logistic_regression random_forest
"""

import sys
import os
import argparse
import pandas as pd
import numpy as np
import json
import logging
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Tuple, Any

# ML libraries
from sklearn.model_selection import (
    train_test_split, GridSearchCV, RandomizedSearchCV, 
    StratifiedKFold, cross_val_score
)
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.svm import SVC
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import (
    classification_report, confusion_matrix, 
    f1_score, roc_auc_score, precision_score, recall_score
)
from sklearn.preprocessing import StandardScaler
from sklearn.utils.class_weight import compute_class_weight

# Statistical libraries
from scipy.stats import randint, uniform
import warnings
warnings.filterwarnings('ignore')

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class HyperparameterTuner:
    """Comprehensive hyperparameter tuning for email classification models."""
    
    def __init__(self, variant_dir: str = 'data/feature_variants', 
                 results_dir: str = 'results/hyperparameter_tuning'):
        """Initialize the hyperparameter tuner.
        
        Args:
            variant_dir: Directory containing feature variant CSV files
            results_dir: Directory to save tuning results
        """
        self.variant_dir = Path(variant_dir)
        self.results_dir = Path(results_dir)
        self.results_dir.mkdir(parents=True, exist_ok=True)
        
        # Search strategies
        self.search_strategies = ['grid', 'random', 'bayesian']
        
        # CV configuration for extreme class imbalance
        self.cv_folds = 3  # Reduced for small dataset
        self.cv_scoring = 'f1'  # Primary metric for imbalanced data
        
        # Results storage
        self.tuning_results = {}
        self.best_models = {}
        
    def get_parameter_grids(self) -> Dict[str, Dict[str, Any]]:
        """Define parameter grids for different models."""
        
        param_grids = {
            'logistic_regression': {
                'grid': {
                    'C': [0.001, 0.01, 0.1, 1.0, 10.0, 100.0],
                    'penalty': ['l1', 'l2', 'elasticnet'],
                    'solver': ['liblinear', 'saga'],
                    'max_iter': [1000, 2000],
                    'class_weight': ['balanced', None]
                },
                'random': {
                    'C': uniform(0.001, 100),
                    'penalty': ['l1', 'l2', 'elasticnet'],
                    'solver': ['liblinear', 'saga'],
                    'max_iter': [1000, 2000, 3000],
                    'class_weight': ['balanced', None]
                }
            },
            
            'random_forest': {
                'grid': {
                    'n_estimators': [50, 100, 200],
                    'max_depth': [3, 5, 10, None],
                    'min_samples_split': [2, 5, 10],
                    'min_samples_leaf': [1, 2, 4],
                    'max_features': ['sqrt', 'log2', None],
                    'class_weight': ['balanced', 'balanced_subsample', None]
                },
                'random': {
                    'n_estimators': randint(50, 300),
                    'max_depth': [3, 5, 10, 15, 20, None],
                    'min_samples_split': randint(2, 20),
                    'min_samples_leaf': randint(1, 10),
                    'max_features': ['sqrt', 'log2', None],
                    'class_weight': ['balanced', 'balanced_subsample', None]
                }
            },
            
            'gradient_boosting': {
                'grid': {
                    'n_estimators': [50, 100, 200],
                    'learning_rate': [0.01, 0.1, 0.2],
                    'max_depth': [3, 5, 7],
                    'min_samples_split': [2, 5, 10],
                    'min_samples_leaf': [1, 2, 4],
                    'subsample': [0.8, 0.9, 1.0]
                },
                'random': {
                    'n_estimators': randint(50, 300),
                    'learning_rate': uniform(0.01, 0.2),
                    'max_depth': randint(3, 10),
                    'min_samples_split': randint(2, 20),
                    'min_samples_leaf': randint(1, 10),
                    'subsample': uniform(0.7, 0.3)
                }
            },
            
            'svm': {
                'grid': {
                    'C': [0.1, 1.0, 10.0, 100.0],
                    'kernel': ['rbf', 'poly', 'sigmoid'],
                    'gamma': ['scale', 'auto', 0.001, 0.01, 0.1],
                    'class_weight': ['balanced', None]
                },
                'random': {
                    'C': uniform(0.1, 100),
                    'kernel': ['rbf', 'poly', 'sigmoid'],
                    'gamma': ['scale', 'auto'] + list(uniform(0.001, 1).rvs(10)),
                    'class_weight': ['balanced', None]
                }
            },
            
            'decision_tree': {
                'grid': {
                    'max_depth': [3, 5, 10, 15, None],
                    'min_samples_split': [2, 5, 10, 20],
                    'min_samples_leaf': [1, 2, 5, 10],
                    'max_features': ['sqrt', 'log2', None],
                    'class_weight': ['balanced', None]
                },
                'random': {
                    'max_depth': [3, 5, 10, 15, 20, None],
                    'min_samples_split': randint(2, 25),
                    'min_samples_leaf': randint(1, 15),
                    'max_features': ['sqrt', 'log2', None],
                    'class_weight': ['balanced', None]
                }
            }
        }
        
        return param_grids
    
    def get_model_instance(self, model_name: str) -> Any:
        """Get a model instance by name."""
        
        models = {
            'logistic_regression': LogisticRegression(random_state=42),
            'random_forest': RandomForestClassifier(random_state=42),
            'gradient_boosting': GradientBoostingClassifier(random_state=42),
            'svm': SVC(random_state=42, probability=True),
            'naive_bayes': GaussianNB(),
            'decision_tree': DecisionTreeClassifier(random_state=42)
        }
        
        return models.get(model_name)
    
    def perform_grid_search(self, model, param_grid: Dict, X_train: np.ndarray, 
                           y_train: np.ndarray, model_name: str) -> Tuple[Any, Dict]:
        """Perform grid search hyperparameter tuning."""
        
        logger.info(f"🔍 Starting Grid Search for {model_name}")
        logger.info(f"   Parameter grid size: {np.prod([len(v) for v in param_grid.values()])} combinations")
        
        # Configure cross-validation
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
        
        # Perform grid search
        grid_search = GridSearchCV(
            estimator=model,
            param_grid=param_grid,
            cv=cv,
            scoring=self.cv_scoring,
            n_jobs=-1,
            verbose=1,
            error_score='raise'
        )
        
        try:
            grid_search.fit(X_train, y_train)
            
            results = {
                'best_score': grid_search.best_score_,
                'best_params': grid_search.best_params_,
                'cv_results': {
                    'mean_test_score': grid_search.cv_results_['mean_test_score'].tolist(),
                    'std_test_score': grid_search.cv_results_['std_test_score'].tolist(),
                    'params': grid_search.cv_results_['params']
                }
            }
            
            logger.info(f"✅ Grid Search completed - Best {self.cv_scoring}: {grid_search.best_score_:.4f}")
            return grid_search.best_estimator_, results
            
        except Exception as e:
            logger.error(f"❌ Grid Search failed for {model_name}: {e}")
            return None, {'error': str(e)}
    
    def perform_random_search(self, model, param_distributions: Dict, X_train: np.ndarray, 
                             y_train: np.ndarray, model_name: str, n_iter: int = 50) -> Tuple[Any, Dict]:
        """Perform randomized search hyperparameter tuning."""
        
        logger.info(f"🎲 Starting Random Search for {model_name}")
        logger.info(f"   Number of iterations: {n_iter}")
        
        # Configure cross-validation
        cv = StratifiedKFold(n_splits=self.cv_folds, shuffle=True, random_state=42)
        
        # Perform random search
        random_search = RandomizedSearchCV(
            estimator=model,
            param_distributions=param_distributions,
            n_iter=n_iter,
            cv=cv,
            scoring=self.cv_scoring,
            n_jobs=-1,
            verbose=1,
            random_state=42,
            error_score='raise'
        )
        
        try:
            random_search.fit(X_train, y_train)
            
            results = {
                'best_score': random_search.best_score_,
                'best_params': random_search.best_params_,
                'cv_results': {
                    'mean_test_score': random_search.cv_results_['mean_test_score'].tolist(),
                    'std_test_score': random_search.cv_results_['std_test_score'].tolist(),
                    'params': random_search.cv_results_['params']
                }
            }
            
            logger.info(f"✅ Random Search completed - Best {self.cv_scoring}: {random_search.best_score_:.4f}")
            return random_search.best_estimator_, results
            
        except Exception as e:
            logger.error(f"❌ Random Search failed for {model_name}: {e}")
            return None, {'error': str(e)}
    
    def evaluate_model(self, model, X_test: np.ndarray, y_test: np.ndarray) -> Dict[str, float]:
        """Evaluate a tuned model on test data."""
        
        try:
            # Make predictions
            y_pred = model.predict(X_test)
            y_pred_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else None
            
            # Calculate metrics
            metrics = {
                'test_f1': f1_score(y_test, y_pred),
                'test_precision': precision_score(y_test, y_pred, zero_division=0),
                'test_recall': recall_score(y_test, y_pred, zero_division=0),
                'test_roc_auc': roc_auc_score(y_test, y_pred_proba) if y_pred_proba is not None else 0.0
            }
            
            return metrics
            
        except Exception as e:
            logger.error(f"❌ Model evaluation failed: {e}")
            return {'test_f1': 0.0, 'test_precision': 0.0, 'test_recall': 0.0, 'test_roc_auc': 0.0}
    
    def tune_variant_models(self, variant_name: str, models_to_tune: List[str], 
                           search_strategy: str = 'grid') -> Dict[str, Any]:
        """Tune hyperparameters for specified models on a feature variant."""
        
        logger.info(f"🚀 Starting hyperparameter tuning for variant: {variant_name}")
        logger.info(f"   Models: {models_to_tune}")
        logger.info(f"   Search strategy: {search_strategy}")
        
        # Load feature variant data
        variant_file = self.variant_dir / f"{variant_name}_features.csv"
        if not variant_file.exists():
            logger.error(f"❌ Variant file not found: {variant_file}")
            return {}
        
        df = pd.read_csv(variant_file)
        logger.info(f"📊 Loaded {len(df)} samples with {len(df.columns)-1} features")
        
        # Prepare data
        X = df.drop(columns=['label'])
        y = df['label']
        
        # Handle missing values
        X = X.fillna(0)
        
        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )
        
        # Scale features for algorithms that need it
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        # Get parameter grids
        param_grids = self.get_parameter_grids()
        
        # Store results for this variant
        variant_results = {
            'variant_name': variant_name,
            'search_strategy': search_strategy,
            'dataset_info': {
                'total_samples': len(df),
                'train_samples': len(X_train),
                'test_samples': len(X_test),
                'feature_count': len(X.columns),
                'bill_rate': float(y.mean())
            },
            'models': {}
        }
        
        # Tune each model
        for model_name in models_to_tune:
            logger.info(f"🔧 Tuning {model_name}...")
            
            # Get model instance
            model = self.get_model_instance(model_name)
            if model is None:
                logger.error(f"❌ Unknown model: {model_name}")
                continue
            
            # Use scaled data for SVM and Logistic Regression
            if model_name in ['svm', 'logistic_regression']:
                X_train_model = X_train_scaled
                X_test_model = X_test_scaled
            else:
                X_train_model = X_train
                X_test_model = X_test
            
            # Get parameter grid/distribution
            if model_name not in param_grids:
                logger.warning(f"⚠️  No parameter grid defined for {model_name}")
                continue
                
            param_config = param_grids[model_name]
            
            # Perform hyperparameter search
            if search_strategy == 'grid':
                best_model, search_results = self.perform_grid_search(
                    model, param_config['grid'], X_train_model, y_train, model_name
                )
            elif search_strategy == 'random':
                best_model, search_results = self.perform_random_search(
                    model, param_config['random'], X_train_model, y_train, model_name
                )
            else:
                logger.error(f"❌ Unknown search strategy: {search_strategy}")
                continue
            
            if best_model is None:
                logger.error(f"❌ Tuning failed for {model_name}")
                continue
            
            # Evaluate on test set
            test_metrics = self.evaluate_model(best_model, X_test_model, y_test)
            
            # Store results
            variant_results['models'][model_name] = {
                'search_results': search_results,
                'test_metrics': test_metrics,
                'improvement_analysis': self._analyze_improvement(model_name, test_metrics)
            }
            
            # Store best model
            self.best_models[f"{variant_name}_{model_name}"] = best_model
            
            logger.info(f"✅ {model_name} tuning completed - Test F1: {test_metrics['test_f1']:.4f}")
        
        return variant_results
    
    def _analyze_improvement(self, model_name: str, tuned_metrics: Dict[str, float]) -> Dict[str, Any]:
        """Analyze improvement from hyperparameter tuning compared to default parameters."""
        
        # These are baseline metrics from previous model comparison
        # You could load these from the existing results file
        baseline_metrics = {
            'logistic_regression': {'test_f1': 0.825, 'test_roc_auc': 0.966},
            'random_forest': {'test_f1': 0.667, 'test_roc_auc': 0.916},
            'gradient_boosting': {'test_f1': 0.667, 'test_roc_auc': 0.899},
            'svm': {'test_f1': 0.825, 'test_roc_auc': 0.966},
            'decision_tree': {'test_f1': 0.667, 'test_roc_auc': 0.833}
        }
        
        if model_name not in baseline_metrics:
            return {'improvement_f1': 0.0, 'improvement_roc_auc': 0.0}
        
        baseline = baseline_metrics[model_name]
        improvement = {
            'baseline_f1': baseline['test_f1'],
            'tuned_f1': tuned_metrics['test_f1'],
            'improvement_f1': tuned_metrics['test_f1'] - baseline['test_f1'],
            'baseline_roc_auc': baseline['test_roc_auc'],
            'tuned_roc_auc': tuned_metrics['test_roc_auc'],
            'improvement_roc_auc': tuned_metrics['test_roc_auc'] - baseline['test_roc_auc'],
            'relative_improvement_f1': ((tuned_metrics['test_f1'] - baseline['test_f1']) / baseline['test_f1'] * 100) if baseline['test_f1'] > 0 else 0
        }
        
        return improvement
    
    def save_results(self, results: Dict[str, Any], filename: str) -> None:
        """Save tuning results to JSON file."""
        
        output_file = self.results_dir / filename
        
        # Add metadata
        results['metadata'] = {
            'tuning_completed_at': datetime.now().isoformat(),
            'cv_folds': self.cv_folds,
            'cv_scoring': self.cv_scoring,
            'search_strategies': self.search_strategies
        }
        
        # Save results
        with open(output_file, 'w') as f:
            json.dump(results, f, indent=2, default=str)
        
        logger.info(f"💾 Results saved to {output_file}")
    
    def create_summary_report(self, results: Dict[str, Any]) -> str:
        """Create a summary report of hyperparameter tuning results."""
        
        report = f"""# Hyperparameter Tuning Report

**Generated**: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

## Experiment Configuration

- **Feature Variant**: {results['variant_name']}
- **Search Strategy**: {results['search_strategy']}
- **Cross-Validation**: {self.cv_folds}-fold Stratified
- **Primary Metric**: {self.cv_scoring}

## Dataset Information

- **Total Samples**: {results['dataset_info']['total_samples']}
- **Training Samples**: {results['dataset_info']['train_samples']}
- **Test Samples**: {results['dataset_info']['test_samples']}
- **Features**: {results['dataset_info']['feature_count']}
- **Bill Rate**: {results['dataset_info']['bill_rate']:.1%}

## Model Performance Summary

| Model | Test F1 | Test ROC-AUC | CV Score | Improvement |
|-------|---------|-------------|----------|-------------|
"""
        
        for model_name, model_results in results['models'].items():
            test_f1 = model_results['test_metrics']['test_f1']
            test_roc_auc = model_results['test_metrics']['test_roc_auc']
            cv_score = model_results['search_results'].get('best_score', 0)
            improvement = model_results['improvement_analysis'].get('improvement_f1', 0)
            
            report += f"| {model_name.replace('_', ' ').title()} | {test_f1:.3f} | {test_roc_auc:.3f} | {cv_score:.3f} | {improvement:+.3f} |\n"
        
        # Find best model
        best_model = max(results['models'].items(), key=lambda x: x[1]['test_metrics']['test_f1'])
        best_name, best_results = best_model
        
        report += f"""
## Best Model: {best_name.replace('_', ' ').title()}

**Performance Metrics:**
- Test F1-Score: {best_results['test_metrics']['test_f1']:.4f}
- Test ROC-AUC: {best_results['test_metrics']['test_roc_auc']:.4f}
- CV Score: {best_results['search_results'].get('best_score', 0):.4f}

**Optimal Hyperparameters:**
```json
{json.dumps(best_results['search_results'].get('best_params', {}), indent=2)}
```

## Key Insights

1. **Best Performing Model**: {best_name.replace('_', ' ').title()} achieved the highest F1-score of {best_results['test_metrics']['test_f1']:.3f}
2. **Hyperparameter Impact**: Tuning improved F1-score by {best_results['improvement_analysis'].get('improvement_f1', 0):+.3f} points
3. **Search Strategy**: {results['search_strategy'].title()} search explored the parameter space effectively
4. **Class Imbalance**: The extreme class imbalance (bill rate: {results['dataset_info']['bill_rate']:.1%}) requires careful metric interpretation

## Recommendations

1. **Production Model**: Use {best_name.replace('_', ' ').title()} with the optimized hyperparameters
2. **Further Optimization**: Consider ensemble methods or advanced techniques for the extreme imbalance
3. **Feature Engineering**: Continue exploring feature selection and engineering approaches
4. **Data Collection**: Increase dataset size for more robust hyperparameter optimization

---
*Report generated by Email Classification Hyperparameter Tuning Pipeline*
"""
        
        return report


def main():
    """Main hyperparameter tuning function."""
    
    parser = argparse.ArgumentParser(description="Hyperparameter tuning for email classification models")
    parser.add_argument('--variant', default='selected', help='Feature variant to tune (basic, enhanced, tfidf, combined, selected, pca)')
    parser.add_argument('--models', nargs='+', default=['logistic_regression', 'random_forest'], 
                       help='Models to tune (logistic_regression, random_forest, gradient_boosting, svm, decision_tree)')
    parser.add_argument('--strategy', default='grid', choices=['grid', 'random'], 
                       help='Search strategy (grid or random)')
    parser.add_argument('--output-dir', default='results/hyperparameter_tuning', 
                       help='Output directory for results')
    parser.add_argument('--random-iterations', type=int, default=50, 
                       help='Number of iterations for random search')
    
    args = parser.parse_args()
    
    logger.info("🎯 Starting Email Classification Hyperparameter Tuning")
    logger.info(f"   Variant: {args.variant}")
    logger.info(f"   Models: {args.models}")
    logger.info(f"   Strategy: {args.strategy}")
    
    # Initialize tuner
    tuner = HyperparameterTuner(results_dir=args.output_dir)
    
    # Perform tuning
    results = tuner.tune_variant_models(
        variant_name=args.variant,
        models_to_tune=args.models,
        search_strategy=args.strategy
    )
    
    if not results:
        logger.error("❌ Hyperparameter tuning failed")
        return
    
    # Save results
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results_file = f"{args.variant}_{args.strategy}_tuning_{timestamp}.json"
    tuner.save_results(results, results_file)
    
    # Generate report
    report = tuner.create_summary_report(results)
    report_file = tuner.results_dir / f"{args.variant}_{args.strategy}_report_{timestamp}.md"
    
    with open(report_file, 'w') as f:
        f.write(report)
    
    logger.info(f"📄 Report saved to {report_file}")
    
    # Print summary
    print("\n" + "="*60)
    print("🎯 HYPERPARAMETER TUNING COMPLETED")
    print("="*60)
    
    best_model = max(results['models'].items(), key=lambda x: x[1]['test_metrics']['test_f1'])
    best_name, best_results = best_model
    
    print(f"🏆 Best Model: {best_name.replace('_', ' ').title()}")
    print(f"   Test F1-Score: {best_results['test_metrics']['test_f1']:.4f}")
    print(f"   Test ROC-AUC: {best_results['test_metrics']['test_roc_auc']:.4f}")
    print(f"   Improvement: {best_results['improvement_analysis'].get('improvement_f1', 0):+.3f}")
    
    print(f"\n📁 Results: {tuner.results_dir}")
    print(f"📄 Report: {report_file}")


if __name__ == "__main__":
    main() 