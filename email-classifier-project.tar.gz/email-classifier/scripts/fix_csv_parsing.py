#!/usr/bin/env python3
"""
Fix CSV Parsing Issues for Gmail Dataset

This script addresses CSV parsing problems in the Gmail dataset caused by 
unescaped HTML content and special characters, enabling access to all emails.

Usage:
    python scripts/fix_csv_parsing.py --input data/my_gmail_dataset.csv --output data/my_gmail_dataset_cleaned.csv
"""

import pandas as pd
import csv
import json
import re
import argparse
import sys
from pathlib import Path
from typing import List, Dict, Any
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)


class CSVCleaner:
    """Robust CSV cleaner for malformed email datasets."""
    
    def __init__(self, input_file: str, output_file: str):
        self.input_file = Path(input_file)
        self.output_file = Path(output_file)
        
    def clean_field_content(self, content: str) -> str:
        """Clean and escape problematic content in CSV fields."""
        if not isinstance(content, str):
            return str(content)
        
        # Remove problematic characters that break CSV parsing
        content = content.replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ')
        content = content.replace('"', '""')  # Escape quotes properly
        content = re.sub(r'\s+', ' ', content)  # Normalize whitespace
        content = content.strip()
        
        return content
    
    def read_raw_lines(self) -> List[str]:
        """Read raw lines from the CSV file."""
        logger.info(f"📖 Reading raw lines from {self.input_file}")
        
        try:
            with open(self.input_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()
            logger.info(f"   Read {len(lines)} total lines")
            return lines
        except Exception as e:
            logger.error(f"❌ Failed to read file: {e}")
            return []
    
    def parse_header(self, header_line: str) -> List[str]:
        """Parse the CSV header to get column names."""
        # Use a simple CSV reader for the header
        reader = csv.reader([header_line])
        try:
            header = next(reader)
            logger.info(f"   Detected {len(header)} columns: {header[:5]}...")
            return header
        except Exception as e:
            logger.error(f"❌ Failed to parse header: {e}")
            return []
    
    def parse_problematic_lines(self, lines: List[str], header: List[str]) -> pd.DataFrame:
        """Parse CSV lines with robust error handling."""
        logger.info("🔧 Parsing lines with robust error handling...")
        
        rows = []
        errors = 0
        
        for i, line in enumerate(lines[1:], 1):  # Skip header
            try:
                # Try different parsing strategies
                parsed_row = self.parse_single_line(line, header)
                if parsed_row:
                    rows.append(parsed_row)
                else:
                    errors += 1
                    if errors < 10:  # Log first 10 errors
                        logger.warning(f"   Failed to parse line {i}: {line[:100]}...")
                        
            except Exception as e:
                errors += 1
                if errors < 10:
                    logger.warning(f"   Error on line {i}: {e}")
            
            # Progress update
            if i % 1000 == 0:
                logger.info(f"   Processed {i} lines, {len(rows)} successful, {errors} errors")
        
        logger.info(f"✅ Parsing completed: {len(rows)} rows, {errors} errors")
        
        # Create DataFrame
        df = pd.DataFrame(rows, columns=header)
        return df
    
    def parse_single_line(self, line: str, header: List[str]) -> Dict[str, Any]:
        """Parse a single CSV line with multiple strategies."""
        
        # Strategy 1: Standard CSV parsing
        try:
            reader = csv.reader([line])
            fields = next(reader)
            if len(fields) == len(header):
                return dict(zip(header, fields))
        except:
            pass
        
        # Strategy 2: Simple comma split with quote handling
        try:
            # Remove problematic quotes and split
            cleaned_line = self.clean_field_content(line)
            
            # Simple field extraction for key columns
            # This is a fallback for severely malformed lines
            if 'id' in header and 'subject' in header and 'body' in header:
                # Extract essential fields using regex patterns
                fields = self.extract_essential_fields(line, header)
                if fields:
                    return fields
        except:
            pass
        
        return None
    
    def extract_essential_fields(self, line: str, header: List[str]) -> Dict[str, str]:
        """Extract essential fields from malformed lines using patterns."""
        
        # This is a simplified extraction for the most important fields
        # In a real scenario, you'd want more sophisticated parsing
        
        result = {}
        
        # Split by comma and try to map to fields
        parts = line.split(',')
        
        # Map the first few fields if they exist
        for i, field_name in enumerate(header):
            if i < len(parts):
                result[field_name] = parts[i].strip().strip('"')
            else:
                result[field_name] = ""
        
        return result
    
    def chunk_read_csv(self, chunk_size: int = 1000) -> pd.DataFrame:
        """Read CSV in chunks to identify where parsing breaks."""
        logger.info(f"📊 Reading CSV in chunks of {chunk_size}...")
        
        chunks = []
        try:
            for chunk in pd.read_csv(self.input_file, chunksize=chunk_size, 
                                   engine='python', on_bad_lines='skip', 
                                   dtype=str, encoding='utf-8'):
                chunks.append(chunk)
                logger.info(f"   Loaded chunk with {len(chunk)} rows")
        except Exception as e:
            logger.warning(f"   Chunk reading stopped: {e}")
        
        if chunks:
            df = pd.concat(chunks, ignore_index=True)
            logger.info(f"✅ Successfully read {len(df)} rows using chunk method")
            return df
        else:
            return pd.DataFrame()
    
    def clean_and_save(self) -> bool:
        """Main method to clean CSV and save corrected version."""
        logger.info("🚀 Starting CSV cleaning process...")
        
        # Try chunk reading first (fastest if it works)
        df = self.chunk_read_csv()
        
        if len(df) < 1000:  # If chunk reading didn't work well
            logger.info("🔄 Chunk reading insufficient, trying line-by-line parsing...")
            
            # Read raw lines
            lines = self.read_raw_lines()
            if not lines:
                return False
            
            # Parse header
            header = self.parse_header(lines[0])
            if not header:
                return False
            
            # Parse data with error handling
            df = self.parse_problematic_lines(lines, header)
        
        if df.empty:
            logger.error("❌ No data could be parsed")
            return False
        
        # Clean the DataFrame
        logger.info("🧹 Cleaning DataFrame content...")
        for col in df.columns:
            if df[col].dtype == 'object':
                df[col] = df[col].astype(str).apply(self.clean_field_content)
        
        # Save cleaned CSV
        logger.info(f"💾 Saving cleaned CSV to {self.output_file}")
        self.output_file.parent.mkdir(parents=True, exist_ok=True)
        
        df.to_csv(self.output_file, index=False, quoting=csv.QUOTE_ALL)
        
        # Create metadata
        metadata = {
            'original_file': str(self.input_file),
            'cleaned_file': str(self.output_file),
            'original_lines': len(self.read_raw_lines()),
            'cleaned_rows': len(df),
            'columns': list(df.columns),
            'cleaning_method': 'robust_parsing'
        }
        
        metadata_file = self.output_file.with_suffix('.json')
        with open(metadata_file, 'w') as f:
            json.dump(metadata, f, indent=2)
        
        logger.info(f"✅ Cleaning completed!")
        logger.info(f"   Original lines: {metadata['original_lines']}")
        logger.info(f"   Cleaned rows: {metadata['cleaned_rows']}")
        logger.info(f"   Success rate: {metadata['cleaned_rows']/metadata['original_lines']*100:.1f}%")
        
        return True


def main():
    """Main function."""
    parser = argparse.ArgumentParser(description="Fix CSV parsing issues in Gmail dataset")
    parser.add_argument('--input', default='data/my_gmail_dataset.csv', 
                       help='Input CSV file with parsing issues')
    parser.add_argument('--output', default='data/my_gmail_dataset_cleaned.csv',
                       help='Output cleaned CSV file')
    
    args = parser.parse_args()
    
    # Initialize cleaner
    cleaner = CSVCleaner(args.input, args.output)
    
    # Clean and save
    success = cleaner.clean_and_save()
    
    if success:
        print(f"\n✅ CSV cleaning successful!")
        print(f"📁 Cleaned file: {args.output}")
        print(f"📄 Metadata: {args.output.replace('.csv', '.json')}")
    else:
        print(f"\n❌ CSV cleaning failed!")
        sys.exit(1)


if __name__ == "__main__":
    main() 