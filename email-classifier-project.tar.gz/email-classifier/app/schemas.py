"""Pydantic schemas for the email classification API with comprehensive examples."""

from pydantic import BaseModel, Field, validator
from typing import List, Optional, Dict, Any
from datetime import datetime


class EmailData(BaseModel):
    """
    ## 📧 Datos del Email para Clasificación
    
    Contiene toda la información necesaria para clasificar un email.
    """
    subject: str = Field(
        ..., 
        description="Asunto del email",
        example="Factura #F-2025-001 - Vencimiento 15/03/2025"
    )
    body: str = Field(
        ..., 
        description="Contenido del cuerpo del email",
        example="Estimado Cliente, le informamos que tiene una factura pendiente de pago por $850.00 (ochocientos cincuenta pesos) correspondiente a los servicios prestados en febrero 2025. La fecha de vencimiento es el 15 de marzo de 2025. Puede realizar el pago a través de transferencia bancaria o en nuestras oficinas. Adjuntamos la factura en formato PDF para su revisión."
    )
    sender_email: str = Field(
        ..., 
        description="Dirección de email del remitente",
        example="facturacion@empresaservicos.com"
    )
    sender_name: Optional[str] = Field(
        None, 
        description="Nombre del remitente",
        example="Empresa Servicios SA - Dpto Facturación"
    )
    to_emails: Optional[List[str]] = Field(
        default_factory=list, 
        description="Emails de destinatarios",
        example=["cliente@email.com"]
    )
    cc_emails: Optional[List[str]] = Field(
        default_factory=list, 
        description="Emails en copia",
        example=[]
    )
    received_date: Optional[datetime] = Field(
        None, 
        description="Fecha de recepción del email",
        example="2025-03-01T09:15:00"
    )
    attachments: Optional[List[str]] = Field(
        default_factory=list, 
        description="Nombres de archivos adjuntos",
        example=["Factura_F-2025-001.pdf"]
    )
    
    @validator('subject', 'body')
    def clean_text(cls, v):
        """Clean and validate text fields."""
        if v:
            return v.strip()
        return v
    
    @validator('sender_email')
    def validate_email(cls, v):
        """Basic email validation."""
        if '@' not in v:
            raise ValueError('Invalid email format')
        return v.lower().strip()

    class Config:
        schema_extra = {
            "example": {
                "subject": "Factura #F-2025-001 - Vencimiento 15/03/2025",
                "body": "Estimado Cliente, le informamos que tiene una factura pendiente de pago por $850.00 (ochocientos cincuenta pesos) correspondiente a los servicios prestados en febrero 2025. La fecha de vencimiento es el 15 de marzo de 2025. Puede realizar el pago a través de transferencia bancaria o en nuestras oficinas. Adjuntamos la factura en formato PDF para su revisión.",
                "sender_email": "facturacion@empresaservcios.com",
                "sender_name": "Empresa Servicios SA - Dpto Facturación",
                "to_emails": ["cliente@email.com"],
                "cc_emails": [],
                "received_date": "2025-03-01T09:15:00",
                "attachments": ["Factura_F-2025-001.pdf"]
            }
        }


class ClassificationRequest(BaseModel):
    """
    ## 🎯 Solicitud de Clasificación Individual
    
    Para clasificar un solo email como factura o no factura.
    """
    email: EmailData = Field(
        ..., 
        description="Datos del email a clasificar"
    )
    include_reasoning: bool = Field(
        True, 
        description="Incluir explicación del razonamiento del modelo",
        example=True
    )

    class Config:
        schema_extra = {
            "example": {
                "email": {
                    "subject": "Factura #F-2025-001 - Vencimiento 15/03/2025",
                    "body": "Estimado Cliente, le informamos que tiene una factura pendiente de pago por $850.00 (ochocientos cincuenta pesos) correspondiente a los servicios prestados en febrero 2025. La fecha de vencimiento es el 15 de marzo de 2025. Puede realizar el pago a través de transferencia bancaria o en nuestras oficinas. Adjuntamos la factura en formato PDF para su revisión.",
                    "sender_email": "facturacion@empresaservcios.com",
                    "sender_name": "Empresa Servicios SA - Dpto Facturación",
                    "to_emails": ["cliente@email.com"],
                    "cc_emails": [],
                    "received_date": "2025-03-01T09:15:00",
                    "attachments": ["Factura_F-2025-001.pdf"]
                },
                "include_reasoning": True
            }
        }


class BatchClassificationRequest(BaseModel):
    """
    ## 📦 Solicitud de Clasificación en Lote
    
    Para clasificar múltiples emails de una vez (máximo 100).
    """
    emails: List[EmailData] = Field(
        ..., 
        description="Lista de emails a clasificar (máximo 100)",
        min_items=1,
        max_items=100
    )
    include_reasoning: bool = Field(
        False, 
        description="Incluir explicación para todos los emails",
        example=False
    )
    
    @validator('emails')
    def validate_batch_size(cls, v):
        """Validate batch size."""
        if len(v) > 100:
            raise ValueError('El lote no puede exceder 100 emails')
        return v

    class Config:
        schema_extra = {
            "example": {
                "emails": [
                    {
                        "subject": "Factura #F-2025-001 - Vencimiento 15/03/2025",
                        "body": "Estimado Cliente, adjuntamos factura por $850.00 con vencimiento 15/03/2025",
                        "sender_email": "facturacion@empresa1.com",
                        "attachments": ["factura_001.pdf"]
                    },
                    {
                        "subject": "Newsletter Marzo 2025 - Ofertas especiales", 
                        "body": "Descubre nuestras promociones especiales para este mes",
                        "sender_email": "marketing@tienda.com",
                        "attachments": []
                    }
                ],
                "include_reasoning": False
            }
        }


class ClassificationResult(BaseModel):
    """
    ## 📊 Resultado de Clasificación
    
    Contiene la predicción del modelo y métricas asociadas.
    """
    is_bill: bool = Field(
        ..., 
        description="¿Es una factura o cuenta por pagar?",
        example=True
    )
    confidence: float = Field(
        ..., 
        description="Nivel de confianza del modelo (0.0 a 1.0)",
        ge=0.0,
        le=1.0,
        example=0.94
    )
    reasoning: Optional[str] = Field(
        None, 
        description="Explicación del por qué de la clasificación",
        example="Email identificado como FACTURA con alta confianza debido a: (1) monto monetario específico ($850.00), (2) fecha de vencimiento clara (15/03/2025), (3) remitente de dominio comercial/facturación, (4) archivo PDF adjunto típico de facturas, (5) terminología financiera ('factura pendiente', 'pago', 'vencimiento'). El modelo detectó 5 indicadores clave de facturas."
    )
    features: Optional[Dict[str, Any]] = Field(
        None, 
        description="Características extraídas del email",
        example={
            "money_entities_count": 1,
            "has_due_date": True,
            "sender_domain_commercial": True,
            "attachment_count": 1,
            "urgency_score": 0.7,
            "subject_length": 42,
            "body_word_count": 58
        }
    )
    processing_time_ms: Optional[float] = Field(
        None, 
        description="Tiempo de procesamiento en milisegundos",
        example=38.5
    )

    class Config:
        schema_extra = {
            "example": {
                "is_bill": True,
                "confidence": 0.94,
                "reasoning": "Email identificado como FACTURA con alta confianza debido a: (1) monto monetario específico ($850.00), (2) fecha de vencimiento clara (15/03/2025), (3) remitente de dominio comercial/facturación, (4) archivo PDF adjunto típico de facturas, (5) terminología financiera ('factura pendiente', 'pago', 'vencimiento'). El modelo detectó 5 indicadores clave de facturas.",
                "features": {
                    "money_entities_count": 1,
                    "has_due_date": True,
                    "sender_domain_commercial": True,
                    "attachment_count": 1,
                    "urgency_score": 0.7,
                    "subject_length": 42,
                    "body_word_count": 58
                },
                "processing_time_ms": 38.5
            }
        }


class ClassificationResponse(BaseModel):
    """
    ## ✅ Respuesta de Clasificación Individual
    
    Respuesta completa para la clasificación de un email.
    """
    result: ClassificationResult = Field(..., description="Resultado de la clasificación")
    status: str = Field("success", description="Estado de la operación", example="success")
    message: Optional[str] = Field(None, description="Mensaje adicional", example="Email clasificado exitosamente")

    class Config:
        schema_extra = {
            "example": {
                "result": {
                    "is_bill": True,
                    "confidence": 0.94,
                    "reasoning": "Email identificado como FACTURA con alta confianza debido a: (1) monto monetario específico ($850.00), (2) fecha de vencimiento clara (15/03/2025), (3) remitente de dominio comercial/facturación, (4) archivo PDF adjunto típico de facturas, (5) terminología financiera ('factura pendiente', 'pago', 'vencimiento'). El modelo detectó 5 indicadores clave de facturas.",
                    "features": {
                        "money_entities_count": 1,
                        "has_due_date": True,
                        "sender_domain_commercial": True,
                        "attachment_count": 1,
                        "urgency_score": 0.7,
                        "subject_length": 42,
                        "body_word_count": 58
                    },
                    "processing_time_ms": 38.5
                },
                "status": "success",
                "message": "Email clasificado exitosamente"
            }
        }


class BatchClassificationResponse(BaseModel):
    """
    ## 📦 Respuesta de Clasificación en Lote
    
    Resultados para múltiples emails procesados.
    """
    results: List[ClassificationResult] = Field(..., description="Resultados de clasificación para cada email")
    total_processed: int = Field(..., description="Total de emails procesados", example=2)
    success_count: int = Field(..., description="Emails clasificados exitosamente", example=2)
    error_count: int = Field(..., description="Emails con errores", example=0)
    total_processing_time_ms: float = Field(..., description="Tiempo total de procesamiento", example=82.3)
    status: str = Field("success", description="Estado general", example="success")

    class Config:
        schema_extra = {
            "example": {
                "results": [
                    {
                        "is_bill": True,
                        "confidence": 0.94,
                        "processing_time_ms": 38.5
                    },
                    {
                        "is_bill": False,
                        "confidence": 0.91,
                        "processing_time_ms": 43.8
                    }
                ],
                "total_processed": 2,
                "success_count": 2,
                "error_count": 0,
                "total_processing_time_ms": 82.3,
                "status": "success"
            }
        }


class ModelInfo(BaseModel):
    """
    ## ℹ️ Información del Modelo
    
    Estadísticas y metadatos del modelo de clasificación cargado.
    """
    model_type: str = Field(..., description="Tipo de modelo ML", example="LogisticRegression")
    model_version: Optional[str] = Field(None, description="Versión del modelo", example="v2.1")
    training_date: Optional[datetime] = Field(None, description="Fecha de entrenamiento", example="2025-03-01T10:00:00")
    total_parameters: Optional[int] = Field(None, description="Número de parámetros", example=20)
    training_samples: Optional[int] = Field(None, description="Muestras de entrenamiento", example=800)
    validation_accuracy: Optional[float] = Field(None, description="Precisión en validación", example=0.875)
    features_used: Optional[List[str]] = Field(None, description="Características utilizadas", example=["money_entities_count", "has_due_date", "sender_domain_commercial"])
    class_distribution: Optional[Dict[str, int]] = Field(None, description="Distribución de clases", example={"bill": 20, "not_bill": 980})

    class Config:
        schema_extra = {
            "example": {
                "model_type": "LogisticRegression",
                "model_version": "v2.1",
                "training_date": "2025-03-01T10:00:00",
                "total_parameters": 20,
                "training_samples": 800,
                "validation_accuracy": 0.875,
                "features_used": ["money_entities_count", "has_due_date", "sender_domain_commercial", "urgency_score"],
                "class_distribution": {"bill": 20, "not_bill": 980}
            }
        }


class HealthStatus(BaseModel):
    """
    ## 🏥 Estado de Salud del Sistema
    
    Información sobre el estado operativo del servicio.
    """
    status: str = Field(..., description="Estado del servicio", example="healthy")
    timestamp: datetime = Field(..., description="Momento de la verificación")
    version: str = Field(..., description="Versión del servicio", example="1.0.0")
    model_loaded: bool = Field(..., description="¿Modelo cargado correctamente?", example=True)
    dependencies: Dict[str, str] = Field(..., description="Estado de dependencias", example={"database": "ok", "filesystem": "ok"})

    class Config:
        schema_extra = {
            "example": {
                "status": "healthy",
                "timestamp": "2025-03-10T14:30:00",
                "version": "1.0.0",
                "model_loaded": True,
                "dependencies": {
                    "modelo_ml": "✅ cargado",
                    "filesystem": "✅ accesible",
                    "memoria": "✅ disponible"
                }
            }
        }


class TrainingRequest(BaseModel):
    """
    ## 🎓 Solicitud de Entrenamiento
    
    Para entrenar un nuevo modelo con datos personalizados.
    """
    data_path: str = Field(..., description="Ruta al archivo CSV de entrenamiento", example="data/labeled_emails_v2.csv")
    model_type: str = Field("logistic_regression", description="Tipo de modelo a entrenar", example="logistic_regression")
    validation_split: float = Field(0.2, description="Proporción para validación (0.0-1.0)", example=0.2)
    epochs: int = Field(3, description="Épocas de entrenamiento", example=3)
    learning_rate: float = Field(2e-5, description="Tasa de aprendizaje", example=0.00002)
    batch_size: int = Field(32, description="Tamaño del lote", example=32)
    
    @validator('validation_split')
    def validate_split(cls, v):
        """Validate validation split."""
        if not 0 < v < 1:
            raise ValueError('La división de validación debe estar entre 0 y 1')
        return v

    class Config:
        schema_extra = {
            "example": {
                "data_path": "data/labeled_emails_v2.csv",
                "model_type": "logistic_regression",
                "validation_split": 0.2,
                "epochs": 5,
                "learning_rate": 0.001,
                "batch_size": 16
            }
        }


class TrainingResponse(BaseModel):
    """
    ## 📈 Respuesta de Entrenamiento
    
    Estado y resultados del proceso de entrenamiento.
    """
    status: str = Field(..., description="Estado del entrenamiento", example="completed")
    message: str = Field(..., description="Mensaje descriptivo", example="Entrenamiento completado exitosamente")
    model_path: Optional[str] = Field(None, description="Ruta del modelo guardado", example="models/logistic_regression_v2.pkl")
    training_time: Optional[float] = Field(None, description="Tiempo de entrenamiento (segundos)", example=45.2)
    final_accuracy: Optional[float] = Field(None, description="Precisión final de validación", example=0.875)
    training_history: Optional[Dict[str, List[float]]] = Field(None, description="Historial de métricas", example={"accuracy": [0.82, 0.85, 0.87], "loss": [0.45, 0.32, 0.28]})

    class Config:
        schema_extra = {
            "example": {
                "status": "completed",
                "message": "Modelo entrenado exitosamente con 800 muestras",
                "model_path": "models/logistic_regression_v2.pkl", 
                "training_time": 67.8,
                "final_accuracy": 0.875,
                "training_history": {
                    "accuracy": [0.82, 0.85, 0.875],
                    "f1_score": [0.78, 0.81, 0.825]
                }
            }
        } 