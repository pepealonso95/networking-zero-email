"""Health check router for the email classification service."""

from fastapi import APIRouter, Depends
from datetime import datetime
import sys
import os
from pathlib import Path

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.schemas import HealthStatus
from config.settings import settings

router = APIRouter()


@router.get("/", response_model=HealthStatus)
async def health_check():
    """Check service health and dependencies."""
    
    # Check if model file exists
    model_exists = os.path.exists(settings.classifier_model_path)
    
    # Check dependencies
    dependencies = {
        "model_file": "exists" if model_exists else "missing",
        "data_directory": "exists" if os.path.exists("data") else "missing",
        "logs_directory": "exists" if os.path.exists("logs") else "missing"
    }
    
    # Determine overall status
    status = "healthy" if all(v != "missing" for v in dependencies.values()) else "degraded"
    
    return HealthStatus(
        status=status,
        timestamp=datetime.utcnow(),
        version="1.0.0",
        model_loaded=model_exists,
        dependencies=dependencies
    )


@router.get("/ready")
async def readiness_check():
    """Check if service is ready to accept requests."""
    model_exists = os.path.exists(settings.classifier_model_path)
    
    if not model_exists:
        return {
            "status": "not_ready",
            "message": "Model not loaded. Please train a model first.",
            "timestamp": datetime.utcnow()
        }
    
    return {
        "status": "ready",
        "message": "Service ready to accept requests",
        "timestamp": datetime.utcnow()
    }


@router.get("/live")
async def liveness_check():
    """Simple liveness check."""
    return {
        "status": "alive",
        "timestamp": datetime.utcnow()
    } 