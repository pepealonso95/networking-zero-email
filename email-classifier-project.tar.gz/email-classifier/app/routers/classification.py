"""Classification API router for email classification endpoints."""

from fastapi import APIRouter, HTTPException, Depends, BackgroundTasks, Request
from datetime import datetime
import time
import sys
from pathlib import Path
import asyncio

# Add parent directory to path
sys.path.append(str(Path(__file__).parent.parent.parent))

from app.schemas import (
    EmailData, ClassificationRequest, ClassificationResponse,
    BatchClassificationRequest, BatchClassificationResponse,
    ClassificationResult, ModelInfo,
    TrainingRequest, TrainingResponse
)
from app.models.classifier import EmailClassifier
from config.settings import settings

router = APIRouter()


def get_classifier_dependency(request: Request) -> EmailClassifier:
    """Dependency to get the classifier from app state."""
    classifier = getattr(request.app.state, 'classifier', None)
    if not classifier:
        raise HTTPException(
            status_code=503,
            detail="Classifier not initialized"
        )
    return classifier


@router.post(
    "/",
    response_model=ClassificationResponse,
    summary="🎯 Clasificar Email Individual",
    description="""
    ## 📧 Clasifica un email como factura o no factura
    
    Este endpoint utiliza el modelo de Machine Learning entrenado para determinar si un email 
    contiene una factura o cuenta por pagar.
    
    ### 🎯 Funcionalidad:
    - **Análisis de contenido**: Examina asunto, cuerpo y metadatos
    - **Extracción de características**: Detecta montos, fechas, remitentes comerciales
    - **Predicción ML**: Utiliza modelo optimizado (F1-Score: 0.825)
    - **Confianza**: Retorna nivel de certeza de la predicción
    
    ### 📊 Características analizadas:
    - Entidades monetarias ($100.00, USD 500, etc.)
    - Fechas de vencimiento
    - Tipo de remitente (comercial vs personal)
    - Palabras clave financieras
    - Archivos adjuntos (PDF, Excel)
    - Urgencia del mensaje
    
    ### ⚡ Performance:
    - **Latencia**: <50ms por email
    - **Precisión**: 87.5%
    - **Recall**: 77.8%
    - **ROC-AUC**: 0.966
    
    ---
    
    ## 🚀 Ejemplos de Uso
    
    ### Ejemplo con curl:
    ```bash
    curl -X POST "http://localhost:8000/classify/" \\
         -H "Content-Type: application/json" \\
         -d '{
           "email": {
             "subject": "Factura #F-2025-001 - Vencimiento 15/03/2025",
             "body": "Estimado Cliente, le informamos que tiene una factura pendiente de pago por $850.00 correspondiente a los servicios prestados en febrero 2025. La fecha de vencimiento es el 15 de marzo de 2025.",
             "sender_email": "facturacion@empresaservcios.com",
             "sender_name": "Empresa Servicios SA",
             "attachments": ["Factura_F-2025-001.pdf"]
           },
           "include_reasoning": true
         }'
    ```
    
    ### Ejemplo con Python requests:
    ```python
    import requests
    
    url = "http://localhost:8000/classify/"
    data = {
        "email": {
            "subject": "Factura #F-2025-001 - Vencimiento 15/03/2025",
            "body": "Estimado Cliente, le informamos que tiene una factura pendiente de pago por $850.00...",
            "sender_email": "facturacion@empresaservcios.com",
            "attachments": ["Factura_F-2025-001.pdf"]
        },
        "include_reasoning": True
    }
    
    response = requests.post(url, json=data)
    result = response.json()
    print(f"Es factura: {result['result']['is_bill']}")
    print(f"Confianza: {result['result']['confidence']:.2%}")
    ```
    
    ### Ejemplo con JavaScript/fetch:
    ```javascript
    const response = await fetch('http://localhost:8000/classify/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            email: {
                subject: "Factura #F-2025-001 - Vencimiento 15/03/2025",
                body: "Estimado Cliente, le informamos que tiene una factura pendiente...",
                sender_email: "facturacion@empresaservcios.com",
                attachments: ["Factura_F-2025-001.pdf"]
            },
            include_reasoning: true
        })
    });
    
    const result = await response.json();
    console.log(`Es factura: ${result.result.is_bill}`);
    console.log(`Confianza: ${(result.result.confidence * 100).toFixed(1)}%`);
    ```
    """,
    response_description="Resultado de clasificación con confianza y razonamiento opcional",
    tags=["🤖 Clasificación"]
)
async def classify_email(
    request: ClassificationRequest,
    classifier: EmailClassifier = Depends(get_classifier_dependency)
):
    """
    Clasifica un email individual como factura o no factura.
    
    Retorna la predicción del modelo junto con el nivel de confianza
    y opcionalmente la explicación del razonamiento.
    """
    if not classifier.is_model_loaded():
        raise HTTPException(
            status_code=503,
            detail="Modelo no cargado. Asegúrese de que hay un modelo entrenado disponible."
        )
    
    try:
        # Convert email data to dict
        email_data = request.email.model_dump()
        
        # Classify the email
        result = await classifier.classify_email(
            email_data,
            include_reasoning=request.include_reasoning
        )
        
        # Create classification result
        classification_result = ClassificationResult(**result)
        
        return ClassificationResponse(
            result=classification_result,
            status="success",
            message="Email clasificado exitosamente"
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error en la clasificación: {str(e)}"
        )


@router.post(
    "/batch",
    response_model=BatchClassificationResponse,
    summary="📦 Clasificación en Lote",
    description="""
    ## 📦 Clasifica múltiples emails de forma eficiente
    
    Procesa hasta **100 emails** en una sola petición, optimizado para 
    casos de uso con grandes volúmenes de datos.
    
    ### 🚀 Ventajas del procesamiento en lote:
    - **Eficiencia**: Reduce overhead de múltiples requests HTTP
    - **Throughput**: Procesa hasta 500 emails/minuto
    - **Estadísticas**: Resumen de éxitos, errores y tiempos
    - **Escalabilidad**: Optimizado para integración empresarial
    
    ### 📊 Métricas retornadas:
    - Total de emails procesados
    - Conteo de éxitos y errores
    - Tiempo total de procesamiento
    - Resultados individuales para cada email
    
    ### 💡 Casos de uso típicos:
    - Migración de sistemas legacy
    - Procesamiento nocturno de bandeja de entrada
    - Integración con CRM/ERP
    - Auditorías financieras automatizadas
    """,
    response_description="Resultados de clasificación para todos los emails con estadísticas agregadas",
    tags=["🤖 Clasificación"]
)
async def classify_emails_batch(
    request: BatchClassificationRequest,
    classifier: EmailClassifier = Depends(get_classifier_dependency)
):
    """
    Clasifica múltiples emails en una sola operación.
    
    Procesa eficientemente hasta 100 emails y retorna estadísticas
    agregadas junto con los resultados individuales.
    """
    if not classifier.is_model_loaded():
        raise HTTPException(
            status_code=503,
            detail="Modelo no cargado. Asegúrese de que hay un modelo entrenado disponible."
        )
    
    try:
        start_time = time.time()
        
        # Convert email data to dicts
        emails_data = [email.model_dump() for email in request.emails]
        
        # Classify all emails
        results = await classifier.classify_batch(
            emails_data,
            include_reasoning=request.include_reasoning
        )
        
        # Convert to ClassificationResult objects
        classification_results = []
        success_count = 0
        error_count = 0
        
        for result in results:
            if result.get("error", False):
                error_count += 1
            else:
                success_count += 1
            
            classification_results.append(ClassificationResult(**result))
        
        total_time = (time.time() - start_time) * 1000  # Convert to milliseconds
        
        return BatchClassificationResponse(
            results=classification_results,
            total_processed=len(classification_results),
            success_count=success_count,
            error_count=error_count,
            total_processing_time_ms=total_time,
            status="success"
        )
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error en clasificación en lote: {str(e)}"
        )


@router.get(
    "/model/info",
    response_model=ModelInfo,
    summary="ℹ️ Información del Modelo",
    description="""
    ## ℹ️ Obtiene metadatos y estadísticas del modelo cargado
    
    Proporciona información detallada sobre el modelo de Machine Learning
    actualmente en uso para la clasificación de emails.
    
    ### 📊 Información incluida:
    - **Tipo de modelo**: LogisticRegression, RandomForest, etc.
    - **Versión**: Control de versiones del modelo
    - **Fecha de entrenamiento**: Cuándo fue entrenado
    - **Performance**: Métricas de validación
    - **Características**: Features utilizadas para la predicción
    - **Distribución de clases**: Balance del dataset de entrenamiento
    
    ### 🎯 Utilidad:
    - Validar que el modelo correcto está cargado
    - Auditoría de modelos en producción
    - Debugging y troubleshooting
    - Reporting de performance del sistema
    """,
    response_description="Metadatos completos del modelo actual",
    tags=["ℹ️ Información"]
)
async def get_model_info(classifier: EmailClassifier = Depends(get_classifier_dependency)):
    """
    Obtiene información detallada sobre el modelo cargado.
    
    Incluye tipo, versión, métricas de performance y características utilizadas.
    """
    model_info = classifier.get_model_info()
    
    return ModelInfo(
        model_type=model_info.get("model_type", "unknown"),
        model_version=model_info.get("model_version"),
        training_date=datetime.fromisoformat(model_info.get("trained_at")) if model_info.get("trained_at") else None,
        total_parameters=model_info.get("total_parameters"),
        training_samples=model_info.get("training_samples"),
        validation_accuracy=model_info.get("accuracy"),
        features_used=model_info.get("features_used"),
        class_distribution=model_info.get("class_distribution")
    )


@router.post(
    "/model/train",
    response_model=TrainingResponse,
    summary="🎓 Entrenar Nuevo Modelo",
    description="""
    ## 🎓 Entrena un nuevo modelo con datos personalizados
    
    **⚠️ Operación avanzada**: Este endpoint permite entrenar un modelo
    completamente nuevo usando datos CSV proporcionados.
    
    ### 📋 Requisitos del archivo CSV:
    - **Columnas requeridas**: `subject`, `body`, `sender_email`, `is_bill`
    - **Formato**: UTF-8, separado por comas
    - **Tamaño mínimo**: 100 muestras
    - **Balance**: Al menos 10% de cada clase
    
    ### 🔄 Proceso de entrenamiento:
    1. **Validación de datos**: Verificación de formato y calidad
    2. **Feature engineering**: Extracción automática de características
    3. **Entrenamiento**: Algoritmo ML optimizado
    4. **Evaluación**: Métricas en conjunto de validación
    5. **Guardado**: Persistencia del modelo entrenado
    
    ### ⏱️ Tiempo estimado:
    - **100-500 muestras**: 30-60 segundos
    - **500-1000 muestras**: 1-2 minutos
    - **1000+ muestras**: 2-5 minutos
    
    **Nota**: El entrenamiento se ejecuta en segundo plano.
    """,
    response_description="Estado del proceso de entrenamiento iniciado",
    tags=["🎓 Entrenamiento"]
)
async def train_model(request: TrainingRequest, background_tasks: BackgroundTasks):
    """
    Inicia el entrenamiento de un nuevo modelo en segundo plano.
    
    El proceso puede tomar varios minutos dependiendo del tamaño de los datos.
    Consulta los logs del sistema para seguir el progreso.
    """
    import os
    
    # Validate training data exists
    if not os.path.exists(request.data_path):
        raise HTTPException(
            status_code=400,
            detail=f"Archivo de entrenamiento no encontrado: {request.data_path}"
        )
    
    # Create a background task for training
    async def train_background():
        """Background training task."""
        try:
            # Import training module
            from scripts.train_model import ModelTrainer
            import pandas as pd
            
            print(f"🎓 Iniciando entrenamiento de modelo {request.model_type}...")
            
            # Load data
            df = pd.read_csv(request.data_path)
            print(f"📊 Datos cargados: {len(df)} muestras")
            
            # Initialize trainer
            trainer = ModelTrainer(request.model_type)
            
            # Prepare data
            X_train, X_test, y_train, y_test = trainer.prepare_data(df)
            
            # Train model
            if request.model_type in ["distilbert", "roberta"]:
                results = trainer.train_transformer_model(X_train, X_test, y_train, y_test)
            else:
                results = trainer.train_ml_model(X_train, X_test, y_train, y_test)
            
            # Save model
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"models/{request.model_type}_model_{timestamp}.pkl"
            trainer.save_model(output_path, results)
            
            print(f"✅ Entrenamiento completado exitosamente:")
            print(f"   Accuracy: {results.get('accuracy', 0):.3f}")
            print(f"   F1-Score: {results.get('f1_score', 0):.3f}")
            print(f"   Modelo guardado: {output_path}")
            
        except Exception as e:
            print(f"❌ Error en entrenamiento: {e}")
    
    # Start background training
    background_tasks.add_task(train_background)
    
    return TrainingResponse(
        status="iniciado",
        message=f"Entrenamiento de modelo {request.model_type} iniciado en segundo plano. Consulte los logs para seguir el progreso.",
        model_path=None,
        training_time=None,
        final_accuracy=None
    )


@router.post("/model/reload")
async def reload_model(request: Request):
    """
    ## 🔄 Recargar Modelo
    
    Recarga el modelo desde el disco sin reiniciar el servicio.
    Útil después de entrenar un nuevo modelo.
    """
    try:
        classifier = getattr(request.app.state, 'classifier', None)
        if not classifier:
            raise HTTPException(status_code=503, detail="Classifier not initialized")
        
        # Reload model
        await classifier.load_model(settings.classifier_model_path)
        
        return {
            "status": "success",
            "message": "Modelo recargado exitosamente",
            "model_path": settings.classifier_model_path,
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error al recargar modelo: {str(e)}"
        )


@router.get(
    "/stats",
    summary="📊 Estadísticas de Uso",
    description="Obtiene estadísticas de uso y performance del sistema de clasificación",
    tags=["📊 Estadísticas"]
)
async def get_classification_stats(classifier: EmailClassifier = Depends(get_classifier_dependency)):
    """
    Obtiene estadísticas de uso del sistema de clasificación.
    
    Incluye conteos de predicciones, tiempos de respuesta promedio,
    y métricas de performance del modelo.
    """
    try:
        # Get basic stats from classifier
        stats = {
            "total_predictions": getattr(classifier, 'prediction_count', 0),
            "model_loaded": classifier.is_model_loaded(),
            "model_type": getattr(classifier, 'model_type', 'unknown'),
            "uptime_info": {
                "status": "operational",
                "last_prediction": getattr(classifier, 'last_prediction_time', None)
            },
            "performance_metrics": {
                "avg_response_time_ms": getattr(classifier, 'avg_response_time', 0),
                "accuracy_estimate": 0.875,  # From validation
                "f1_score_estimate": 0.825   # From validation
            }
        }
        
        return stats
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error al obtener estadísticas: {str(e)}"
        )


@router.post(
    "/test",
    summary="🧪 Test de Clasificación",
    description="""
    ## 🧪 Endpoint de prueba con ejemplos predefinidos
    
    Utiliza emails de ejemplo para verificar que el sistema funciona correctamente.
    Útil para testing, demostraciones y verificaciones rápidas.
    
    ### 🚀 Uso rápido:
    ```bash
    # Test rápido del sistema
    curl -X POST "http://localhost:8000/classify/test"
    ```
    
    ### 📝 Este endpoint:
    - No requiere parámetros de entrada
    - Usa emails predefinidos para pruebas
    - Retorna resultados de clasificación de ejemplo
    - Verifica que el modelo está funcionando
    """,
    tags=["🧪 Testing"]
)
async def test_classification(classifier: EmailClassifier = Depends(get_classifier_dependency)):
    """
    Ejecuta una prueba rápida del sistema con emails de ejemplo.
    
    Retorna resultados de clasificación para casos típicos de
    facturas y emails normales.
    """
    if not classifier.is_model_loaded():
        raise HTTPException(
            status_code=503,
            detail="Modelo no disponible para testing"
        )
    
    # Test emails
    test_emails = [
        {
            "subject": "Factura Nº 001-2025 - Vencimiento 20/03",
            "body": "Estimado cliente, adjuntamos la factura por $1,250.00 con vencimiento el 20 de marzo de 2025.",
            "sender_email": "billing@empresa.com",
            "attachments": ["factura_001.pdf"],
            "expected": True  # Should be classified as bill
        },
        {
            "subject": "Newsletter marzo - Ofertas especiales",
            "body": "Descubre nuestras nuevas promociones y ofertas especiales para este mes.",
            "sender_email": "marketing@tienda.com",
            "attachments": [],
            "expected": False  # Should be classified as not bill
        }
    ]
    
    try:
        results = []
        
        for test_email in test_emails:
            expected = test_email.pop("expected")
            
            # Classify test email
            result = await classifier.classify_email(test_email, include_reasoning=True)
            
            # Add test info
            result["test_info"] = {
                "expected_classification": expected,
                "prediction_correct": result["is_bill"] == expected,
                "test_case": "factura" if expected else "email_normal"
            }
            
            results.append(result)
        
        # Calculate accuracy
        correct_predictions = sum(1 for r in results if r["test_info"]["prediction_correct"])
        accuracy = correct_predictions / len(results)
        
        return {
            "test_results": results,
            "summary": {
                "total_tests": len(results),
                "correct_predictions": correct_predictions,
                "test_accuracy": accuracy,
                "status": "✅ PASS" if accuracy >= 0.8 else "❌ FAIL"
            },
            "timestamp": datetime.now().isoformat()
        }
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error en test de clasificación: {str(e)}"
        ) 