import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import json
import numpy as np
from pathlib import Path
import seaborn as sns
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report
import warnings
warnings.filterwarnings('ignore')

# Page configuration
st.set_page_config(
    page_title="Email Classification ML Dashboard",
    page_icon="📧",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS
st.markdown("""
<style>
    .main-header {
        font-size: 2.5rem;
        font-weight: bold;
        text-align: center;
        margin-bottom: 2rem;
        color: #2E86AB;
    }
    .metric-card {
        background-color: #f0f2f6;
        padding: 1rem;
        border-radius: 0.5rem;
        text-align: center;
        margin: 0.5rem 0;
    }
    .section-header {
        font-size: 1.5rem;
        font-weight: bold;
        margin: 1.5rem 0 1rem 0;
        color: #2E86AB;
    }
</style>
""", unsafe_allow_html=True)

@st.cache_data
def load_data():
    """Load all necessary data files"""
    base_path = Path("data")
    results_path = Path("results/model_comparison")
    
    # Load model comparison results
    results_df = pd.read_csv(results_path / "detailed_results.csv")
    
    # Rename columns to match expected format
    if 'model_name' in results_df.columns:
        results_df = results_df.rename(columns={'model_name': 'algorithm'})
    if 'variant_name' in results_df.columns:
        results_df = results_df.rename(columns={'variant_name': 'variant'})
    
    # Load feature variants report
    with open(base_path / "feature_variants" / "feature_variants_report.json", 'r') as f:
        feature_report_data = json.load(f)
        # Extract the variants section if it exists
        feature_report = feature_report_data.get('variants', feature_report_data)
    
    # Load all feature variant datasets
    feature_variants = {}
    feature_files = [
        "basic_features.csv", "enhanced_features.csv", "tfidf_features.csv",
        "combined_features.csv", "selected_features.csv", "pca_features.csv"
    ]
    
    for file in feature_files:
        variant_name = file.replace("_features.csv", "")
        feature_variants[variant_name] = pd.read_csv(base_path / "feature_variants" / file)
    
    # Load original dataset
    original_data = pd.read_csv(base_path / "my_gmail_dataset.csv")
    
    return results_df, feature_report, feature_variants, original_data

def main():
    """Main Streamlit application"""
    
    # Load data
    results_df, feature_report, feature_variants, original_data = load_data()
    
    # Sidebar navigation
    st.sidebar.title("📧 Email Classification Dashboard")
    st.sidebar.markdown("---")
    
    page = st.sidebar.selectbox(
        "Choose a page:",
        ["🏠 Overview", "📊 Model Comparison", "🔍 Feature Analysis", "📈 Performance Deep Dive", "🧪 Interactive Prediction", "📋 Data Explorer"]
    )
    
    # Main header
    st.markdown('<h1 class="main-header">Email Classification ML Dashboard</h1>', unsafe_allow_html=True)
    
    if page == "🏠 Overview":
        show_overview(results_df, feature_report, original_data)
    elif page == "📊 Model Comparison":
        show_model_comparison(results_df)
    elif page == "🔍 Feature Analysis":
        show_feature_analysis(feature_report, feature_variants)
    elif page == "📈 Performance Deep Dive":
        show_performance_analysis(results_df)
    elif page == "🧪 Interactive Prediction":
        show_prediction_interface(feature_variants, original_data)
    elif page == "📋 Data Explorer":
        show_data_explorer(original_data, feature_variants)

def show_overview(results_df, feature_report, original_data):
    """Overview page with key insights and summary"""
    
    st.markdown('<div class="section-header">🎯 Project Overview</div>', unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3>📧 Dataset Size</h3>
            <h2>{}</h2>
            <p>Real Gmail Emails</p>
        </div>
        """.format(len(original_data)), unsafe_allow_html=True)
    
    with col2:
        bill_percentage = (original_data['is_bill'].sum() / len(original_data)) * 100
        st.markdown("""
        <div class="metric-card">
            <h3>💰 Bill Rate</h3>
            <h2>{:.1f}%</h2>
            <p>Class Imbalance Challenge</p>
        </div>
        """.format(bill_percentage), unsafe_allow_html=True)
    
    with col3:
        best_f1 = results_df['test_f1'].max()
        st.markdown("""
        <div class="metric-card">
            <h3>🏆 Best F1-Score</h3>
            <h2>{:.3f}</h2>
            <p>Bill Detection Performance</p>
        </div>
        """.format(best_f1), unsafe_allow_html=True)
    
    st.markdown('<div class="section-header">🧪 Experiment Summary</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("**Feature Engineering Approaches:**")
        for variant, info in feature_report.items():
            if variant != "creation_timestamp":
                feature_count = info['feature_count']
                st.write(f"• **{variant.title()}**: {feature_count} features")
    
    with col2:
        st.markdown("**Machine Learning Algorithms:**")
        algorithms = results_df['algorithm'].unique()
        for algo in algorithms:
            st.write(f"• {algo}")
    
    # Best model highlight
    best_model = results_df.loc[results_df['test_f1'].idxmax()]
    
    st.markdown('<div class="section-header">🏆 Best Model Results</div>', unsafe_allow_html=True)
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric("Algorithm", best_model['algorithm'])
    
    with col2:
        st.metric("Feature Variant", best_model['variant'].title())
    
    with col3:
        st.metric("F1-Score", f"{best_model['test_f1']:.3f}")
    
    with col4:
        st.metric("ROC-AUC", f"{best_model['test_roc_auc']:.3f}")
    
    # Key insights
    st.markdown('<div class="section-header">💡 Key Insights</div>', unsafe_allow_html=True)
    
    st.success("""
    **🎯 Feature Selection Wins**: The Selected Features variant (20 features) outperformed 
    the Combined approach (166 features), proving that careful feature selection beats feature engineering volume.
    """)
    
    st.info("""
    **⚖️ Algorithm Efficiency**: Logistic Regression and SVM achieved identical top performance, 
    demonstrating that simpler models can be as effective as complex ones for this task.
    """)
    
    st.warning("""
    **📊 Class Imbalance Success**: Despite extreme imbalance (2% bills), the model achieved 
    82.5% F1-score through proper handling with balanced class weights and stratified sampling.
    """)

def show_model_comparison(results_df):
    """Model comparison visualization page"""
    
    st.markdown('<div class="section-header">📊 Model Performance Comparison</div>', unsafe_allow_html=True)
    
    # Performance heatmap
    col1, col2 = st.columns(2)
    
    with col1:
        metric = st.selectbox("Select Metric:", ["test_f1", "test_roc_auc", "test_precision", "test_recall"])
    
    with col2:
        variant_filter = st.multiselect(
            "Filter Feature Variants:",
            options=results_df['variant'].unique(),
            default=results_df['variant'].unique()
        )
    
    # Filter data
    filtered_df = results_df[results_df['variant'].isin(variant_filter)]
    
    # Create pivot table for heatmap
    pivot_df = filtered_df.pivot(index='algorithm', columns='variant', values=metric)
    
    # Plotly heatmap
    fig = px.imshow(
        pivot_df.values,
        x=pivot_df.columns,
        y=pivot_df.index,
        color_continuous_scale='RdYlBu_r',
        title=f'{metric.replace("test_", "").replace("_", " ").title()} Performance Heatmap'
    )
    
    fig.update_layout(height=500)
    st.plotly_chart(fig, use_container_width=True)
    
    # Top performers table
    st.markdown('<div class="section-header">🏆 Top 10 Performers</div>', unsafe_allow_html=True)
    
    top_performers = filtered_df.nlargest(10, metric)[['algorithm', 'variant', metric, 'test_f1', 'test_roc_auc']]
    top_performers = top_performers.round(3)
    st.dataframe(top_performers, use_container_width=True)
    
    # Algorithm comparison
    st.markdown('<div class="section-header">🔬 Algorithm Performance Distribution</div>', unsafe_allow_html=True)
    
    fig = px.box(filtered_df, x='algorithm', y=metric, title=f'{metric.replace("test_", "").title()} Distribution by Algorithm')
    fig.update_xaxes(tickangle=45)
    st.plotly_chart(fig, use_container_width=True)

def show_feature_analysis(feature_report, feature_variants):
    """Feature analysis and comparison page"""
    
    st.markdown('<div class="section-header">🔍 Feature Engineering Analysis</div>', unsafe_allow_html=True)
    
    # Feature count comparison
    variant_names = [v for v in feature_report.keys() if v != "creation_timestamp"]
    feature_counts = [feature_report[v]['feature_count'] for v in variant_names]
    
    fig = px.bar(
        x=[v.title() for v in variant_names],
        y=feature_counts,
        title="Feature Count by Variant",
        labels={'x': 'Feature Variant', 'y': 'Number of Features'}
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Feature variant details
    st.markdown('<div class="section-header">📋 Feature Variant Details</div>', unsafe_allow_html=True)
    
    selected_variant = st.selectbox("Select Feature Variant:", variant_names)
    
    col1, col2 = st.columns(2)
    
    with col1:
        variant_info = feature_report[selected_variant]
        st.write(f"**Feature Count:** {variant_info['feature_count']}")
        st.write(f"**Description:** {variant_info['description']}")
        
        if 'feature_categories' in variant_info:
            st.write("**Feature Categories:**")
            for category, count in variant_info['feature_categories'].items():
                st.write(f"• {category}: {count}")
    
    with col2:
        # Show sample of actual features
        if selected_variant in feature_variants:
            variant_df = feature_variants[selected_variant]
            feature_cols = [col for col in variant_df.columns if col not in ['subject', 'sender', 'is_bill']]
            
            st.write("**Sample Features:**")
            sample_features = feature_cols[:10]  # Show first 10 features
            for feature in sample_features:
                st.write(f"• {feature}")
            
            if len(feature_cols) > 10:
                st.write(f"... and {len(feature_cols) - 10} more")
    
    # Feature importance for selected features variant
    if selected_variant == "selected" and "selected" in feature_variants:
        st.markdown('<div class="section-header">⭐ Selected Features Importance</div>', unsafe_allow_html=True)
        
        # Show the top features that were selected
        selected_df = feature_variants["selected"]
        feature_cols = [col for col in selected_df.columns if col not in ['subject', 'sender', 'is_bill']]
        
        # Create a simple importance visualization based on feature names
        st.write("**Top Selected Features:**")
        for i, feature in enumerate(feature_cols[:15], 1):
            st.write(f"{i}. {feature}")

def show_performance_analysis(results_df):
    """Detailed performance analysis page"""
    
    st.markdown('<div class="section-header">📈 Performance Deep Dive</div>', unsafe_allow_html=True)
    
    # Scatter plot: F1 vs ROC-AUC
    fig = px.scatter(
        results_df,
        x='test_f1',
        y='test_roc_auc',
        color='variant',
        symbol='algorithm',
        title='F1-Score vs ROC-AUC Performance',
        hover_data=['algorithm', 'variant']
    )
    
    fig.add_shape(
        type="line",
        x0=results_df['test_f1'].min(),
        y0=results_df['test_f1'].min(),
        x1=results_df['test_f1'].max(),
        y1=results_df['test_f1'].max(),
        line=dict(color="red", dash="dash"),
        name="Equal Performance Line"
    )
    
    st.plotly_chart(fig, use_container_width=True)
    
    # Performance correlation analysis
    st.markdown('<div class="section-header">🔗 Metric Correlations</div>', unsafe_allow_html=True)
    
    metric_cols = ['test_f1', 'test_roc_auc', 'test_precision', 'test_recall']
    correlation_matrix = results_df[metric_cols].corr()
    
    fig = px.imshow(
        correlation_matrix,
        title="Performance Metrics Correlation",
        color_continuous_scale='RdBu',
        aspect="auto"
    )
    st.plotly_chart(fig, use_container_width=True)
    
    # Detailed statistics
    st.markdown('<div class="section-header">📊 Statistical Summary</div>', unsafe_allow_html=True)
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.write("**Performance by Feature Variant:**")
        variant_stats = results_df.groupby('variant')[metric_cols].agg(['mean', 'std']).round(3)
        st.dataframe(variant_stats)
    
    with col2:
        st.write("**Performance by Algorithm:**")
        algo_stats = results_df.groupby('algorithm')[metric_cols].agg(['mean', 'std']).round(3)
        st.dataframe(algo_stats)

def show_prediction_interface(feature_variants, original_data):
    """Interactive prediction interface"""
    
    st.markdown('<div class="section-header">🧪 Interactive Email Classification</div>', unsafe_allow_html=True)
    
    st.info("This interface simulates the best performing model: Logistic Regression with Selected Features")
    
    # Prepare the best model (Selected Features + Logistic Regression)
    if "selected" in feature_variants:
        selected_df = feature_variants["selected"]
        
        # Prepare features and target
        feature_cols = [col for col in selected_df.columns if col not in ['subject', 'sender', 'is_bill']]
        X = selected_df[feature_cols]
        y = selected_df['is_bill']
        
        # Train the model
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
        
        scaler = StandardScaler()
        X_train_scaled = scaler.fit_transform(X_train)
        X_test_scaled = scaler.transform(X_test)
        
        model = LogisticRegression(class_weight='balanced', random_state=42)
        model.fit(X_train_scaled, y_train)
        
        # Email input interface
        st.markdown("**Enter email details for classification:**")
        
        col1, col2 = st.columns(2)
        
        with col1:
            subject = st.text_input("Email Subject:", value="Your monthly utility bill")
            sender = st.text_input("Sender Email:", value="billing@utility-company.com")
        
        with col2:
            # Sample from actual dataset
            sample_email = st.selectbox(
                "Or choose a sample email:",
                options=["Custom"] + list(range(min(10, len(original_data)))),
                format_func=lambda x: "Custom" if x == "Custom" else f"Sample {x+1}: {original_data.iloc[x]['subject'][:50]}..."
            )
        
        if sample_email != "Custom":
            subject = original_data.iloc[sample_email]['subject']
            sender = original_data.iloc[sample_email]['sender']
            actual_label = original_data.iloc[sample_email]['is_bill']
        
        if st.button("🔍 Classify Email", type="primary"):
            # For demo purposes, create a simple feature vector
            # In practice, you'd use the same feature engineering pipeline
            
            # Create dummy features based on the email content
            sample_features = np.zeros(len(feature_cols))
            
            # Simple feature extraction (bill-related keywords)
            bill_keywords = ['bill', 'invoice', 'payment', 'due', 'account', 'statement', 'utility', 'electric', 'gas', 'water']
            
            subject_lower = subject.lower()
            sender_lower = sender.lower()
            
            # Set some features based on keywords
            keyword_count = sum(1 for keyword in bill_keywords if keyword in subject_lower or keyword in sender_lower)
            
            # Use average feature values with some bill-specific adjustments
            for i, col in enumerate(feature_cols):
                if 'bill' in col.lower() or 'payment' in col.lower() or 'invoice' in col.lower():
                    sample_features[i] = keyword_count / len(bill_keywords)
                else:
                    sample_features[i] = X[col].mean()
            
            # Scale and predict
            sample_features_scaled = scaler.transform([sample_features])
            prediction = model.predict(sample_features_scaled)[0]
            probability = model.predict_proba(sample_features_scaled)[0]
            
            # Display results
            col1, col2, col3 = st.columns(3)
            
            with col1:
                st.metric("Prediction", "💰 Bill" if prediction == 1 else "📧 Not Bill")
            
            with col2:
                st.metric("Confidence", f"{max(probability):.1%}")
            
            with col3:
                if sample_email != "Custom":
                    st.metric("Actual Label", "💰 Bill" if actual_label == 1 else "📧 Not Bill")
            
            # Probability breakdown
            st.markdown("**Classification Probabilities:**")
            prob_df = pd.DataFrame({
                'Class': ['Not Bill', 'Bill'],
                'Probability': probability
            })
            
            fig = px.bar(prob_df, x='Class', y='Probability', title="Classification Confidence")
            st.plotly_chart(fig, use_container_width=True)
    
    else:
        st.error("Selected features variant not found. Please ensure the feature engineering pipeline has been run.")

def show_data_explorer(original_data, feature_variants):
    """Data exploration page"""
    
    st.markdown('<div class="section-header">📋 Dataset Explorer</div>', unsafe_allow_html=True)
    
    tab1, tab2, tab3 = st.tabs(["📧 Original Data", "🔧 Feature Variants", "📊 Statistics"])
    
    with tab1:
        st.markdown("**Original Gmail Dataset:**")
        
        col1, col2, col3 = st.columns(3)
        with col1:
            st.metric("Total Emails", len(original_data))
        with col2:
            st.metric("Bills", original_data['is_bill'].sum())
        with col3:
            st.metric("Non-Bills", (original_data['is_bill'] == 0).sum())
        
        # Class distribution
        fig = px.pie(
            values=[original_data['is_bill'].sum(), (original_data['is_bill'] == 0).sum()],
            names=['Bills', 'Non-Bills'],
            title="Class Distribution"
        )
        st.plotly_chart(fig, use_container_width=True)
        
        # Sample data
        st.markdown("**Sample Emails:**")
        display_cols = ['subject', 'sender', 'is_bill']
        if all(col in original_data.columns for col in display_cols):
            st.dataframe(original_data[display_cols].head(10), use_container_width=True)
    
    with tab2:
        st.markdown("**Feature Variant Comparison:**")
        
        variant_selector = st.selectbox("Select Variant:", list(feature_variants.keys()))
        
        if variant_selector in feature_variants:
            variant_df = feature_variants[variant_selector]
            
            col1, col2 = st.columns(2)
            with col1:
                st.metric("Features", len([col for col in variant_df.columns if col not in ['subject', 'sender', 'is_bill']]))
            with col2:
                st.metric("Samples", len(variant_df))
            
            # Feature statistics
            feature_cols = [col for col in variant_df.columns if col not in ['subject', 'sender', 'is_bill']]
            if feature_cols:
                st.markdown("**Feature Statistics:**")
                st.dataframe(variant_df[feature_cols].describe(), use_container_width=True)
    
    with tab3:
        st.markdown("**Cross-Variant Statistics:**")
        
        # Feature count comparison
        variant_info = []
        for variant_name, variant_df in feature_variants.items():
            feature_count = len([col for col in variant_df.columns if col not in ['subject', 'sender', 'is_bill']])
            variant_info.append({
                'Variant': variant_name.title(),
                'Feature Count': feature_count,
                'Sample Count': len(variant_df)
            })
        
        stats_df = pd.DataFrame(variant_info)
        st.dataframe(stats_df, use_container_width=True)
        
        # Feature count visualization
        fig = px.bar(stats_df, x='Variant', y='Feature Count', title="Feature Count by Variant")
        st.plotly_chart(fig, use_container_width=True)

if __name__ == "__main__":
    main() 