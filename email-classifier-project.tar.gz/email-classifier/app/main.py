from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from contextlib import asynccontextmanager
import os
import sys
from pathlib import Path

sys.path.append(str(Path(__file__).parent.parent))

from config.settings import settings
from app.routers import classification, health
from app.models.classifier import EmailClassifier
from app.utils.logging import setup_logging


@asynccontextmanager
async def lifespan(app: FastAPI):
    setup_logging()
    
    os.makedirs("data", exist_ok=True)
    os.makedirs("models", exist_ok=True)
    os.makedirs("logs", exist_ok=True)
    
    try:
        classifier = EmailClassifier(model_type=settings.classifier_model_type)
        if os.path.exists(settings.classifier_model_path):
            await classifier.load_model(settings.classifier_model_path)
            print(f"Modelo cargado desde {settings.classifier_model_path}")
        else:
            print(f"No se encontró modelo en {settings.classifier_model_path}")
        
        app.state.classifier = classifier
        
    except Exception as e:
        print(f"Error al inicializar: {e}")
        app.state.classifier = None
    
    yield
    
    if hasattr(app.state, 'classifier') and app.state.classifier:
        await app.state.classifier.cleanup()


app = FastAPI(
    title="📧 Sistema de Clasificación de Emails ML",
    description="""
    ## 🎯 Clasificador Automático de Facturas y Cuentas por Pagar
    
    Este sistema utiliza **Machine Learning** para identificar automáticamente emails que contienen facturas o cuentas por pagar.
    
    ### 🚀 Características principales:
    - **Clasificación en tiempo real** con confianza >87%
    - **API REST** para integración fácil
    - **Procesamiento en lote** para múltiples emails
    - **Explicabilidad** de las decisiones del modelo
    
    ### 📊 Endpoints principales:
    - **`POST /classify/`** - Clasificar un email individual ⭐
    - **`POST /classify/batch`** - Clasificar múltiples emails 
    - **`GET /classify/model/info`** - Información del modelo
    - **`GET /health`** - Estado del sistema
    
    ### 🚀 Ejemplo rápido:
    ```bash
    # Clasificar un email
    curl -X POST "http://localhost:8000/classify/" \\
         -H "Content-Type: application/json" \\
         -d '{"email": {"subject": "Factura pendiente", "body": "Adjuntamos factura por $500", "sender_email": "billing@company.com"}, "include_reasoning": true}'
    ```
    
    ### 🎓 Proyecto académico
    **Obligatorio ML en Producción - ORT Uruguay 2025**  
    **Estudiante:** Rafael Alonso - 201523
    """,
    version="1.0.0",
    contact={
        "name": "Rafael Alonso",
        "email": "rafael.alonso@estudiantes.ort.edu.uy",
    },
    license_info={
        "name": "Academic Project - ORT Uruguay",
    },
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/health", tags=["🏥 Health Check"])
app.include_router(classification.router, prefix="/classify", tags=["🤖 Email Classification"])


@app.get(
    "/",
    summary="🏠 API Home",
    description="Información general del sistema y endpoints disponibles",
    tags=["📋 Info"]
)
async def root():
    """
    ## 🏠 Página principal de la API
    
    Obtiene información general del sistema de clasificación de emails.
    
    ### Respuesta incluye:
    - Estado del sistema
    - Endpoints disponibles  
    - Estado del modelo cargado
    - Información de versión
    """
    classifier = getattr(app.state, 'classifier', None)
    return {
        "🎯": "Sistema de Clasificación de Emails",
        "📊": "API REST para identificar facturas automáticamente",
        "🎓": "Obligatorio ML en Producción - ORT Uruguay",
        "👨‍💻": "Rafael Alonso - 201523",
        "version": "1.0.0",
        "estado": "✅ funcionando",
        "modelo_cargado": "✅ sí" if (classifier and classifier.is_model_loaded()) else "❌ no",
        "📡": {
            "🏥": "/health - Estado del sistema",
            "🤖": "/classify/ - Clasificar un email",
            "📦": "/classify/batch - Clasificar múltiples emails", 
            "ℹ️": "/classify/model/info - Info del modelo",
            "📚": "/docs - Documentación completa",
            "🔄": "/redoc - Documentación alternativa"
        },
        "🎯": {
            "precision": "87.5%",
            "f1_score": "0.825",
            "latencia": "<50ms",
            "confianza": ">0.90"
        }
    }


@app.exception_handler(HTTPException)
async def http_exception_handler(request, exc):
    return JSONResponse(
        status_code=exc.status_code,
        content={"detalle": exc.detail, "estado": "error"}
    )


@app.exception_handler(Exception)
async def general_exception_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"detalle": "Error interno del servidor", "estado": "error"}
    ) 