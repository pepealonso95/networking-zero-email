#!/bin/bash

# 🔧 Script de Troubleshooting para AWS Deployment
# Clasificador de Emails ML - Obligatorio Marzo 2025

set -e

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

echo "🔧 Troubleshooting AWS Deployment..."
echo ""

# Verificar AWS CLI
print_info "1. Verificando AWS CLI..."
if command -v aws &> /dev/null; then
    AWS_VERSION=$(aws --version 2>&1 | head -n1)
    print_success "AWS CLI instalado: $AWS_VERSION"
else
    print_error "AWS CLI no está instalado"
    exit 1
fi

# Verificar credenciales AWS
print_info "2. Verificando credenciales AWS..."
if aws sts get-caller-identity &> /dev/null; then
    ACCOUNT_ID=$(aws sts get-caller-identity --query Account --output text)
    USER_ARN=$(aws sts get-caller-identity --query Arn --output text)
    print_success "Credenciales OK - Account: $ACCOUNT_ID"
    print_info "   User: $USER_ARN"
else
    print_error "Credenciales AWS no válidas"
    echo "   Ejecuta: aws configure"
    exit 1
fi

# Buscar instancias relacionadas al proyecto
print_info "3. Buscando instancias del proyecto..."
INSTANCES=$(aws ec2 describe-instances \
    --filters "Name=tag:Project,Values=ORT-Obligatorio-2025" "Name=instance-state-name,Values=running,pending,stopping,stopped" \
    --query 'Reservations[*].Instances[*].[InstanceId,State.Name,PublicIpAddress,Tags[?Key==`Name`].Value|[0]]' \
    --output table)

if [ -n "$INSTANCES" ] && [ "$INSTANCES" != "None" ]; then
    echo "$INSTANCES"
    
    # Obtener la primera instancia corriendo
    RUNNING_INSTANCE=$(aws ec2 describe-instances \
        --filters "Name=tag:Project,Values=ORT-Obligatorio-2025" "Name=instance-state-name,Values=running" \
        --query 'Reservations[0].Instances[0].InstanceId' \
        --output text 2>/dev/null)
    
    if [ "$RUNNING_INSTANCE" != "None" ] && [ -n "$RUNNING_INSTANCE" ]; then
        INSTANCE_IP=$(aws ec2 describe-instances \
            --instance-ids $RUNNING_INSTANCE \
            --query 'Reservations[0].Instances[0].PublicIpAddress' \
            --output text)
        
        print_success "Instancia corriendo encontrada: $RUNNING_INSTANCE"
        print_info "   IP Pública: $INSTANCE_IP"
        
        # Crear deployment-info.json temporal
        print_info "4. Creando deployment-info.json..."
        cat > deployment-info.json << EOF
{
  "instance_id": "$RUNNING_INSTANCE",
  "public_ip": "$INSTANCE_IP",
  "dashboard_url": "http://${INSTANCE_IP}:8501",
  "api_url": "http://${INSTANCE_IP}:8000",
  "api_docs_url": "http://${INSTANCE_IP}:8000/docs"
}
EOF
        print_success "Archivo deployment-info.json creado"
        
        # Probar conectividad
        print_info "5. Probando conectividad..."
        
        # Test basic connectivity
        if ping -c 1 $INSTANCE_IP > /dev/null 2>&1; then
            print_success "Ping OK: $INSTANCE_IP"
        else
            print_warning "Ping falló: $INSTANCE_IP"
        fi
        
        # Test Dashboard
        print_info "6. Probando Dashboard (puerto 8501)..."
        DASHBOARD_STATUS=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 10 "http://${INSTANCE_IP}:8501" || echo "000")
        if [ "$DASHBOARD_STATUS" = "200" ]; then
            print_success "Dashboard OK: http://${INSTANCE_IP}:8501"
        else
            print_warning "Dashboard no responde (código: $DASHBOARD_STATUS)"
            print_info "   URL: http://${INSTANCE_IP}:8501"
        fi
        
        # Test API
        print_info "7. Probando API (puerto 8000)..."
        API_STATUS=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 10 "http://${INSTANCE_IP}:8000/health" || echo "000")
        if [ "$API_STATUS" = "200" ]; then
            print_success "API OK: http://${INSTANCE_IP}:8000"
        else
            print_warning "API no responde (código: $API_STATUS)"
            print_info "   URL: http://${INSTANCE_IP}:8000"
            print_info "   Docs: http://${INSTANCE_IP}:8000/docs"
        fi
        
        echo ""
        echo "🎯 URLs a probar:"
        echo "   📊 Dashboard: http://${INSTANCE_IP}:8501"
        echo "   🚀 API: http://${INSTANCE_IP}:8000"
        echo "   📚 API Docs: http://${INSTANCE_IP}:8000/docs"
        echo ""
        
        # Comandos de debugging
        echo "🔧 Comandos de debugging:"
        echo ""
        echo "# Conectar por SSH (si tienes la key):"
        echo "ssh -i email-classifier-key.pem ec2-user@${INSTANCE_IP}"
        echo ""
        echo "# Ver logs remotamente:"
        echo "curl http://${INSTANCE_IP}:8000/logs 2>/dev/null || echo 'No logs endpoint'"
        echo ""
        echo "# Verificar puertos abiertos:"
        echo "nmap -p 22,8000,8501 ${INSTANCE_IP}"
        
        # Si los servicios no responden, dar troubleshooting tips
        if [ "$DASHBOARD_STATUS" != "200" ] || [ "$API_STATUS" != "200" ]; then
            echo ""
            print_warning "🚨 Servicios no responden. Posibles causas:"
            echo "   1. Los servicios aún están iniciando (espera 5-10 minutos)"
            echo "   2. Error en la instalación (revisar logs via SSH)"
            echo "   3. Problemas de security group (puertos no abiertos)"
            echo "   4. Error en el user-data script"
            echo ""
            echo "💡 Ejecuta este script nuevamente en 5 minutos"
        fi
        
    else
        print_warning "No hay instancias corriendo del proyecto"
    fi
else
    print_warning "No se encontraron instancias del proyecto"
    echo ""
    echo "💡 Posibles acciones:"
    echo "   1. Ejecutar deployment: ./aws/deploy.sh"
    echo "   2. Verificar que usaste el tag correcto en la instancia"
fi

echo ""
print_info "Troubleshooting completado" 