#!/bin/bash

# 🔍 Script de Verificación de Deployment
# Clasificador de Emails ML - AWS Academy

set -e

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar si existe deployment-info.json
if [ ! -f "deployment-info.json" ]; then
    print_error "No se encontró deployment-info.json. ¿Has ejecutado el deployment?"
    exit 1
fi

# Leer información del deployment (sin jq para evitar dependencia)
INSTANCE_ID=$(grep -o '"instance_id": "[^"]*"' deployment-info.json | cut -d'"' -f4)
PUBLIC_IP=$(grep -o '"public_ip": "[^"]*"' deployment-info.json | cut -d'"' -f4)
DASHBOARD_URL="http://${PUBLIC_IP}:8501"
API_URL="http://${PUBLIC_IP}:8000"

echo "🔍 Verificando deployment..."
echo ""

# Verificar estado de la instancia EC2
print_info "Verificando instancia EC2..."
INSTANCE_STATE=$(aws ec2 describe-instances \
    --instance-ids $INSTANCE_ID \
    --query 'Reservations[0].Instances[0].State.Name' \
    --output text)

if [ "$INSTANCE_STATE" = "running" ]; then
    print_success "Instancia EC2 corriendo: $INSTANCE_ID"
else
    print_warning "Instancia EC2 en estado: $INSTANCE_STATE"
fi

# Verificar conectividad básica
print_info "Verificando conectividad de red..."
if ping -c 1 $PUBLIC_IP > /dev/null 2>&1; then
    print_success "Conectividad de red OK: $PUBLIC_IP"
else
    print_warning "Problemas de conectividad con: $PUBLIC_IP"
fi

# Verificar Dashboard Streamlit
print_info "Verificando Dashboard Streamlit..."
HTTP_STATUS=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 10 $DASHBOARD_URL || echo "000")
if [ "$HTTP_STATUS" = "200" ]; then
    print_success "Dashboard Streamlit disponible: $DASHBOARD_URL"
elif [ "$HTTP_STATUS" = "000" ]; then
    print_warning "Dashboard no responde (todavía iniciando?): $DASHBOARD_URL"
else
    print_warning "Dashboard responde con código: $HTTP_STATUS"
fi

# Verificar API FastAPI
print_info "Verificando API FastAPI..."
API_STATUS=$(curl -s -o /dev/null -w "%{http_code}" --connect-timeout 10 "${API_URL}/health" || echo "000")
if [ "$API_STATUS" = "200" ]; then
    print_success "API FastAPI disponible: $API_URL"
elif [ "$API_STATUS" = "000" ]; then
    print_warning "API no responde (todavía iniciando?): $API_URL"
else
    print_warning "API responde con código: $API_STATUS"
fi

echo ""
echo "📊 Resumen del Deployment:"
echo "   🖥️  Instancia: $INSTANCE_ID ($INSTANCE_STATE)"
echo "   🌐 IP Pública: $PUBLIC_IP"
echo "   📈 Dashboard: $DASHBOARD_URL"
echo "   🚀 API: $API_URL"
echo "   📚 API Docs: ${API_URL}/docs"
echo ""

# Mostrar comandos útiles
echo "🔧 Comandos útiles:"
echo ""
echo "# Conectar por SSH:"
echo "ssh -i email-classifier-key.pem ec2-user@$PUBLIC_IP"
echo ""
echo "# Ver logs del dashboard:"
echo "ssh -i email-classifier-key.pem ec2-user@$PUBLIC_IP 'tail -f ~/obligatorio-marzo-2025-alonso/dashboard.log'"
echo ""
echo "# Ver logs de la API:"
echo "ssh -i email-classifier-key.pem ec2-user@$PUBLIC_IP 'tail -f ~/obligatorio-marzo-2025-alonso/api.log'"
echo ""

# Verificar si los servicios están completamente listos
if [ "$HTTP_STATUS" = "200" ] && [ "$API_STATUS" = "200" ]; then
    print_success "🎉 ¡Deployment completamente funcional!"
    echo ""
    echo "🎯 Accede a tu proyecto:"
    echo "   📊 Dashboard: $DASHBOARD_URL"
    echo "   🔗 API Docs: ${API_URL}/docs"
elif [ "$INSTANCE_STATE" = "running" ]; then
    print_warning "⏰ Servicios todavía iniciando... Espera 2-3 minutos más"
    echo ""
    echo "💡 Ejecuta este script nuevamente en unos minutos:"
    echo "   ./aws/check-deployment.sh"
else
    print_error "❌ Hay problemas con el deployment"
fi
