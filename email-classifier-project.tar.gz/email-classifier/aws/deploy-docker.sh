#!/bin/bash

# 🐳 Script de Deployment Docker para AWS Academy
# Clasificador de Emails ML - Obligatorio Marzo 2025
# Rafael Alonso - ORT Uruguay

set -e

echo "🐳 Iniciando deployment con Docker en AWS Academy..."

# Configuración
PROJECT_NAME="email-classifier-ml"
REGION="us-east-1"
INSTANCE_TYPE="t3.medium"
KEY_NAME="email-classifier-key"

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar AWS CLI
if ! command -v aws &> /dev/null; then
    print_error "AWS CLI no está instalado. Instálalo primero."
    exit 1
fi

# Verificar credenciales AWS
print_status "Verificando credenciales AWS..."
if ! aws sts get-caller-identity &> /dev/null; then
    print_error "Credenciales AWS no configuradas. Ejecuta 'aws configure'"
    exit 1
fi

print_success "Credenciales AWS verificadas"

# Crear security group
print_status "Creando security group..."
SECURITY_GROUP_ID=$(aws ec2 create-security-group \
    --group-name ${PROJECT_NAME}-docker-sg \
    --description "Security group for Email Classifier ML with Docker" \
    --query 'GroupId' \
    --output text 2>/dev/null || aws ec2 describe-security-groups \
    --group-names ${PROJECT_NAME}-docker-sg \
    --query 'SecurityGroups[0].GroupId' \
    --output text)

print_success "Security Group ID: $SECURITY_GROUP_ID"

# Configurar reglas de security group
print_status "Configurando reglas de firewall..."

# SSH (puerto 22)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 22 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# Streamlit Dashboard (puerto 8501)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 8501 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# FastAPI (puerto 8000)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 8000 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# Redis (puerto 6380)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 6380 \
    --cidr 0.0.0.0/0 2>/dev/null || true

print_success "Reglas de firewall configuradas"

# Crear key pair si no existe
print_status "Configurando key pair..."
if ! aws ec2 describe-key-pairs --key-names $KEY_NAME &> /dev/null; then
    aws ec2 create-key-pair \
        --key-name $KEY_NAME \
        --query 'KeyMaterial' \
        --output text > ${KEY_NAME}.pem
    chmod 400 ${KEY_NAME}.pem
    print_success "Key pair creado: ${KEY_NAME}.pem"
else
    print_warning "Key pair ya existe: $KEY_NAME"
fi

# Crear user data script con Docker
print_status "Creando script de inicialización con Docker..."
cat > user-data-docker.sh << 'EOF'
#!/bin/bash

# Log para debugging
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

echo "🐳 Iniciando configuración con Docker..."

# Actualizar sistema
yum update -y

# Instalar Docker
yum install -y docker git htop

# Iniciar Docker y configurar para arranque automático
systemctl start docker
systemctl enable docker

# Agregar ec2-user al grupo docker
usermod -a -G docker ec2-user

# Instalar Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

# Verificar instalación
docker --version
docker-compose --version

# Cambiar a ec2-user para las operaciones siguientes
cd /home/ec2-user

# Clonar el repositorio del proyecto
echo "📥 Clonando repositorio del proyecto..."
sudo -u ec2-user git clone https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso.git email-classifier 2>/dev/null || \
sudo -u ec2-user wget -O repo.zip https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso/archive/refs/heads/main.zip && \
sudo -u ec2-user unzip repo.zip && sudo -u ec2-user mv obligatorio-marzo-2025-alonso-main email-classifier

# Verificar que el proyecto se clonó correctamente
if [ ! -d "email-classifier" ]; then
    echo "❌ Error: No se pudo clonar el repositorio"
    exit 1
fi

cd email-classifier

# Crear archivo .env si no existe
if [ ! -f ".env" ]; then
    sudo -u ec2-user cp env.example .env 2>/dev/null || sudo -u ec2-user cat > .env << 'ENVFILE'
# Environment Configuration
ENVIRONMENT=production
PYTHONPATH=/app

# Redis Configuration
REDIS_URL=redis://redis:6379

# Model Configuration
MODEL_PATH=./models/logistic_regression_model.pkl

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000

# OpenAI API Key (opcional para funcionalidades avanzadas)
# OPENAI_API_KEY=your_api_key_here
ENVFILE
fi

# Asegurar permisos correctos
chown -R ec2-user:ec2-user /home/ec2-user/email-classifier

# Crear script para verificar estado
sudo -u ec2-user cat > check-services.sh << 'CHECKSCRIPT'
#!/bin/bash
echo "🔍 Verificando estado de servicios Docker..."
docker-compose ps
echo ""
echo "📊 URLs disponibles:"
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
echo "🚀 API: http://${PUBLIC_IP}:8000"
echo "📚 API Docs: http://${PUBLIC_IP}:8000/docs"
echo "📊 Dashboard: http://${PUBLIC_IP}:8501"
echo "🔧 Redis: http://${PUBLIC_IP}:6380"
CHECKSCRIPT

chmod +x check-services.sh

# Construir y lanzar servicios con Docker Compose
echo "🏗️ Construyendo imagen Docker..."
sudo -u ec2-user docker-compose build

echo "🚀 Iniciando servicios con Docker Compose..."
sudo -u ec2-user docker-compose up -d

# Esperar a que los servicios estén listos
echo "⏳ Esperando que los servicios estén listos..."
sleep 30

# Verificar que los servicios están corriendo
echo "✅ Verificando servicios..."
sudo -u ec2-user docker-compose ps

# Obtener IP pública para mostrar URLs
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Crear información de deployment
sudo -u ec2-user cat > deployment-info.txt << DEPLOYINFO
🎉 Deployment completado exitosamente con Docker!

📊 Servicios disponibles:
🚀 API: http://${PUBLIC_IP}:8000
📚 API Docs: http://${PUBLIC_IP}:8000/docs  
📊 Dashboard: http://${PUBLIC_IP}:8501
🔧 Redis: http://${PUBLIC_IP}:6380

🐳 Comandos útiles:
- Ver logs: docker-compose logs -f
- Reiniciar servicios: docker-compose restart
- Parar servicios: docker-compose down
- Ver estado: docker-compose ps
- Ver script: ./check-services.sh

📁 Ubicación del proyecto: /home/ec2-user/email-classifier
DEPLOYINFO

echo "✅ Deployment con Docker completado!"
echo "📄 Información guardada en deployment-info.txt"

# Mostrar información final
cat deployment-info.txt

EOF

# Lanzar instancia EC2
print_status "Lanzando instancia EC2 con Docker..."
INSTANCE_ID=$(aws ec2 run-instances \
    --image-id ami-0c02fb55956c7d316 \
    --count 1 \
    --instance-type $INSTANCE_TYPE \
    --key-name $KEY_NAME \
    --security-group-ids $SECURITY_GROUP_ID \
    --user-data file://user-data-docker.sh \
    --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${PROJECT_NAME}-docker},{Key=Project,Value=ORT-Obligatorio-2025},{Key=DeploymentType,Value=Docker}]" \
    --query 'Instances[0].InstanceId' \
    --output text)

print_success "Instancia EC2 lanzada: $INSTANCE_ID"

# Esperar que la instancia esté corriendo
print_status "Esperando que la instancia inicie..."
aws ec2 wait instance-running --instance-ids $INSTANCE_ID

# Obtener IP pública
PUBLIC_IP=$(aws ec2 describe-instances \
    --instance-ids $INSTANCE_ID \
    --query 'Reservations[0].Instances[0].PublicIpAddress' \
    --output text)

print_success "Instancia corriendo en IP: $PUBLIC_IP"

# Guardar información del deployment
print_status "Guardando información del deployment..."
cat > deployment-info-docker.json << EOF
{
  "deployment_type": "docker",
  "instance_id": "$INSTANCE_ID",
  "public_ip": "$PUBLIC_IP",
  "key_name": "$KEY_NAME",
  "security_group_id": "$SECURITY_GROUP_ID",
  "region": "$REGION",
  "instance_type": "$INSTANCE_TYPE",
  "deployment_date": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "urls": {
    "api": "http://$PUBLIC_IP:8000",
    "docs": "http://$PUBLIC_IP:8000/docs",
    "dashboard": "http://$PUBLIC_IP:8501",
    "redis": "http://$PUBLIC_IP:6380"
  },
  "ssh_command": "ssh -i $KEY_NAME.pem ec2-user@$PUBLIC_IP",
  "docker_commands": {
    "logs": "docker-compose logs -f",
    "restart": "docker-compose restart", 
    "status": "docker-compose ps",
    "stop": "docker-compose down"
  }
}
EOF

print_success "Información guardada en deployment-info-docker.json"

echo ""
echo "🎉 ¡Deployment con Docker iniciado exitosamente!"
echo ""
echo "📊 URLs de acceso:"
echo "🚀 API: http://$PUBLIC_IP:8000"
echo "📚 API Docs: http://$PUBLIC_IP:8000/docs"  
echo "📊 Dashboard: http://$PUBLIC_IP:8501"
echo "🔧 Redis: http://$PUBLIC_IP:6380"
echo ""
echo "🔑 Conectar via SSH:"
echo "ssh -i $KEY_NAME.pem ec2-user@$PUBLIC_IP"
echo ""
echo "⏳ Los servicios tardarán 2-3 minutos en estar completamente listos."
echo "💡 Usa 'docker-compose logs -f' en el servidor para ver el progreso."
echo ""
echo "📄 Información completa guardada en: deployment-info-docker.json" 