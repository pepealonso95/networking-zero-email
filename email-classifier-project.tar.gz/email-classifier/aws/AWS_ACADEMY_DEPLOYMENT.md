# 🚀 Deployment en AWS Academy

**Guía Paso a Paso para Desplegar el Clasificador de Emails ML**  
*Obligatorio Marzo 2025 - Rafael Alonso - ORT Uruguay*

## 📋 Prerrequisitos

### 1. Acceso a AWS Academy
- Tener acceso al laboratorio de AWS Academy
- Credenciales AWS configuradas
- Presupuesto de $100 USD disponible

### 2. Herramientas Locales
```bash
# Verificar instalaciones necesarias
aws --version          # AWS CLI v2
git --version          # Git
curl --version         # cURL para verificaciones
```

### 3. Configuración Inicial
```bash
# Configurar AWS CLI con credenciales del laboratorio
aws configure

# Verificar acceso
aws sts get-caller-identity
```

## 🎯 Deployment Automático (Recomendado)

### Paso 1: Clonar el Repositorio
```bash
# Clonar el proyecto
git clone https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso.git
cd obligatorio-marzo-2025-alonso
```

### Paso 2: Ejecutar Deployment
```bash
# Ejecutar deployment automático
./aws/deploy.sh
```

**⏰ Tiempo estimado:** 8-12 minutos

### Paso 3: Verificar Deployment
```bash
# Verificar estado (ejecutar después de 5 minutos)
./aws/check-deployment.sh
```

### Paso 4: Acceder al Proyecto
El script mostrará las URLs de acceso:
- **📊 Dashboard Streamlit:** `http://IP_PUBLICA:8501`
- **🚀 API FastAPI:** `http://IP_PUBLICA:8000`
- **📚 API Docs:** `http://IP_PUBLICA:8000/docs`

## 📊 Costos Estimados en AWS Academy

### Recursos Utilizados
- **EC2 t3.medium:** ~$0.04/hora
- **Almacenamiento EBS:** ~$0.10/mes (8GB)
- **Transferencia de datos:** ~$0.01/GB

### Estimación Mensual
- **Uso 8 horas/día:** ~$10/mes
- **Uso 24/7:** ~$30/mes
- **Total con datos:** ~$35/mes máximo

⚠️ **AWS Academy:** Presupuesto de $100 es suficiente para todo el semestre

## 🧹 Limpieza de Recursos

### Limpieza Automática
```bash
# Ejecutar script de limpieza
./aws/cleanup.sh
```

## 🎓 Entrega del Obligatorio

### Elementos para Incluir
1. **URL del Dashboard:** `http://IP:8501`
2. **URL de la API:** `http://IP:8000`
3. **Repositorio GitHub:** https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso
4. **Screenshots** del dashboard funcionando
5. **Documento** con explicación técnica

¡Éxito con tu obligatorio! 🎉
