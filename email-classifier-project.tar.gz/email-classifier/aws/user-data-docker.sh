#!/bin/bash

# Log para debugging
exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1

echo "🐳 Iniciando configuración con Docker..."

# Actualizar sistema
yum update -y

# Instalar Docker
yum install -y docker git htop

# Iniciar Docker y configurar para arranque automático
systemctl start docker
systemctl enable docker

# Agregar ec2-user al grupo docker
usermod -a -G docker ec2-user

# Instalar Docker Compose
curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
chmod +x /usr/local/bin/docker-compose
ln -s /usr/local/bin/docker-compose /usr/bin/docker-compose

# Verificar instalación
docker --version
docker-compose --version

# Cambiar a ec2-user para las operaciones siguientes
cd /home/ec2-user

# Clonar el repositorio del proyecto
echo "📥 Clonando repositorio del proyecto..."
sudo -u ec2-user git clone https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso.git email-classifier 2>/dev/null || \
sudo -u ec2-user wget -O repo.zip https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso/archive/refs/heads/main.zip && \
sudo -u ec2-user unzip repo.zip && sudo -u ec2-user mv obligatorio-marzo-2025-alonso-main email-classifier

# Verificar que el proyecto se clonó correctamente
if [ ! -d "email-classifier" ]; then
    echo "❌ Error: No se pudo clonar el repositorio"
    exit 1
fi

cd email-classifier

# Crear archivo .env si no existe
if [ ! -f ".env" ]; then
    sudo -u ec2-user cp env.example .env 2>/dev/null || sudo -u ec2-user cat > .env << 'ENVFILE'
# Environment Configuration
ENVIRONMENT=production
PYTHONPATH=/app

# Redis Configuration
REDIS_URL=redis://redis:6379

# Model Configuration
MODEL_PATH=./models/logistic_regression_model.pkl

# API Configuration
API_HOST=0.0.0.0
API_PORT=8000

# OpenAI API Key (opcional para funcionalidades avanzadas)
# OPENAI_API_KEY=your_api_key_here
ENVFILE
fi

# Asegurar permisos correctos
chown -R ec2-user:ec2-user /home/ec2-user/email-classifier

# Crear script para verificar estado
sudo -u ec2-user cat > check-services.sh << 'CHECKSCRIPT'
#!/bin/bash
echo "🔍 Verificando estado de servicios Docker..."
docker-compose ps
echo ""
echo "📊 URLs disponibles:"
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)
echo "🚀 API: http://${PUBLIC_IP}:8000"
echo "📚 API Docs: http://${PUBLIC_IP}:8000/docs"
echo "📊 Dashboard: http://${PUBLIC_IP}:8501"
echo "🔧 Redis: http://${PUBLIC_IP}:6380"
CHECKSCRIPT

chmod +x check-services.sh

# Construir y lanzar servicios con Docker Compose
echo "🏗️ Construyendo imagen Docker..."
sudo -u ec2-user docker-compose build

echo "🚀 Iniciando servicios con Docker Compose..."
sudo -u ec2-user docker-compose up -d

# Esperar a que los servicios estén listos
echo "⏳ Esperando que los servicios estén listos..."
sleep 30

# Verificar que los servicios están corriendo
echo "✅ Verificando servicios..."
sudo -u ec2-user docker-compose ps

# Obtener IP pública para mostrar URLs
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Crear información de deployment
sudo -u ec2-user cat > deployment-info.txt << DEPLOYINFO
🎉 Deployment completado exitosamente con Docker!

📊 Servicios disponibles:
🚀 API: http://${PUBLIC_IP}:8000
📚 API Docs: http://${PUBLIC_IP}:8000/docs  
📊 Dashboard: http://${PUBLIC_IP}:8501
🔧 Redis: http://${PUBLIC_IP}:6380

🐳 Comandos útiles:
- Ver logs: docker-compose logs -f
- Reiniciar servicios: docker-compose restart
- Parar servicios: docker-compose down
- Ver estado: docker-compose ps
- Ver script: ./check-services.sh

📁 Ubicación del proyecto: /home/ec2-user/email-classifier
DEPLOYINFO

echo "✅ Deployment con Docker completado!"
echo "📄 Información guardada en deployment-info.txt"

# Mostrar información final
cat deployment-info.txt

