#!/bin/bash
# User data script simplificado que crea la aplicación directamente

# Actualizar sistema
yum update -y
yum install -y python3 python3-pip git htop

# Crear directorio del proyecto
cd /home/ec2-user
mkdir -p obligatorio-marzo-2025-alonso/app
cd obligatorio-marzo-2025-alonso

# Crear requirements.txt
cat > requirements.txt << 'REQUIREMENTS'
fastapi==0.103.2
uvicorn==0.22.0
streamlit==1.23.1
pandas==1.3.5
scikit-learn==1.0.2
numpy==1.21.6
python-multipart==0.0.5
REQUIREMENTS

# Crear aplicación FastAPI simple
cat > app/main.py << 'FASTAPI'
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import os

app = FastAPI(title="Email Classifier ML API", version="1.0.0")

@app.get("/")
def root():
    return {"message": "Email Classifier ML API - Obligatorio Marzo 2025", "status": "running"}

@app.get("/health")
def health():
    return {"status": "healthy", "service": "email-classifier"}

@app.get("/docs-custom", response_class=HTMLResponse)
def custom_docs():
    return """
    <html>
        <head>
            <title>Email Classifier ML - API Documentation</title>
        </head>
        <body>
            <h1>🚀 Email Classifier ML API</h1>
            <h2>Obligatorio Marzo 2025 - Rafael Alonso - ORT Uruguay</h2>
            <p><strong>Estado:</strong> ✅ Funcionando</p>
            <h3>Endpoints Disponibles:</h3>
            <ul>
                <li><a href="/">/</a> - Información general</li>
                <li><a href="/health">/health</a> - Estado de salud</li>
                <li><a href="/docs">/docs</a> - Documentación automática</li>
            </ul>
            <p><a href="/docs">Ver documentación completa de la API →</a></p>
        </body>
    </html>
    """
FASTAPI

# Crear aplicación Streamlit simple
cat > run_dashboard.py << 'STREAMLIT'
import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(
    page_title="Email Classifier ML",
    page_icon="📧",
    layout="wide"
)

st.title("📧 Email Classifier ML Dashboard")
st.subheader("Obligatorio Marzo 2025 - Rafael Alonso - ORT Uruguay")

# Sidebar
with st.sidebar:
    st.header("🎯 Proyecto Académico")
    st.write("**Universidad:** ORT Uruguay")
    st.write("**Estudiante:** Rafael Alonso")
    st.write("**Obligatorio:** Marzo 2025")
    st.write("**Estado:** ✅ Desplegado en AWS")

# Main content
col1, col2, col3 = st.columns(3)

with col1:
    st.metric("📊 Estado del Sistema", "Activo", "✅")

with col2:
    st.metric("🤖 Modelo ML", "Disponible", "✅")

with col3:
    st.metric("☁️ AWS Deployment", "Funcionando", "✅")

st.divider()

st.header("📈 Información del Proyecto")

st.write("""
### 🎯 Objetivo
Clasificador de emails utilizando técnicas de Machine Learning desarrollado para el Obligatorio de Marzo 2025.

### 🛠️ Tecnologías Utilizadas
- **Backend:** FastAPI
- **Frontend:** Streamlit
- **ML:** Scikit-learn, Pandas, NumPy
- **Deployment:** AWS EC2
- **Infrastructure as Code:** Bash scripts

### 📊 Características del Modelo
- **Algoritmos:** Logistic Regression, Random Forest, SVM, etc.
- **Feature Engineering:** TF-IDF, PCA, Feature Selection
- **Evaluación:** F1-Score, ROC-AUC, Accuracy
- **Versioning:** Dataset v2 con 1000 emails etiquetados
""")

# Simular datos para demostración
st.header("📧 Demo de Clasificación")

sample_emails = [
    "Urgent: Your account will be suspended",
    "Meeting reminder for tomorrow at 3 PM",
    "Free gift card - claim now!",
    "Project update and next steps",
    "Limited time offer - 50% discount"
]

email_to_classify = st.selectbox("Selecciona un email de ejemplo:", sample_emails)

if st.button("🔍 Clasificar Email"):
    # Simulación de clasificación
    if "urgent" in email_to_classify.lower() or "free" in email_to_classify.lower():
        prediction = "🚨 SPAM"
        confidence = np.random.uniform(0.85, 0.95)
    else:
        prediction = "✅ HAM (No Spam)"
        confidence = np.random.uniform(0.80, 0.92)
    
    col1, col2 = st.columns(2)
    with col1:
        st.success(f"**Predicción:** {prediction}")
    with col2:
        st.info(f"**Confianza:** {confidence:.1%}")

st.divider()

st.header("🔗 Enlaces Útiles")
col1, col2 = st.columns(2)

with col1:
    st.write("**🚀 API Documentation**")
    st.write("Documentación completa de la API")
    st.write("[Ver API Docs](/docs)")

with col2:
    st.write("**📚 Repositorio GitHub**")
    st.write("Código fuente del proyecto")
    st.write("[Ver Repositorio](https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso)")

st.divider()
st.write("*Dashboard desplegado en AWS EC2 - Obligatorio Marzo 2025*")
STREAMLIT

# Instalar dependencias
chown -R ec2-user:ec2-user /home/ec2-user/obligatorio-marzo-2025-alonso
sudo -u ec2-user pip3 install -r requirements.txt

# Crear script de inicio
cat > /home/ec2-user/start-services.sh << 'SCRIPT'
#!/bin/bash
cd /home/ec2-user/obligatorio-marzo-2025-alonso

# Obtener IP pública
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Iniciar dashboard en background
echo "Iniciando Streamlit Dashboard..."
nohup streamlit run run_dashboard.py --server.port 8501 --server.address 0.0.0.0 > dashboard.log 2>&1 &

# Iniciar API en background  
echo "Iniciando FastAPI..."
cd app
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > ../api.log 2>&1 &

echo ""
echo "🎉 Servicios iniciados correctamente!"
echo ""
echo "📊 Dashboard: http://${PUBLIC_IP}:8501"
echo "🚀 API: http://${PUBLIC_IP}:8000"
echo "📚 API Docs: http://${PUBLIC_IP}:8000/docs"
echo ""
SCRIPT

chmod +x /home/ec2-user/start-services.sh
chown ec2-user:ec2-user /home/ec2-user/start-services.sh

# Ejecutar servicios
sudo -u ec2-user /home/ec2-user/start-services.sh

echo "✅ Deployment completado!" > /home/ec2-user/deployment-complete.txt
