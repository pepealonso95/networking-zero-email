#!/bin/bash

# 🚀 Script de Deployment para AWS Academy
# Clasificador de Emails ML - Obligatorio Marzo 2025
# Rafael Alonso - ORT Uruguay

set -e

echo "�� Iniciando deployment en AWS Academy..."

# Configuración
PROJECT_NAME="email-classifier-ml"
REGION="us-east-1"
INSTANCE_TYPE="t3.medium"
KEY_NAME="email-classifier-key"

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar AWS CLI
if ! command -v aws &> /dev/null; then
    print_error "AWS CLI no está instalado. Instálalo primero."
    exit 1
fi

# Verificar credenciales AWS
print_status "Verificando credenciales AWS..."
if ! aws sts get-caller-identity &> /dev/null; then
    print_error "Credenciales AWS no configuradas. Ejecuta 'aws configure'"
    exit 1
fi

print_success "Credenciales AWS verificadas"

# Crear security group
print_status "Creando security group..."
SECURITY_GROUP_ID=$(aws ec2 create-security-group \
    --group-name ${PROJECT_NAME}-sg \
    --description "Security group for Email Classifier ML" \
    --query 'GroupId' \
    --output text 2>/dev/null || aws ec2 describe-security-groups \
    --group-names ${PROJECT_NAME}-sg \
    --query 'SecurityGroups[0].GroupId' \
    --output text)

print_success "Security Group ID: $SECURITY_GROUP_ID"

# Configurar reglas de security group
print_status "Configurando reglas de firewall..."

# SSH (puerto 22)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 22 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# Streamlit Dashboard (puerto 8501)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 8501 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# FastAPI (puerto 8000)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 8000 \
    --cidr 0.0.0.0/0 2>/dev/null || true

print_success "Reglas de firewall configuradas"

# Crear key pair si no existe
print_status "Configurando key pair..."
if ! aws ec2 describe-key-pairs --key-names $KEY_NAME &> /dev/null; then
    aws ec2 create-key-pair \
        --key-name $KEY_NAME \
        --query 'KeyMaterial' \
        --output text > ${KEY_NAME}.pem
    chmod 400 ${KEY_NAME}.pem
    print_success "Key pair creado: ${KEY_NAME}.pem"
else
    print_warning "Key pair ya existe: $KEY_NAME"
fi

# Crear user data script
print_status "Creando script de inicialización..."
cat > user-data.sh << 'EOF'
#!/bin/bash
# User data script para instalar el proyecto

# Actualizar sistema
yum update -y
yum install -y docker git htop unzip wget

# Instalar Python 3.9
amazon-linux-extras install python3.8 -y
pip3 install --upgrade pip

# Clonar proyecto
cd /home/ec2-user
sudo -u ec2-user git clone https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso.git || \
sudo -u ec2-user git clone git://github.com/ORTMLProd/obligatorio-marzo-2025-alonso.git || \
sudo -u ec2-user wget -O repo.zip https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso/archive/refs/heads/main.zip && \
sudo -u ec2-user unzip repo.zip && sudo -u ec2-user mv obligatorio-marzo-2025-alonso-main obligatorio-marzo-2025-alonso

# Verificar que el proyecto se clonó correctamente
if [ ! -d "obligatorio-marzo-2025-alonso" ]; then
    echo "Error: No se pudo clonar el repositorio"
    exit 1
fi

cd obligatorio-marzo-2025-alonso

# Instalar dependencias
sudo -u ec2-user pip3 install -r requirements.txt

# Crear archivo de environment
sudo -u ec2-user cp env.example .env

# Crear script de inicio automático
cat > /home/ec2-user/start-services.sh << 'SCRIPT'
#!/bin/bash
cd /home/ec2-user/obligatorio-marzo-2025-alonso

# Iniciar dashboard en background
nohup python3 run_dashboard.py > dashboard.log 2>&1 &

# Iniciar API en background  
cd app
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > ../api.log 2>&1 &

echo "Servicios iniciados:"
echo "- Dashboard: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):8501"
echo "- API: http://$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4):8000"
SCRIPT

chmod +x /home/ec2-user/start-services.sh
chown ec2-user:ec2-user /home/ec2-user/start-services.sh

# Ejecutar servicios
sudo -u ec2-user /home/ec2-user/start-services.sh

echo "Deployment completado!" > /home/ec2-user/deployment-complete.txt
EOF

# Lanzar instancia EC2
print_status "Lanzando instancia EC2..."
INSTANCE_ID=$(aws ec2 run-instances \
    --image-id ami-0c02fb55956c7d316 \
    --count 1 \
    --instance-type $INSTANCE_TYPE \
    --key-name $KEY_NAME \
    --security-group-ids $SECURITY_GROUP_ID \
    --user-data file://user-data.sh \
    --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${PROJECT_NAME}},{Key=Project,Value=ORT-Obligatorio-2025}]" \
    --query 'Instances[0].InstanceId' \
    --output text)

print_success "Instancia EC2 lanzada: $INSTANCE_ID"

# Esperar que la instancia esté corriendo
print_status "Esperando que la instancia inicie..."
aws ec2 wait instance-running --instance-ids $INSTANCE_ID

# Obtener IP pública
PUBLIC_IP=$(aws ec2 describe-instances \
    --instance-ids $INSTANCE_ID \
    --query 'Reservations[0].Instances[0].PublicIpAddress' \
    --output text)

print_success "Instancia corriendo en IP: $PUBLIC_IP"

# Guardar información del deployment
print_status "Guardando información del deployment..."
cat > deployment-info.json << EOF
{
  "instance_id": "$INSTANCE_ID",
  "public_ip": "$PUBLIC_IP",
  "security_group_id": "$SECURITY_GROUP_ID",
  "key_name": "$KEY_NAME",
  "region": "$REGION",
  "instance_type": "$INSTANCE_TYPE",
  "deployment_time": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "dashboard_url": "http://${PUBLIC_IP}:8501",
  "api_url": "http://${PUBLIC_IP}:8000",
  "api_docs_url": "http://${PUBLIC_IP}:8000/docs"
}
EOF

print_success "Información guardada en deployment-info.json"

# Mostrar información de conexión
echo ""
echo "🎉 ¡Deployment completado exitosamente!"
echo ""
echo "📋 Información de la instancia:"
echo "   Instance ID: $INSTANCE_ID"
echo "   Public IP: $PUBLIC_IP"
echo "   Security Group: $SECURITY_GROUP_ID"
echo ""
echo "🔗 URLs de acceso (disponibles en ~5 minutos):"
echo "   📊 Dashboard Streamlit: http://${PUBLIC_IP}:8501"
echo "   🚀 API FastAPI: http://${PUBLIC_IP}:8000"
echo "   📚 API Docs: http://${PUBLIC_IP}:8000/docs"
echo ""
echo "🔑 Conexión SSH:"
echo "   ssh -i ${KEY_NAME}.pem ec2-user@${PUBLIC_IP}"
echo ""
echo "📝 Para verificar el deployment:"
echo "   ./aws/check-deployment.sh"
echo ""
echo "⏰ Los servicios tardan ~5 minutos en estar completamente disponibles"

# Guardar información del deployment
cat > deployment-info.json << EOF
{
  "instance_id": "$INSTANCE_ID",
  "public_ip": "$PUBLIC_IP",
  "security_group_id": "$SECURITY_GROUP_ID",
  "key_name": "$KEY_NAME",
  "dashboard_url": "http://${PUBLIC_IP}:8501",
  "api_url": "http://${PUBLIC_IP}:8000",
  "ssh_command": "ssh -i ${KEY_NAME}.pem ec2-user@${PUBLIC_IP}",
  "deployed_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF

print_success "Información del deployment guardada en deployment-info.json"
echo ""
echo "🎯 Para verificar el estado del deployment:"
echo "   ./aws/check-deployment.sh"
