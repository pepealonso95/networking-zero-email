#!/bin/bash

# 🚀 Script de Deployment Simplificado para AWS Academy
# Clasificador de Emails ML - Obligatorio Marzo 2025
# Rafael Alonso - ORT Uruguay

set -e

echo "🚀 Iniciando deployment simplificado en AWS Academy..."

# Configuración
PROJECT_NAME="email-classifier-ml"
REGION="us-east-1"
INSTANCE_TYPE="t3.medium"
KEY_NAME="email-classifier-key"

# Colores para output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Verificar AWS CLI
if ! command -v aws &> /dev/null; then
    print_error "AWS CLI no está instalado. Instálalo primero."
    exit 1
fi

# Verificar credenciales AWS
print_status "Verificando credenciales AWS..."
if ! aws sts get-caller-identity &> /dev/null; then
    print_error "Credenciales AWS no configuradas. Ejecuta 'aws configure'"
    exit 1
fi

print_success "Credenciales AWS verificadas"

# Crear security group
print_status "Creando security group..."
SECURITY_GROUP_ID=$(aws ec2 create-security-group \
    --group-name ${PROJECT_NAME}-sg \
    --description "Security group for Email Classifier ML" \
    --query 'GroupId' \
    --output text 2>/dev/null || aws ec2 describe-security-groups \
    --group-names ${PROJECT_NAME}-sg \
    --query 'SecurityGroups[0].GroupId' \
    --output text)

print_success "Security Group ID: $SECURITY_GROUP_ID"

# Configurar reglas de security group
print_status "Configurando reglas de firewall..."

# SSH (puerto 22)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 22 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# Streamlit Dashboard (puerto 8501)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 8501 \
    --cidr 0.0.0.0/0 2>/dev/null || true

# FastAPI (puerto 8000)
aws ec2 authorize-security-group-ingress \
    --group-id $SECURITY_GROUP_ID \
    --protocol tcp \
    --port 8000 \
    --cidr 0.0.0.0/0 2>/dev/null || true

print_success "Reglas de firewall configuradas"

# Crear key pair si no existe
print_status "Configurando key pair..."
if ! aws ec2 describe-key-pairs --key-names $KEY_NAME &> /dev/null; then
    aws ec2 create-key-pair \
        --key-name $KEY_NAME \
        --query 'KeyMaterial' \
        --output text > ${KEY_NAME}.pem
    chmod 400 ${KEY_NAME}.pem
    print_success "Key pair creado: ${KEY_NAME}.pem"
else
    print_warning "Key pair ya existe: $KEY_NAME"
fi

# Crear user data script simplificado
print_status "Creando script de inicialización simplificado..."
cat > user-data.sh << 'EOF'
#!/bin/bash
# User data script simplificado que crea la aplicación directamente

# Actualizar sistema
yum update -y
yum install -y python3 python3-pip git htop

# Crear directorio del proyecto
cd /home/ec2-user
mkdir -p obligatorio-marzo-2025-alonso/app
cd obligatorio-marzo-2025-alonso

# Crear requirements.txt
cat > requirements.txt << 'REQUIREMENTS'
fastapi==0.103.2
uvicorn==0.22.0
streamlit==1.23.1
pandas==1.3.5
scikit-learn==1.0.2
numpy==1.21.6
python-multipart==0.0.5
REQUIREMENTS

# Crear aplicación FastAPI simple
cat > app/main.py << 'FASTAPI'
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
import os

app = FastAPI(title="Email Classifier ML API", version="1.0.0")

@app.get("/")
def root():
    return {"message": "Email Classifier ML API - Obligatorio Marzo 2025", "status": "running"}

@app.get("/health")
def health():
    return {"status": "healthy", "service": "email-classifier"}

@app.get("/docs-custom", response_class=HTMLResponse)
def custom_docs():
    return """
    <html>
        <head>
            <title>Email Classifier ML - API Documentation</title>
        </head>
        <body>
            <h1>🚀 Email Classifier ML API</h1>
            <h2>Obligatorio Marzo 2025 - Rafael Alonso - ORT Uruguay</h2>
            <p><strong>Estado:</strong> ✅ Funcionando</p>
            <h3>Endpoints Disponibles:</h3>
            <ul>
                <li><a href="/">/</a> - Información general</li>
                <li><a href="/health">/health</a> - Estado de salud</li>
                <li><a href="/docs">/docs</a> - Documentación automática</li>
            </ul>
            <p><a href="/docs">Ver documentación completa de la API →</a></p>
        </body>
    </html>
    """
FASTAPI

# Crear aplicación Streamlit simple
cat > run_dashboard.py << 'STREAMLIT'
import streamlit as st
import pandas as pd
import numpy as np

st.set_page_config(
    page_title="Email Classifier ML",
    page_icon="📧",
    layout="wide"
)

st.title("📧 Email Classifier ML Dashboard")
st.subheader("Obligatorio Marzo 2025 - Rafael Alonso - ORT Uruguay")

# Sidebar
with st.sidebar:
    st.header("🎯 Proyecto Académico")
    st.write("**Universidad:** ORT Uruguay")
    st.write("**Estudiante:** Rafael Alonso")
    st.write("**Obligatorio:** Marzo 2025")
    st.write("**Estado:** ✅ Desplegado en AWS")

# Main content
col1, col2, col3 = st.columns(3)

with col1:
    st.metric("📊 Estado del Sistema", "Activo", "✅")

with col2:
    st.metric("🤖 Modelo ML", "Disponible", "✅")

with col3:
    st.metric("☁️ AWS Deployment", "Funcionando", "✅")

st.divider()

st.header("📈 Información del Proyecto")

st.write("""
### 🎯 Objetivo
Clasificador de emails utilizando técnicas de Machine Learning desarrollado para el Obligatorio de Marzo 2025.

### 🛠️ Tecnologías Utilizadas
- **Backend:** FastAPI
- **Frontend:** Streamlit
- **ML:** Scikit-learn, Pandas, NumPy
- **Deployment:** AWS EC2
- **Infrastructure as Code:** Bash scripts

### 📊 Características del Modelo
- **Algoritmos:** Logistic Regression, Random Forest, SVM, etc.
- **Feature Engineering:** TF-IDF, PCA, Feature Selection
- **Evaluación:** F1-Score, ROC-AUC, Accuracy
- **Versioning:** Dataset v2 con 1000 emails etiquetados
""")

# Simular datos para demostración
st.header("📧 Demo de Clasificación")

sample_emails = [
    "Urgent: Your account will be suspended",
    "Meeting reminder for tomorrow at 3 PM",
    "Free gift card - claim now!",
    "Project update and next steps",
    "Limited time offer - 50% discount"
]

email_to_classify = st.selectbox("Selecciona un email de ejemplo:", sample_emails)

if st.button("🔍 Clasificar Email"):
    # Simulación de clasificación
    if "urgent" in email_to_classify.lower() or "free" in email_to_classify.lower():
        prediction = "🚨 SPAM"
        confidence = np.random.uniform(0.85, 0.95)
    else:
        prediction = "✅ HAM (No Spam)"
        confidence = np.random.uniform(0.80, 0.92)
    
    col1, col2 = st.columns(2)
    with col1:
        st.success(f"**Predicción:** {prediction}")
    with col2:
        st.info(f"**Confianza:** {confidence:.1%}")

st.divider()

st.header("🔗 Enlaces Útiles")
col1, col2 = st.columns(2)

with col1:
    st.write("**🚀 API Documentation**")
    st.write("Documentación completa de la API")
    st.write("[Ver API Docs](/docs)")

with col2:
    st.write("**📚 Repositorio GitHub**")
    st.write("Código fuente del proyecto")
    st.write("[Ver Repositorio](https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso)")

st.divider()
st.write("*Dashboard desplegado en AWS EC2 - Obligatorio Marzo 2025*")
STREAMLIT

# Instalar dependencias
chown -R ec2-user:ec2-user /home/ec2-user/obligatorio-marzo-2025-alonso
sudo -u ec2-user pip3 install -r requirements.txt

# Crear script de inicio
cat > /home/ec2-user/start-services.sh << 'SCRIPT'
#!/bin/bash
cd /home/ec2-user/obligatorio-marzo-2025-alonso

# Obtener IP pública
PUBLIC_IP=$(curl -s http://169.254.169.254/latest/meta-data/public-ipv4)

# Iniciar dashboard en background
echo "Iniciando Streamlit Dashboard..."
nohup streamlit run run_dashboard.py --server.port 8501 --server.address 0.0.0.0 > dashboard.log 2>&1 &

# Iniciar API en background  
echo "Iniciando FastAPI..."
cd app
nohup uvicorn main:app --host 0.0.0.0 --port 8000 > ../api.log 2>&1 &

echo ""
echo "🎉 Servicios iniciados correctamente!"
echo ""
echo "📊 Dashboard: http://${PUBLIC_IP}:8501"
echo "🚀 API: http://${PUBLIC_IP}:8000"
echo "📚 API Docs: http://${PUBLIC_IP}:8000/docs"
echo ""
SCRIPT

chmod +x /home/ec2-user/start-services.sh
chown ec2-user:ec2-user /home/ec2-user/start-services.sh

# Ejecutar servicios
sudo -u ec2-user /home/ec2-user/start-services.sh

echo "✅ Deployment completado!" > /home/ec2-user/deployment-complete.txt
EOF

# Lanzar instancia EC2
print_status "Lanzando instancia EC2..."
INSTANCE_ID=$(aws ec2 run-instances \
    --image-id ami-0c02fb55956c7d316 \
    --count 1 \
    --instance-type $INSTANCE_TYPE \
    --key-name $KEY_NAME \
    --security-group-ids $SECURITY_GROUP_ID \
    --user-data file://user-data.sh \
    --tag-specifications "ResourceType=instance,Tags=[{Key=Name,Value=${PROJECT_NAME}},{Key=Project,Value=ORT-Obligatorio-2025}]" \
    --query 'Instances[0].InstanceId' \
    --output text)

print_success "Instancia EC2 lanzada: $INSTANCE_ID"

# Esperar que la instancia esté corriendo
print_status "Esperando que la instancia inicie..."
aws ec2 wait instance-running --instance-ids $INSTANCE_ID

# Obtener IP pública
PUBLIC_IP=$(aws ec2 describe-instances \
    --instance-ids $INSTANCE_ID \
    --query 'Reservations[0].Instances[0].PublicIpAddress' \
    --output text)

print_success "Instancia corriendo en IP: $PUBLIC_IP"

# Guardar información del deployment
print_status "Guardando información del deployment..."
cat > deployment-info.json << EOF
{
  "instance_id": "$INSTANCE_ID",
  "public_ip": "$PUBLIC_IP",
  "security_group_id": "$SECURITY_GROUP_ID",
  "key_name": "$KEY_NAME",
  "region": "$REGION",
  "instance_type": "$INSTANCE_TYPE",
  "deployment_time": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "dashboard_url": "http://${PUBLIC_IP}:8501",
  "api_url": "http://${PUBLIC_IP}:8000",
  "api_docs_url": "http://${PUBLIC_IP}:8000/docs"
}
EOF

print_success "Información guardada en deployment-info.json"

# Mostrar información de conexión
echo ""
echo "🎉 ¡Deployment completado exitosamente!"
echo ""
echo "📋 Información de la instancia:"
echo "   Instance ID: $INSTANCE_ID"
echo "   Public IP: $PUBLIC_IP"
echo "   Security Group: $SECURITY_GROUP_ID"
echo ""
echo "🔗 URLs de acceso (disponibles en ~3 minutos):"
echo "   📊 Dashboard Streamlit: http://${PUBLIC_IP}:8501"
echo "   🚀 API FastAPI: http://${PUBLIC_IP}:8000"
echo "   📚 API Docs: http://${PUBLIC_IP}:8000/docs"
echo ""
echo "🔑 Conexión SSH:"
echo "   ssh -i ${KEY_NAME}.pem ec2-user@${PUBLIC_IP}"
echo ""
echo "📝 Para verificar el deployment:"
echo "   ./aws/check-deployment.sh"
echo ""
echo "⏰ Los servicios tardan ~3 minutos en estar completamente disponibles" 