#!/bin/bash

# 🧹 Script de Limpieza de Recursos AWS
# Clasificador de Emails ML - AWS Academy

set -e

# Colores
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
BLUE='\033[0;34m'
NC='\033[0m'

print_info() {
    echo -e "${BLUE}[INFO]${NC} $1"
}

print_success() {
    echo -e "${GREEN}[SUCCESS]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Función para confirmar acciones destructivas
confirm() {
    read -p "¿Estás seguro? (y/N): " -n 1 -r
    echo
    [[ $REPLY =~ ^[Yy]$ ]]
}

echo "🧹 Script de Limpieza de Recursos AWS"
echo ""
print_warning "⚠️  Este script eliminará TODOS los recursos del proyecto"
echo "   - Instancia EC2"
echo "   - Security Group"
echo "   - Key Pair"
echo ""

if ! confirm; then
    print_info "Operación cancelada"
    exit 0
fi

# Configuración por defecto
PROJECT_NAME="email-classifier-ml"
KEY_NAME="email-classifier-key"

# Leer información del deployment si existe
if [ -f "deployment-info.json" ]; then
    INSTANCE_ID=$(grep -o '"instance_id": "[^"]*"' deployment-info.json | cut -d'"' -f4)
    SECURITY_GROUP_ID=$(grep -o '"security_group_id": "[^"]*"' deployment-info.json | cut -d'"' -f4)
    KEY_NAME=$(grep -o '"key_name": "[^"]*"' deployment-info.json | cut -d'"' -f4)
else
    print_warning "No se encontró deployment-info.json"
    print_info "Intentando buscar recursos por tags..."
    
    # Buscar instancias por tag
    INSTANCE_ID=$(aws ec2 describe-instances \
        --filters "Name=tag:Project,Values=ORT-Obligatorio-2025" "Name=instance-state-name,Values=running,stopped,stopping" \
        --query 'Reservations[0].Instances[0].InstanceId' \
        --output text 2>/dev/null || echo "None")
    
    if [ "$INSTANCE_ID" = "None" ] || [ -z "$INSTANCE_ID" ]; then
        print_warning "No se encontraron instancias activas"
    fi
fi

echo ""
print_info "Iniciando limpieza de recursos..."

# 1. Terminar instancia EC2
if [ ! -z "$INSTANCE_ID" ] && [ "$INSTANCE_ID" != "None" ]; then
    print_info "Terminando instancia EC2: $INSTANCE_ID"
    
    aws ec2 terminate-instances --instance-ids $INSTANCE_ID > /dev/null
    print_success "Instancia EC2 terminada: $INSTANCE_ID"
    
    print_info "Esperando que la instancia termine completamente..."
    aws ec2 wait instance-terminated --instance-ids $INSTANCE_ID
    print_success "Instancia completamente terminada"
else
    print_warning "No se encontró instancia EC2 para terminar"
fi

# 2. Eliminar Security Group
if [ ! -z "$SECURITY_GROUP_ID" ] && [ "$SECURITY_GROUP_ID" != "None" ]; then
    print_info "Eliminando Security Group: $SECURITY_GROUP_ID"
    
    # Esperar un poco para que la instancia se desassocie del SG
    sleep 10
    
    aws ec2 delete-security-group --group-id $SECURITY_GROUP_ID 2>/dev/null || \
    print_warning "No se pudo eliminar el Security Group (puede que esté en uso)"
    
    print_success "Security Group eliminado"
else
    # Intentar encontrar SG por nombre
    print_info "Buscando Security Group por nombre..."
    SECURITY_GROUP_ID=$(aws ec2 describe-security-groups \
        --group-names ${PROJECT_NAME}-sg \
        --query 'SecurityGroups[0].GroupId' \
        --output text 2>/dev/null || echo "None")
    
    if [ "$SECURITY_GROUP_ID" != "None" ] && [ ! -z "$SECURITY_GROUP_ID" ]; then
        print_info "Eliminando Security Group: $SECURITY_GROUP_ID"
        sleep 10
        aws ec2 delete-security-group --group-id $SECURITY_GROUP_ID 2>/dev/null || \
        print_warning "No se pudo eliminar el Security Group"
        print_success "Security Group eliminado"
    else
        print_warning "No se encontró Security Group para eliminar"
    fi
fi

# 3. Eliminar Key Pair
print_info "Eliminando Key Pair: $KEY_NAME"

if aws ec2 describe-key-pairs --key-names $KEY_NAME &> /dev/null; then
    aws ec2 delete-key-pair --key-name $KEY_NAME
    print_success "Key Pair eliminado de AWS: $KEY_NAME"
    
    # Eliminar archivo local de clave privada
    if [ -f "${KEY_NAME}.pem" ]; then
        rm -f "${KEY_NAME}.pem"
        print_success "Archivo de clave privada eliminado: ${KEY_NAME}.pem"
    fi
else
    print_warning "Key Pair no encontrado: $KEY_NAME"
fi

# 4. Limpiar archivos locales de deployment
print_info "Limpiando archivos locales de deployment..."

# Archivos a eliminar
files_to_clean=(
    "deployment-info.json"
    "user-data.sh"
    "${KEY_NAME}.pem"
)

for file in "${files_to_clean[@]}"; do
    if [ -f "$file" ]; then
        rm -f "$file"
        print_success "Eliminado: $file"
    fi
done

echo ""
print_success "🎉 ¡Limpieza completada!"
echo ""
print_info "�� Resumen de recursos eliminados:"
echo "   🖥️  Instancia EC2: ${INSTANCE_ID:-'No encontrada'}"
echo "   🛡️  Security Group: ${SECURITY_GROUP_ID:-'No encontrado'}"
echo "   🔑 Key Pair: $KEY_NAME"
echo "   📁 Archivos locales: deployment-info.json, user-data.sh, *.pem"
echo ""
print_info "💰 Ya no se generarán costos por estos recursos"
echo ""
print_warning "📝 Nota: Este cleanup no afecta el código en GitHub"
echo "   Tu repositorio sigue disponible en:"
echo "   https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso"
