# 🚀 AWS Deployment Scripts

Scripts para deployment automático en AWS Academy del Clasificador de Emails ML.

## 📋 Scripts Disponibles

### `deploy.sh` - Deployment Automático
Crea toda la infraestructura AWS y despliega la aplicación:
- Instancia EC2 t3.medium
- Security Group con puertos 22, 8000, 8501
- Key Pair para acceso SSH
- User data script para instalación automática

**Uso:**
```bash
./aws/deploy.sh
```

### `check-deployment.sh` - Verificación
Verifica el estado del deployment y servicios:
- Estado de instancia EC2
- Conectividad de red
- Disponibilidad de servicios
- URLs de acceso

**Uso:**
```bash
./aws/check-deployment.sh
```

### `cleanup.sh` - Limpieza de Recursos
Elimina todos los recursos para evitar costos:
- Termina instancia EC2
- Elimina Security Group
- Elimina Key Pair
- Limpia archivos locales

**Uso:**
```bash
./aws/cleanup.sh
```

## 🔧 Flujo de Deployment

1. **Configurar AWS CLI**
   ```bash
   aws configure
   ```

2. **Clonar repositorio**
   ```bash
   git clone https://github.com/ORTMLProd/obligatorio-marzo-2025-alonso.git
   cd obligatorio-marzo-2025-alonso
   ```

3. **Ejecutar deployment**
   ```bash
   ./aws/deploy.sh
   ```

4. **Verificar (después de 5 minutos)**
   ```bash
   ./aws/check-deployment.sh
   ```

5. **Acceder a la aplicación**
   - Dashboard: `http://IP:8501`
   - API: `http://IP:8000`

6. **Limpiar al finalizar**
   ```bash
   ./aws/cleanup.sh
   ```

## 📊 Recursos Creados

- **EC2 Instance:** t3.medium con Amazon Linux 2
- **Security Group:** Puertos 22, 8000, 8501 abiertos
- **Key Pair:** Para acceso SSH
- **Tags:** Project=ORT-Obligatorio-2025

## 💰 Estimación de Costos

- **t3.medium:** $0.0416/hora
- **EBS gp2:** $0.10/GB/mes
- **Data Transfer:** $0.09/GB

**Total estimado:** ~$30/mes para uso 24/7

## 🔍 Troubleshooting

### Servicios no inician
```bash
# SSH a la instancia
ssh -i email-classifier-key.pem ec2-user@IP

# Ver logs
tail -f ~/obligatorio-marzo-2025-alonso/dashboard.log
tail -f ~/obligatorio-marzo-2025-alonso/api.log
```

### Recrear deployment
```bash
# Limpiar recursos existentes
./aws/cleanup.sh

# Esperar 2 minutos y redeployar
./aws/deploy.sh
```

## 📚 Documentación Completa

Ver [AWS_ACADEMY_DEPLOYMENT.md](AWS_ACADEMY_DEPLOYMENT.md) para guía paso a paso completa.
