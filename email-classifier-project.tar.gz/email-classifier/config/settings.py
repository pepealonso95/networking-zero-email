"""Configuration settings for the email classification service."""

from pydantic import Field
from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # Environment
    environment: str = Field(default="development", alias="ENVIRONMENT")
    
    # Zero Project API Configuration
    zero_api_base_url: str = Field(default="http://localhost:3000", alias="ZERO_API_BASE_URL")
    zero_api_key: Optional[str] = Field(default=None, alias="ZERO_API_KEY")
    zero_connection_id: Optional[str] = Field(default=None, alias="ZERO_CONNECTION_ID")
    
    # Zero Project Integration (for email export)
    google_client_id: Optional[str] = Field(default=None, alias="GOOGLE_CLIENT_ID")
    google_client_secret: Optional[str] = Field(default=None, alias="GOOGLE_CLIENT_SECRET")
    zero_database_url: Optional[str] = Field(default=None, alias="ZERO_DATABASE_URL")
    better_auth_secret: Optional[str] = Field(default=None, alias="BETTER_AUTH_SECRET")
    better_auth_url: Optional[str] = Field(default=None, alias="BETTER_AUTH_URL")
    resend_api_key: Optional[str] = Field(default=None, alias="RESEND_API_KEY")
    
    # OpenAI Configuration
    openai_api_key: Optional[str] = Field(default=None, alias="OPENAI_API_KEY")
    openai_model: str = Field(default="gpt-4o", alias="OPENAI_MODEL")
    
    # Model Configuration - renamed to avoid protected namespace warnings
    classifier_model_path: str = Field(default="models/bill_classifier.pkl", alias="MODEL_PATH")
    classifier_model_type: str = Field(default="distilbert", alias="MODEL_TYPE")
    confidence_threshold: float = Field(default=0.7, alias="CONFIDENCE_THRESHOLD")
    batch_size: int = Field(default=32, alias="BATCH_SIZE")
    
    # Database Configuration
    database_url: str = Field(default="sqlite:///./data/email_classifier.db", alias="DATABASE_URL")
    
    # Redis Configuration
    redis_url: str = Field(default="redis://localhost:6379", alias="REDIS_URL")
    redis_enabled: bool = Field(default=False, alias="REDIS_ENABLED")
    
    # Logging
    log_level: str = Field(default="INFO", alias="LOG_LEVEL")
    log_file: str = Field(default="logs/email_classifier.log", alias="LOG_FILE")
    
    # Training Configuration
    training_data_path: str = Field(default="data/labeled_emails.csv", alias="TRAINING_DATA_PATH")
    validation_split: float = Field(default=0.2, alias="VALIDATION_SPLIT")
    max_email_length: int = Field(default=2000, alias="MAX_EMAIL_LENGTH")
    learning_rate: float = Field(default=2e-5, alias="LEARNING_RATE")
    epochs: int = Field(default=3, alias="EPOCHS")
    
    # Classification Prompts
    bill_classification_prompt: str = Field(
        default="Analyze this email and determine if it represents a bill that requires payment action (not a receipt). Consider: utility bills, subscription payments, invoices requiring action, payment reminders, etc.",
        alias="BILL_CLASSIFICATION_PROMPT"
    )
    
    model_config = {
        "env_file": ".env",
        "env_file_encoding": "utf-8",
        "protected_namespaces": ('settings_',)  # Fix protected namespace warnings
    }


# Global settings instance
settings = Settings() 